ENI Carthage Platform V15

Corrections principales:
1. Route guard frontend: un etudiant ne peut plus ouvrir les pages admin par URL directe.
2. Moyenne provisoire: les matieres sans notes ne sont plus comptees comme zero dans la moyenne affichee.
3. Saisie notes: selection par groupe, puis affichage uniquement des etudiants du groupe.
4. Deplacement EDT: la salle se choisit maintenant dans une liste de salles libres pour le creneau choisi.
5. Enseignants: admin peut creer/modifier un enseignant et l'affecter a des matieres.
6. Enseignant: voit son emploi du temps selon ses matieres affectees et saisit seulement les notes des matieres affectees.
7. Skill Swap: la page Marketplace contient aussi la creation du profil offres/besoins.
8. Interface: textes descriptifs inutiles reduits.

Lancement:
Backend:
cd integrated-backend
"C:\Program Files\apache-maven-3.9.15\bin\mvn.cmd" spring-boot:run

Frontend:
cd frontend/angular
npm install
npm start

Comptes:
admin / admin
teacher / teacher
student / student
student2 / student2
demo / demo
