ENI Carthage Platform V16 - corrections notes/credits

Corrections principales :

1. Moyenne generale etudiant
   - La moyenne generale du semestre n'est plus affichee tant que toutes les matieres du semestre ne sont pas completes.
   - Les matieres deja saisies affichent toujours leurs moyennes individuelles.
   - Le statut du semestre devient "Non finalisee" si plusieurs notes sont encore vides.
   - Objectif : eviter le cas illogique ou un etudiant avec beaucoup de cases vides voit une moyenne generale comme 12.

2. Credits semestre
   - Les credits des modules sont normalises pour que la somme pedagogique de chaque semestre soit exactement 30 credits.
   - Correction du probleme d'arrondi des modules 5.5 / 6.5 qui pouvait donner 31 credits.

3. Interface notes
   - Cote etudiant : le bloc resume affiche maintenant "Moyenne finale" et "Credits valides".
   - Les matieres incompletes sont marquees "Incomplete" au lieu de laisser croire que la moyenne generale est definitive.

Important :
- Pour voir les nouveaux credits, faire un reset PostgreSQL une seule fois avec RESET_DATABASE.sql avant de tester V16.
- Ne pas utiliser npm audit fix --force.
