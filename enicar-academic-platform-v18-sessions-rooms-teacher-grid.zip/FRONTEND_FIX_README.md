# Correction frontend Angular

Ne pas lancer `npm audit fix --force` sur ce projet. Cette commande met Angular a jour vers une version majeure incompatible avec la configuration actuelle.

Pour reparer un frontend casse par `npm audit fix --force` :

```powershell
cd frontend/angular
.\RESET_FRONTEND.ps1
npm start
```

Ou manuellement :

```powershell
cd frontend/angular
Remove-Item -Recurse -Force node_modules
Remove-Item -Force package-lock.json
npm install
npm start
```

Versions fixees : Angular 17.3.x, TypeScript 5.4.5, Zone.js 0.14.10.
