package com.unigate.communication.service.matching;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;

class SkillMatchingAlgorithmTest {

    private final SkillMatchingAlgorithm algorithm = new SkillMatchingAlgorithm();

    @Test
    void mutualExchangeWithGoodGradeAndAvailabilityShouldScoreHigh() {
        MatchScore score = algorithm.score(new MatchInput(
                true,
                true,
                180,
                BigDecimal.valueOf(16),
                BigDecimal.valueOf(4.5),
                true
        ));

        assertThat(score.totalScore()).isGreaterThan(BigDecimal.valueOf(85));
        assertThat(score.skillComplementarityScore()).isEqualByComparingTo(BigDecimal.valueOf(100));
        assertThat(score.mutualExchange()).isTrue();
    }

    @Test
    void oneWayExchangeShouldRemainValidButLowerThanMutual() {
        MatchScore mutual = algorithm.score(new MatchInput(true, true, 180, BigDecimal.valueOf(16), BigDecimal.valueOf(4.5), true));
        MatchScore oneWay = algorithm.score(new MatchInput(true, false, 180, BigDecimal.valueOf(16), BigDecimal.valueOf(4.5), true));

        assertThat(oneWay.totalScore()).isLessThan(mutual.totalScore());
        assertThat(oneWay.skillComplementarityScore()).isEqualByComparingTo(BigDecimal.valueOf(65));
    }

    @Test
    void missingGradeAndRatingUseNeutralFallbacks() {
        MatchScore score = algorithm.score(new MatchInput(true, false, 60, null, null, false));

        assertThat(score.totalScore()).isGreaterThan(BigDecimal.valueOf(35));
        assertThat(score.tutorGradeScore()).isEqualByComparingTo(BigDecimal.valueOf(55));
        assertThat(score.historyScore()).isEqualByComparingTo(BigDecimal.valueOf(70));
    }
}
