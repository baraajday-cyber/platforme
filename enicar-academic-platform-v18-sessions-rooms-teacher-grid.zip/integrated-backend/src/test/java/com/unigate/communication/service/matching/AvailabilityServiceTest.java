package com.unigate.communication.service.matching;

import org.junit.jupiter.api.Test;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class AvailabilityServiceTest {

    private final AvailabilityService service = new AvailabilityService();

    @Test
    void computesCommonFreeWindowsFromBusyTimetables() {
        List<TimeWindow> busyA = List.of(new TimeWindow(DayOfWeek.MONDAY, LocalTime.of(8, 0), LocalTime.of(10, 0)));
        List<TimeWindow> busyB = List.of(new TimeWindow(DayOfWeek.MONDAY, LocalTime.of(9, 0), LocalTime.of(11, 0)));

        List<TimeWindow> common = service.commonFreeWindows(busyA, busyB, LocalTime.of(8, 0), LocalTime.of(12, 0));

        assertThat(common).contains(new TimeWindow(DayOfWeek.MONDAY, LocalTime.of(11, 0), LocalTime.of(12, 0)));
        assertThat(service.totalMinutes(common)).isGreaterThanOrEqualTo(60);
    }

    @Test
    void mergesOverlappingBusyWindowsBeforeCreatingFreeSlots() {
        List<TimeWindow> busy = List.of(
                new TimeWindow(DayOfWeek.TUESDAY, LocalTime.of(8, 0), LocalTime.of(10, 0)),
                new TimeWindow(DayOfWeek.TUESDAY, LocalTime.of(9, 30), LocalTime.of(11, 0))
        );

        List<TimeWindow> free = service.freeWindows(busy, LocalTime.of(8, 0), LocalTime.of(12, 0));

        assertThat(free).contains(new TimeWindow(DayOfWeek.TUESDAY, LocalTime.of(11, 0), LocalTime.of(12, 0)));
        assertThat(free).doesNotContain(new TimeWindow(DayOfWeek.TUESDAY, LocalTime.of(10, 0), LocalTime.of(12, 0)));
    }
}
