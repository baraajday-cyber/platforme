package com.unigate.academic.domain.math;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;

class GradeMathTest {

    @Test
    void computesWeightedAverageWithCcExamAndTp() {
        BigDecimal average = GradeMath.weightedAverage(
                new BigDecimal("12"),
                new BigDecimal("14"),
                new BigDecimal("16"),
                new BigDecimal("0.30"),
                new BigDecimal("0.50"),
                new BigDecimal("0.20")
        );

        assertThat(average).isEqualByComparingTo("13.80");
    }

    @Test
    void computesRequiredExamForSubject() {
        BigDecimal required = GradeMath.requiredExamForSubject(
                GradeMath.VALIDATION_MARK,
                new BigDecimal("8"),
                null,
                new BigDecimal("0.35"),
                new BigDecimal("0.65"),
                BigDecimal.ZERO
        ).orElseThrow();

        assertThat(required).isEqualByComparingTo("11.08");
    }

    @Test
    void computesRequiredExamForModuleCompensation() {
        BigDecimal required = GradeMath.requiredExamForModule(
                GradeMath.VALIDATION_MARK,
                new BigDecimal("3"),
                new BigDecimal("24"),
                new BigDecimal("1"),
                new BigDecimal("8"),
                null,
                new BigDecimal("0.35"),
                new BigDecimal("0.65"),
                BigDecimal.ZERO
        ).orElseThrow();

        assertThat(required).isEqualByComparingTo("4.92");
    }

    @Test
    void returnsEmptyWhenExamHasZeroWeight() {
        assertThat(GradeMath.requiredExamForSubject(
                GradeMath.VALIDATION_MARK,
                new BigDecimal("12"),
                null,
                BigDecimal.ONE,
                BigDecimal.ZERO,
                BigDecimal.ZERO
        )).isEmpty();
    }
}
