package com.unigate.academic.dto.teacher;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.util.List;

public record TeacherCreateRequest(
        @NotBlank @Size(min = 3, max = 80) String username,
        @NotBlank @Size(min = 4, max = 80) String password,
        @NotBlank @Size(min = 3, max = 160) String fullName,
        @Email String email,
        @NotNull List<Long> courseIds,
        Boolean enabled
) {
}
