package com.unigate.academic.domain.entity;

import com.unigate.academic.domain.enums.Semester;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(
        name = "grade_configs",
        uniqueConstraints = @UniqueConstraint(name = "uk_grade_config_subject", columnNames = {"department", "academic_year", "semester", "subject_id", "module_id"}),
        indexes = @Index(name = "idx_grade_config_dept_semester", columnList = "department, academic_year, semester")
)
public class GradeConfig extends BaseEntity {

    @Column(nullable = false, length = 80)
    private String department;

    @Column(name = "academic_year", nullable = false)
    private Integer year;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Semester semester;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "subject_id", nullable = false)
    private Course subject;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "module_id", nullable = false)
    private AcademicModule module;

    @Column(name = "subject_coefficient", nullable = false, precision = 5, scale = 2)
    private BigDecimal subjectCoefficient;

    @Column(name = "module_coefficient", nullable = false, precision = 5, scale = 2)
    private BigDecimal moduleCoefficient;

    @Column(name = "cc_weight", nullable = false, precision = 5, scale = 4)
    private BigDecimal ccWeight;

    @Column(name = "exam_weight", nullable = false, precision = 5, scale = 4)
    private BigDecimal examWeight;

    @Column(name = "tp_weight", nullable = false, precision = 5, scale = 4)
    private BigDecimal tpWeight;

    @Column(nullable = false)
    private Integer credits;

    @Column(nullable = false)
    @Builder.Default
    private boolean active = true;

    public BigDecimal totalWeight() {
        return ccWeight.add(examWeight).add(tpWeight);
    }
}
