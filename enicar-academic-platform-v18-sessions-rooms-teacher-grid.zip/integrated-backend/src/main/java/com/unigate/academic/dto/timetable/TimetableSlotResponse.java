package com.unigate.academic.dto.timetable;

import com.unigate.academic.domain.enums.SlotStatus;

import java.time.DayOfWeek;
import java.time.LocalTime;

public record TimetableSlotResponse(
        Long id,
        Long classGroupId,
        String classGroupName,
        Long courseId,
        String courseName,
        DayOfWeek dayOfWeek,
        LocalTime startTime,
        LocalTime endTime,
        String room,
        Long professorId,
        String professorName,
        SlotStatus status,
        String changeReason
) {
}
