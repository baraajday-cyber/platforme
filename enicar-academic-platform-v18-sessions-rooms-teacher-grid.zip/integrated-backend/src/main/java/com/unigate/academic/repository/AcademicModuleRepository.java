package com.unigate.academic.repository;

import com.unigate.academic.domain.entity.AcademicModule;
import com.unigate.academic.domain.enums.Semester;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface AcademicModuleRepository extends JpaRepository<AcademicModule, Long> {
    List<AcademicModule> findByDepartmentAndYearAndSemesterOrderByName(String department, Integer year, Semester semester);
    Optional<AcademicModule> findByNameAndDepartmentAndYearAndSemester(String name, String department, Integer year, Semester semester);
}
