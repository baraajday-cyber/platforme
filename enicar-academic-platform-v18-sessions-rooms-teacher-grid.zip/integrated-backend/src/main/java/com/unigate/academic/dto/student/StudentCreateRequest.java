package com.unigate.academic.dto.student;

import com.unigate.academic.domain.enums.Semester;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record StudentCreateRequest(
        @NotBlank @Size(min = 3, max = 80) String username,
        @NotBlank @Size(min = 4, max = 80) String password,
        @NotBlank @Size(min = 3, max = 160) String fullName,
        @Email String email,
        String studentCode,
        @NotBlank String department,
        @NotNull Integer year,
        @NotNull Semester semester,
        @NotNull Long classGroupId
) {
}
