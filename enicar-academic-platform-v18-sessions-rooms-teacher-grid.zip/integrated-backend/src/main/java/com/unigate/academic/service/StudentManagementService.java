package com.unigate.academic.service;

import com.unigate.academic.common.exception.ConflictException;
import com.unigate.academic.common.exception.ResourceNotFoundException;
import com.unigate.academic.domain.entity.AcademicUser;
import com.unigate.academic.domain.entity.ClassGroup;
import com.unigate.academic.domain.entity.StudentClassAssignment;
import com.unigate.academic.domain.enums.Semester;
import com.unigate.academic.dto.grade.StudentOptionResponse;
import com.unigate.academic.dto.student.StudentCreateRequest;
import com.unigate.academic.dto.student.StudentPasswordRequest;
import com.unigate.academic.dto.student.StudentUpdateRequest;
import com.unigate.academic.dto.student.StudentUserResponse;
import com.unigate.academic.repository.AcademicUserRepository;
import com.unigate.academic.repository.ClassGroupRepository;
import com.unigate.academic.repository.StudentClassAssignmentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Locale;

@Service
@RequiredArgsConstructor
@Transactional
public class StudentManagementService {

    private final AcademicUserRepository userRepository;
    private final ClassGroupRepository classGroupRepository;
    private final StudentClassAssignmentRepository assignmentRepository;
    private final PasswordEncoder passwordEncoder;

    @Transactional(readOnly = true)
    public List<StudentUserResponse> listStudents() {
        return userRepository.findByRolesCsvContainingIgnoreCaseOrderByDisplayNameAsc("STUDENT")
                .stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public List<StudentOptionResponse> listStudentOptions() {
        return listStudents().stream()
                .map(student -> new StudentOptionResponse(
                        student.studentId(),
                        student.code(),
                        student.fullName(),
                        student.department(),
                        student.year(),
                        student.semester() == null ? "S4" : student.semester().name(),
                        student.classGroupId(),
                        student.classGroupName()
                ))
                .toList();
    }

    public StudentUserResponse createStudent(StudentCreateRequest request) {
        String username = normalizeUsername(request.username());
        if (userRepository.existsByUsernameIgnoreCase(username)) {
            throw new ConflictException("Cet identifiant existe deja: " + username);
        }
        ClassGroup group = classGroup(request.classGroupId());
        Long studentId = nextStudentId();
        AcademicUser user = AcademicUser.builder()
                .username(username)
                .passwordHash(passwordEncoder.encode(request.password()))
                .displayName(request.fullName().trim())
                .email(clean(request.email()))
                .studentCode(clean(request.studentCode()) == null ? "ETU-" + String.format("%03d", studentId) : clean(request.studentCode()))
                .studentId(studentId)
                .rolesCsv("STUDENT")
                .enabled(true)
                .enrolled(true)
                .defaultDepartment(request.department().trim())
                .defaultYear(request.year())
                .defaultSemester(request.semester())
                .defaultClassGroup(group)
                .build();
        AcademicUser saved = userRepository.save(user);
        assign(saved, group, request.year(), request.semester());
        return toResponse(saved);
    }

    public StudentUserResponse updateStudent(Long studentId, StudentUpdateRequest request) {
        AcademicUser user = userByStudentId(studentId);
        ClassGroup group = classGroup(request.classGroupId());
        user.setDisplayName(request.fullName().trim());
        user.setEmail(clean(request.email()));
        user.setStudentCode(clean(request.studentCode()) == null ? user.getStudentCode() : clean(request.studentCode()));
        user.setDefaultDepartment(request.department().trim());
        user.setDefaultYear(request.year());
        user.setDefaultSemester(request.semester());
        user.setDefaultClassGroup(group);
        if (request.enabled() != null) {
            user.setEnabled(request.enabled());
        }
        if (request.enrolled() != null) {
            user.setEnrolled(request.enrolled());
        }
        assign(user, group, request.year(), request.semester());
        return toResponse(user);
    }

    public void changePassword(Long studentId, StudentPasswordRequest request) {
        AcademicUser user = userByStudentId(studentId);
        user.setPasswordHash(passwordEncoder.encode(request.password()));
    }

    @Transactional(readOnly = true)
    public AcademicUser userByUsername(String username) {
        return userRepository.findByUsernameIgnoreCase(normalizeUsername(username))
                .orElseThrow(() -> new ResourceNotFoundException("Utilisateur introuvable: " + username));
    }

    @Transactional(readOnly = true)
    public AcademicUser userByStudentId(Long studentId) {
        return userRepository.findByStudentId(studentId)
                .orElseThrow(() -> new ResourceNotFoundException("Etudiant introuvable: " + studentId));
    }

    @Transactional(readOnly = true)
    public boolean isEnrolled(Long studentId) {
        return userRepository.findByStudentId(studentId)
                .map(user -> user.isEnabled() && user.isEnrolled())
                .orElse(false);
    }

    public AcademicUser seedUser(String username, String password, String displayName, String rolesCsv, Long studentId,
                                 String code, String email, ClassGroup group, Integer year, Semester semester) {
        String normalized = normalizeUsername(username);
        AcademicUser user = userRepository.findByUsernameIgnoreCase(normalized).orElseGet(AcademicUser::new);
        user.setUsername(normalized);
        if (user.getPasswordHash() == null || user.getPasswordHash().isBlank()) {
            user.setPasswordHash(passwordEncoder.encode(password));
        }
        user.setDisplayName(displayName);
        user.setRolesCsv(rolesCsv);
        user.setStudentId(studentId);
        user.setStudentCode(code);
        user.setEmail(email);
        user.setEnabled(true);
        user.setEnrolled(rolesCsv.toUpperCase(Locale.ROOT).contains("STUDENT"));
        if (group != null) {
            user.setDefaultDepartment(group.getDepartment());
            user.setDefaultYear(year);
            user.setDefaultSemester(semester);
            user.setDefaultClassGroup(group);
        }
        AcademicUser saved = userRepository.save(user);
        if (group != null && rolesCsv.toUpperCase(Locale.ROOT).contains("STUDENT")) {
            assign(saved, group, year, semester);
        }
        return saved;
    }

    private void assign(AcademicUser user, ClassGroup group, Integer year, Semester semester) {
        if (user.getStudentId() == null) {
            return;
        }
        assignmentRepository.findByStudentIdAndYearAndSemesterAndActiveTrue(user.getStudentId(), year, semester)
                .ifPresent(current -> {
                    if (!current.getClassGroup().getId().equals(group.getId())) {
                        current.setActive(false);
                    }
                });
        boolean alreadyActive = assignmentRepository.findByStudentIdAndYearAndSemesterAndActiveTrue(user.getStudentId(), year, semester)
                .map(current -> current.getClassGroup().getId().equals(group.getId()))
                .orElse(false);
        if (!alreadyActive) {
            assignmentRepository.save(StudentClassAssignment.builder()
                    .studentId(user.getStudentId())
                    .year(year)
                    .semester(semester)
                    .classGroup(group)
                    .active(true)
                    .build());
        }
    }

    private StudentUserResponse toResponse(AcademicUser user) {
        ClassGroup group = user.getDefaultClassGroup();
        return new StudentUserResponse(
                user.getId(),
                user.getStudentId(),
                user.getUsername(),
                user.getStudentCode(),
                user.getDisplayName(),
                user.getEmail(),
                user.getDefaultDepartment(),
                user.getDefaultYear(),
                user.getDefaultSemester(),
                group == null ? null : group.getId(),
                group == null ? "Non affecte" : group.getName(),
                user.isEnabled(),
                user.isEnrolled()
        );
    }

    private ClassGroup classGroup(Long id) {
        return classGroupRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Groupe introuvable: " + id));
    }

    private Long nextStudentId() {
        Long max = userRepository.maxStudentId();
        return Math.max(1000L, max == null ? 0L : max) + 1L;
    }

    private String normalizeUsername(String username) {
        return username == null ? "" : username.trim().toLowerCase(Locale.ROOT);
    }

    private String clean(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }
}
