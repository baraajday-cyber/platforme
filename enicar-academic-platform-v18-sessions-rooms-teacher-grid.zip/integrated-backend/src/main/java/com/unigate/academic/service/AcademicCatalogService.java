package com.unigate.academic.service;

import com.unigate.academic.common.exception.ConflictException;
import com.unigate.academic.common.exception.ResourceNotFoundException;
import com.unigate.academic.domain.entity.AcademicModule;
import com.unigate.academic.domain.entity.ClassGroup;
import com.unigate.academic.domain.entity.Course;
import com.unigate.academic.domain.entity.StudentClassAssignment;
import com.unigate.academic.domain.enums.Semester;
import com.unigate.academic.dto.timetable.AcademicModuleRequest;
import com.unigate.academic.dto.timetable.AcademicModuleResponse;
import com.unigate.academic.dto.timetable.ClassGroupRequest;
import com.unigate.academic.dto.timetable.ClassGroupResponse;
import com.unigate.academic.dto.timetable.CourseRequest;
import com.unigate.academic.dto.timetable.CourseResponse;
import com.unigate.academic.dto.timetable.StudentAssignmentRequest;
import com.unigate.academic.mapper.AcademicMapper;
import com.unigate.academic.repository.AcademicModuleRepository;
import com.unigate.academic.repository.ClassGroupRepository;
import com.unigate.academic.repository.CourseRepository;
import com.unigate.academic.repository.StudentClassAssignmentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class AcademicCatalogService {

    private final ClassGroupRepository classGroupRepository;
    private final CourseRepository courseRepository;
    private final AcademicModuleRepository academicModuleRepository;
    private final StudentClassAssignmentRepository assignmentRepository;
    private final AcademicMapper mapper;

    public ClassGroupResponse createClassGroup(ClassGroupRequest request) {
        classGroupRepository.findByNameAndDepartmentAndYearAndSemester(
                request.name(), request.department(), request.year(), request.semester()
        ).ifPresent(existing -> {
            throw new ConflictException("A class group with this identity already exists");
        });

        ClassGroup group = ClassGroup.builder()
                .name(request.name().trim())
                .department(request.department().trim())
                .year(request.year())
                .semester(request.semester())
                .description(request.description())
                .build();
        return mapper.toClassGroupResponse(classGroupRepository.save(group));
    }

    public ClassGroupResponse updateClassGroup(Long id, ClassGroupRequest request) {
        ClassGroup group = getClassGroupOrThrow(id);
        group.setName(request.name().trim());
        group.setDepartment(request.department().trim());
        group.setYear(request.year());
        group.setSemester(request.semester());
        group.setDescription(request.description());
        return mapper.toClassGroupResponse(group);
    }

    @Transactional(readOnly = true)
    public List<ClassGroupResponse> listClassGroups(String department, Integer year, Semester semester) {
        return classGroupRepository.findByDepartmentAndYearAndSemesterOrderByName(department, year, semester)
                .stream()
                .map(mapper::toClassGroupResponse)
                .toList();
    }

    public void deleteClassGroup(Long id) {
        if (!classGroupRepository.existsById(id)) {
            throw new ResourceNotFoundException("Class group not found: " + id);
        }
        classGroupRepository.deleteById(id);
    }

    public CourseResponse createCourse(CourseRequest request) {
        courseRepository.findByNameAndDepartment(request.name(), request.department()).ifPresent(existing -> {
            throw new ConflictException("A course with this name already exists in the department");
        });
        Course course = Course.builder()
                .name(request.name().trim())
                .department(request.department().trim())
                .code(request.code())
                .defaultCoefficient(request.defaultCoefficient())
                .defaultCredits(request.defaultCredits())
                .build();
        return mapper.toCourseResponse(courseRepository.save(course));
    }

    public CourseResponse updateCourse(Long id, CourseRequest request) {
        Course course = getCourseOrThrow(id);
        course.setName(request.name().trim());
        course.setDepartment(request.department().trim());
        course.setCode(request.code());
        course.setDefaultCoefficient(request.defaultCoefficient());
        course.setDefaultCredits(request.defaultCredits());
        return mapper.toCourseResponse(course);
    }

    @Transactional(readOnly = true)
    public List<CourseResponse> listCourses(String department) {
        return courseRepository.findByDepartmentOrderByName(department).stream()
                .map(mapper::toCourseResponse)
                .toList();
    }

    public AcademicModuleResponse createAcademicModule(AcademicModuleRequest request) {
        academicModuleRepository.findByNameAndDepartmentAndYearAndSemester(
                request.name(), request.department(), request.year(), request.semester()
        ).ifPresent(existing -> {
            throw new ConflictException("An academic module with this identity already exists");
        });
        AcademicModule module = AcademicModule.builder()
                .name(request.name().trim())
                .department(request.department().trim())
                .year(request.year())
                .semester(request.semester())
                .moduleCoefficient(request.moduleCoefficient())
                .credits(request.credits())
                .build();
        return mapper.toAcademicModuleResponse(academicModuleRepository.save(module));
    }

    public AcademicModuleResponse updateAcademicModule(Long id, AcademicModuleRequest request) {
        AcademicModule module = getAcademicModuleOrThrow(id);
        module.setName(request.name().trim());
        module.setDepartment(request.department().trim());
        module.setYear(request.year());
        module.setSemester(request.semester());
        module.setModuleCoefficient(request.moduleCoefficient());
        module.setCredits(request.credits());
        return mapper.toAcademicModuleResponse(module);
    }

    @Transactional(readOnly = true)
    public List<AcademicModuleResponse> listAcademicModules(String department, Integer year, Semester semester) {
        return academicModuleRepository.findByDepartmentAndYearAndSemesterOrderByName(department, year, semester).stream()
                .map(mapper::toAcademicModuleResponse)
                .toList();
    }

    public void assignStudentToClass(StudentAssignmentRequest request) {
        ClassGroup group = getClassGroupOrThrow(request.classGroupId());
        assignmentRepository.findByStudentIdAndYearAndSemesterAndActiveTrue(
                request.studentId(), request.year(), request.semester()
        ).ifPresent(current -> {
            current.setActive(false);
            assignmentRepository.save(current);
        });

        StudentClassAssignment assignment = StudentClassAssignment.builder()
                .studentId(request.studentId())
                .classGroup(group)
                .year(request.year())
                .semester(request.semester())
                .active(true)
                .build();
        assignmentRepository.save(assignment);
    }

    @Transactional(readOnly = true)
    public ClassGroup getClassGroupOrThrow(Long id) {
        return classGroupRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Class group not found: " + id));
    }

    @Transactional(readOnly = true)
    public Course getCourseOrThrow(Long id) {
        return courseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Course not found: " + id));
    }

    @Transactional(readOnly = true)
    public AcademicModule getAcademicModuleOrThrow(Long id) {
        return academicModuleRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Academic module not found: " + id));
    }
}
