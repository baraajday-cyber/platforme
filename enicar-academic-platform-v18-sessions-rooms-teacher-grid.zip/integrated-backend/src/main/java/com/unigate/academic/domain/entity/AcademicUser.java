package com.unigate.academic.domain.entity;

import com.unigate.academic.domain.enums.Semester;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "academic_users")
public class AcademicUser extends BaseEntity {

    @Column(nullable = false, unique = true, length = 80)
    private String username;

    @Column(name = "password_hash", nullable = false)
    private String passwordHash;

    @Column(name = "display_name", nullable = false, length = 160)
    private String displayName;

    @Column(length = 160)
    private String email;

    @Column(name = "student_code", length = 60)
    private String studentCode;

    @Column(name = "student_id", unique = true)
    private Long studentId;

    @Column(name = "roles_csv", nullable = false, length = 160)
    private String rolesCsv;

    @Column(nullable = false)
    @Builder.Default
    private boolean enabled = true;

    @Column(nullable = false)
    @Builder.Default
    private boolean enrolled = true;

    @Column(name = "default_department", length = 120)
    private String defaultDepartment;

    @Column(name = "default_year")
    private Integer defaultYear;

    @Enumerated(EnumType.STRING)
    @Column(name = "default_semester", length = 10)
    private Semester defaultSemester;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "default_class_group_id")
    private ClassGroup defaultClassGroup;
}
