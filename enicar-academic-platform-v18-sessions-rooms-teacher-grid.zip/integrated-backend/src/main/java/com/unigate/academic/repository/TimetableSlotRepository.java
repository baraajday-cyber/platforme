package com.unigate.academic.repository;

import com.unigate.academic.domain.entity.TimetableSlot;
import com.unigate.academic.domain.enums.SlotStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.List;

public interface TimetableSlotRepository extends JpaRepository<TimetableSlot, Long> {

    List<TimetableSlot> findByClassGroupIdOrderByDayOfWeekAscStartTimeAsc(Long classGroupId);

    List<TimetableSlot> findByClassGroupIdAndStatusOrderByDayOfWeekAscStartTimeAsc(Long classGroupId, SlotStatus status);

    @Query("""
            select t
            from TimetableSlot t
            where t.status = com.unigate.academic.domain.enums.SlotStatus.ACTIVE
              and t.classGroup.year = :year
              and t.classGroup.semester = :semester
              and (t.course.id in :courseIds or lower(t.course.name) in :courseNamesLower or t.professorId = :teacherUserId)
            order by t.dayOfWeek asc, t.startTime asc, t.classGroup.name asc
            """)
    List<TimetableSlot> findTeacherSlots(
            @Param("teacherUserId") Long teacherUserId,
            @Param("courseIds") List<Long> courseIds,
            @Param("courseNamesLower") List<String> courseNamesLower,
            @Param("year") Integer year,
            @Param("semester") com.unigate.academic.domain.enums.Semester semester
    );

    @Query("""
            select case when count(t) > 0 then true else false end
            from TimetableSlot t
            where t.classGroup.id = :classGroupId
              and t.dayOfWeek = :dayOfWeek
              and t.status = com.unigate.academic.domain.enums.SlotStatus.ACTIVE
              and (:excludedId is null or t.id <> :excludedId)
              and t.startTime < :endTime
              and t.endTime > :startTime
            """)
    boolean existsClassGroupOverlap(
            @Param("classGroupId") Long classGroupId,
            @Param("dayOfWeek") DayOfWeek dayOfWeek,
            @Param("startTime") LocalTime startTime,
            @Param("endTime") LocalTime endTime,
            @Param("excludedId") Long excludedId
    );

    @Query("""
            select case when count(t) > 0 then true else false end
            from TimetableSlot t
            where lower(t.room) = lower(:room)
              and t.dayOfWeek = :dayOfWeek
              and t.status = com.unigate.academic.domain.enums.SlotStatus.ACTIVE
              and (:excludedId is null or t.id <> :excludedId)
              and t.startTime < :endTime
              and t.endTime > :startTime
            """)
    boolean existsRoomOverlap(
            @Param("room") String room,
            @Param("dayOfWeek") DayOfWeek dayOfWeek,
            @Param("startTime") LocalTime startTime,
            @Param("endTime") LocalTime endTime,
            @Param("excludedId") Long excludedId
    );

    @Query("""
            select case when count(t) > 0 then true else false end
            from TimetableSlot t
            where t.professorId = :professorId
              and t.dayOfWeek = :dayOfWeek
              and t.status = com.unigate.academic.domain.enums.SlotStatus.ACTIVE
              and (:excludedId is null or t.id <> :excludedId)
              and t.startTime < :endTime
              and t.endTime > :startTime
            """)
    boolean existsProfessorOverlap(
            @Param("professorId") Long professorId,
            @Param("dayOfWeek") DayOfWeek dayOfWeek,
            @Param("startTime") LocalTime startTime,
            @Param("endTime") LocalTime endTime,
            @Param("excludedId") Long excludedId
    );


    @Query("""
            select t
            from TimetableSlot t
            where t.dayOfWeek = :dayOfWeek
              and t.status = com.unigate.academic.domain.enums.SlotStatus.ACTIVE
              and (:excludedId is null or t.id <> :excludedId)
              and t.startTime < :endTime
              and t.endTime > :startTime
            order by t.dayOfWeek asc, t.startTime asc, t.classGroup.name asc
            """)
    List<TimetableSlot> findActiveOverlappingSlots(
            @Param("dayOfWeek") DayOfWeek dayOfWeek,
            @Param("startTime") LocalTime startTime,
            @Param("endTime") LocalTime endTime,
            @Param("excludedId") Long excludedId
    );

    List<TimetableSlot> findByStatusAndClassGroupYearAndClassGroupSemesterOrderByDayOfWeekAscStartTimeAsc(
            SlotStatus status,
            Integer year,
            com.unigate.academic.domain.enums.Semester semester
    );

    @Query("""
            select distinct t.room
            from TimetableSlot t
            where t.status = com.unigate.academic.domain.enums.SlotStatus.ACTIVE
              and t.room is not null
            order by t.room
            """)
    List<String> findDistinctActiveRooms();

}
