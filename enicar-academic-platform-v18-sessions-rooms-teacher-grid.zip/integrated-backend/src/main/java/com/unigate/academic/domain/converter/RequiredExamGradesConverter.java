package com.unigate.academic.domain.converter;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.unigate.academic.domain.vo.RequiredExamGrade;
import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

@Converter
public class RequiredExamGradesConverter implements AttributeConverter<Map<Long, RequiredExamGrade>, String> {

    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final JavaType TYPE = MAPPER.getTypeFactory()
            .constructMapType(LinkedHashMap.class, Long.class, RequiredExamGrade.class);

    @Override
    public String convertToDatabaseColumn(Map<Long, RequiredExamGrade> attribute) {
        if (attribute == null || attribute.isEmpty()) {
            return "{}";
        }
        try {
            return MAPPER.writeValueAsString(attribute);
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("Cannot serialize required exam grades", e);
        }
    }

    @Override
    public Map<Long, RequiredExamGrade> convertToEntityAttribute(String dbData) {
        if (dbData == null || dbData.isBlank()) {
            return new LinkedHashMap<>();
        }
        try {
            return MAPPER.readValue(dbData, TYPE);
        } catch (IOException e) {
            throw new IllegalArgumentException("Cannot deserialize required exam grades", e);
        }
    }
}
