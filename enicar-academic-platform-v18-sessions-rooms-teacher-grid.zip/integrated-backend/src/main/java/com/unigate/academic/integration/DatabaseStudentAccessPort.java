package com.unigate.academic.integration;

import com.unigate.academic.common.exception.ForbiddenAcademicAccessException;
import com.unigate.academic.service.StudentManagementService;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
@RequiredArgsConstructor
public class DatabaseStudentAccessPort implements StudentAccessPort {

    private final StudentManagementService studentManagementService;

    @Override
    public void assertStudentIsEnrolled(Long studentId) {
        if (studentId == null || !studentManagementService.isEnrolled(studentId)) {
            throw new ForbiddenAcademicAccessException("Etudiant non inscrit ou desactive: " + studentId);
        }
    }
}
