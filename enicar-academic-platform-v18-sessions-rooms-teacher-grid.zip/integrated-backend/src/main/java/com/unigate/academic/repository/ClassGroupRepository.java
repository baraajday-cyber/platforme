package com.unigate.academic.repository;

import com.unigate.academic.domain.entity.ClassGroup;
import com.unigate.academic.domain.enums.Semester;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ClassGroupRepository extends JpaRepository<ClassGroup, Long> {
    List<ClassGroup> findByDepartmentAndYearAndSemesterOrderByName(String department, Integer year, Semester semester);
    Optional<ClassGroup> findByNameAndDepartmentAndYearAndSemester(String name, String department, Integer year, Semester semester);
}
