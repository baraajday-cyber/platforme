package com.unigate.academic.repository;

import com.unigate.academic.domain.entity.GradeConfig;
import com.unigate.academic.domain.enums.Semester;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface GradeConfigRepository extends JpaRepository<GradeConfig, Long> {
    List<GradeConfig> findByDepartmentAndYearAndSemesterAndActiveTrueOrderByModuleNameAscSubjectNameAsc(String department, Integer year, Semester semester);
    List<GradeConfig> findByModuleIdAndActiveTrueOrderBySubjectNameAsc(Long moduleId);
    Optional<GradeConfig> findByDepartmentAndYearAndSemesterAndSubjectIdAndActiveTrue(String department, Integer year, Semester semester, Long subjectId);
    Optional<GradeConfig> findByDepartmentAndYearAndSemesterAndSubjectIdAndModuleId(String department, Integer year, Semester semester, Long subjectId, Long moduleId);
}
