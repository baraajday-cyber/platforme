package com.unigate.academic.dto.teacher;

import com.unigate.academic.dto.timetable.CourseResponse;

import java.util.List;

public record TeacherUserResponse(
        Long id,
        String username,
        String fullName,
        String email,
        boolean enabled,
        List<CourseResponse> courses
) {
}
