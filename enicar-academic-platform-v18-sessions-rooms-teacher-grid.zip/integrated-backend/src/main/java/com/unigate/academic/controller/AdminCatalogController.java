package com.unigate.academic.controller;

import com.unigate.academic.domain.enums.Semester;
import com.unigate.academic.dto.common.IdResponse;
import com.unigate.academic.dto.timetable.AcademicModuleRequest;
import com.unigate.academic.dto.timetable.AcademicModuleResponse;
import com.unigate.academic.dto.timetable.ClassGroupRequest;
import com.unigate.academic.dto.timetable.ClassGroupResponse;
import com.unigate.academic.dto.timetable.CourseRequest;
import com.unigate.academic.dto.timetable.CourseResponse;
import com.unigate.academic.dto.timetable.StudentAssignmentRequest;
import com.unigate.academic.service.AcademicCatalogService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/admin/academic/catalog")
@PreAuthorize("hasAnyRole('DEPARTMENT_ADMIN','SUPER_ADMIN')")
public class AdminCatalogController {

    private final AcademicCatalogService catalogService;

    @PostMapping("/class-groups")
    @ResponseStatus(HttpStatus.CREATED)
    public ClassGroupResponse createClassGroup(@Valid @RequestBody ClassGroupRequest request) {
        return catalogService.createClassGroup(request);
    }

    @PutMapping("/class-groups/{id}")
    public ClassGroupResponse updateClassGroup(@PathVariable Long id, @Valid @RequestBody ClassGroupRequest request) {
        return catalogService.updateClassGroup(id, request);
    }

    @GetMapping("/class-groups")
    public List<ClassGroupResponse> listClassGroups(
            @RequestParam @NotBlank String department,
            @RequestParam @NotNull Integer year,
            @RequestParam @NotNull Semester semester
    ) {
        return catalogService.listClassGroups(department, year, semester);
    }

    @DeleteMapping("/class-groups/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteClassGroup(@PathVariable Long id) {
        catalogService.deleteClassGroup(id);
    }

    @PostMapping("/class-groups/assign-student")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void assignStudent(@Valid @RequestBody StudentAssignmentRequest request) {
        catalogService.assignStudentToClass(request);
    }

    @PostMapping("/courses")
    @ResponseStatus(HttpStatus.CREATED)
    public CourseResponse createCourse(@Valid @RequestBody CourseRequest request) {
        return catalogService.createCourse(request);
    }

    @PutMapping("/courses/{id}")
    public CourseResponse updateCourse(@PathVariable Long id, @Valid @RequestBody CourseRequest request) {
        return catalogService.updateCourse(id, request);
    }

    @GetMapping("/courses")
    public List<CourseResponse> listCourses(@RequestParam @NotBlank String department) {
        return catalogService.listCourses(department);
    }

    @PostMapping("/modules")
    @ResponseStatus(HttpStatus.CREATED)
    public AcademicModuleResponse createModule(@Valid @RequestBody AcademicModuleRequest request) {
        return catalogService.createAcademicModule(request);
    }

    @PutMapping("/modules/{id}")
    public AcademicModuleResponse updateModule(@PathVariable Long id, @Valid @RequestBody AcademicModuleRequest request) {
        return catalogService.updateAcademicModule(id, request);
    }

    @GetMapping("/modules")
    public List<AcademicModuleResponse> listModules(
            @RequestParam @NotBlank String department,
            @RequestParam @NotNull Integer year,
            @RequestParam @NotNull Semester semester
    ) {
        return catalogService.listAcademicModules(department, year, semester);
    }
}
