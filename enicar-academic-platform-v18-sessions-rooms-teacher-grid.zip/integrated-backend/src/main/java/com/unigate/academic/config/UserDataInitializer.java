package com.unigate.academic.config;

import com.unigate.academic.domain.entity.ClassGroup;
import com.unigate.academic.domain.enums.Semester;
import com.unigate.academic.repository.ClassGroupRepository;
import com.unigate.academic.repository.CourseRepository;
import com.unigate.academic.domain.entity.AcademicUser;
import com.unigate.academic.domain.entity.Course;
import com.unigate.academic.service.StudentManagementService;
import com.unigate.academic.service.TeacherManagementService;

import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;

@Configuration
@RequiredArgsConstructor
public class UserDataInitializer {

    private static final String DEPARTMENT = "Informatique";

    @Bean
    @Order(40)
    CommandLineRunner seedAcademicUsers(StudentManagementService studentManagementService,
                                         TeacherManagementService teacherManagementService,
                                         ClassGroupRepository classGroupRepository,
                                         CourseRepository courseRepository) {
        return args -> {
            ClassGroup g1A = group(classGroupRepository, "Ing Inf 1A", 1, Semester.S2);
            ClassGroup g1B = group(classGroupRepository, "Ing Inf 1B", 1, Semester.S2);
            ClassGroup g1C = group(classGroupRepository, "Ing Inf 1C", 1, Semester.S2);
            ClassGroup g1D = group(classGroupRepository, "Ing Inf 1D", 1, Semester.S2);
            ClassGroup g2A = group(classGroupRepository, "Ing Inf 2A", 2, Semester.S4);
            ClassGroup g2B = group(classGroupRepository, "Ing Inf 2B", 2, Semester.S4);
            ClassGroup g2C = group(classGroupRepository, "Ing Inf 2C", 2, Semester.S4);
            ClassGroup g2D = group(classGroupRepository, "Ing Inf 2D", 2, Semester.S4);

            seedStudent(studentManagementService, "student", "student", "Etudiant Demo", 1L, "ETU-001", g2A, 2, Semester.S4);
            seedStudent(studentManagementService, "student2", "student2", "Etudiant Groupe B", 2L, "ETU-002", g2B, 2, Semester.S4);

            seedStudent(studentManagementService, "amina1a", "amina1a", "Amina Ben Ali", 11L, "1A-011", g1A, 1, Semester.S2);
            seedStudent(studentManagementService, "ines1b", "ines1b", "Ines Trabelsi", 12L, "1B-012", g1B, 1, Semester.S2);
            seedStudent(studentManagementService, "malek1c", "malek1c", "Malek Hachicha", 13L, "1C-013", g1C, 1, Semester.S2);
            seedStudent(studentManagementService, "yasmine1d", "yasmine1d", "Yasmine Saidi", 14L, "1D-014", g1D, 1, Semester.S2);
            seedStudent(studentManagementService, "nour2c", "nour2c", "Nour Gharbi", 23L, "2C-023", g2C, 2, Semester.S4);
            seedStudent(studentManagementService, "aziz2d", "aziz2d", "Aziz Kallel", 24L, "2D-024", g2D, 2, Semester.S4);

            studentManagementService.seedUser("demo", "demo", "Demo ENI Carthage", "STUDENT,DEPARTMENT_ADMIN,SUPER_ADMIN", 100L,
                    "DEM-100", "demo@enicar.ucar.tn", g1A, 1, Semester.S2);
            studentManagementService.seedUser("admin", "admin", "Administration Scolarite", "DEPARTMENT_ADMIN,SUPER_ADMIN", null,
                    "ADM-200", "scolarite@enicar.ucar.tn", null, null, null);
            AcademicUser teacher = studentManagementService.seedUser("teacher", "teacher", "Enseignant Demo", "TEACHER", null,
                    "ENS-300", "teacher@enicar.ucar.tn", null, null, null);
            List<String> defaultTeacherNames = List.of(
                    "Intelligence Artificielle", "Intelli.Artificielle",
                    "Théorie des Langages et Compilation", "TLA & Compilation",
                    "Programmation et administration Système et Réseaux", "Prog. Sys. & Rx",
                    "Développement mobile", "Développement Mobile",
                    "Syst. embarqués", "Plateformes de Dev.", "Routage des Rx",
                    "Analyse des Données", "Business english", "Management de Projet",
                    "Sécu. Informatique", "Comm. en Entreprise", "Admin. Sys. et Rx."
            );
            List<Long> defaultTeacherCourses = courseRepository.findByDepartmentOrderByName(DEPARTMENT).stream()
                    .filter(course -> defaultTeacherNames.stream().anyMatch(name -> name.equalsIgnoreCase(course.getName())))
                    .map(Course::getId)
                    .toList();
            teacherManagementService.assignCourses(teacher, defaultTeacherCourses);
        };
    }

    private void seedStudent(StudentManagementService service, String username, String password, String name, Long id, String code,
                             ClassGroup group, Integer year, Semester semester) {
        service.seedUser(username, password, name, "STUDENT", id, code, username + "@enicar.ucar.tn", group, year, semester);
    }

    private ClassGroup group(ClassGroupRepository repository, String name, Integer year, Semester semester) {
        return repository.findByNameAndDepartmentAndYearAndSemester(name, DEPARTMENT, year, semester).orElse(null);
    }
}
