package com.unigate.academic.controller;

import com.unigate.academic.domain.enums.Semester;
import com.unigate.academic.dto.grade.GradeSimulationRequest;
import com.unigate.academic.dto.grade.GradeSimulationResponse;
import com.unigate.academic.dto.grade.StudentResultsResponse;
import com.unigate.academic.security.CurrentUserService;
import com.unigate.academic.service.GradeCalculationService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/student/academic/grades")
@PreAuthorize("hasRole('STUDENT')")
public class StudentGradeController {

    private final GradeCalculationService gradeCalculationService;
    private final CurrentUserService currentUserService;

    @GetMapping("/results")
    public StudentResultsResponse results(
            @RequestParam(required = false) Long studentId,
            @RequestParam @NotBlank String department,
            @RequestParam @NotNull Integer year,
            @RequestParam @NotNull Semester semester
    ) {
        Long resolvedStudentId = currentUserService.resolveStudentId(studentId);
        return gradeCalculationService.getStudentResults(resolvedStudentId, department, year, semester);
    }

    @PostMapping("/simulate")
    public GradeSimulationResponse simulate(
            @RequestParam(required = false) Long studentId,
            @Valid @RequestBody GradeSimulationRequest request
    ) {
        Long resolvedStudentId = currentUserService.resolveStudentId(studentId);
        return gradeCalculationService.simulate(resolvedStudentId, request);
    }
}
