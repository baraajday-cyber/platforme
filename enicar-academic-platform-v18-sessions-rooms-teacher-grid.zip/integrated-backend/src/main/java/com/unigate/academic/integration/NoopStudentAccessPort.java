package com.unigate.academic.integration;

import org.springframework.stereotype.Component;

@Component
public class NoopStudentAccessPort implements StudentAccessPort {
    @Override
    public void assertStudentIsEnrolled(Long studentId) {
        // Module 1 doit remplacer ce bean par une verification réelle du statut ENROLLED.
    }
}
