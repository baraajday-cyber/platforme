package com.unigate.academic.domain.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RequiredExamGrade {
    private Long subjectId;
    private String subjectName;
    private BigDecimal requiredForSubject;
    private BigDecimal requiredForModule;
    private boolean impossibleForSubject;
    private boolean impossibleForModule;
    private String status;
    private String message;
}
