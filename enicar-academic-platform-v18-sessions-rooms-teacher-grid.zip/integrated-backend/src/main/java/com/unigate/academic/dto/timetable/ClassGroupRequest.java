package com.unigate.academic.dto.timetable;

import com.unigate.academic.domain.enums.Semester;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record ClassGroupRequest(
        @NotBlank @Size(max = 80) String name,
        @NotBlank @Size(max = 80) String department,
        @NotNull @Min(1) @Max(6) Integer year,
        @NotNull Semester semester,
        @Size(max = 500) String description
) {
}
