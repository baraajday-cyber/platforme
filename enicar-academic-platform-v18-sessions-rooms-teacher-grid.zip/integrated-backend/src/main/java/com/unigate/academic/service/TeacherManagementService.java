package com.unigate.academic.service;

import com.unigate.academic.common.exception.ConflictException;
import com.unigate.academic.common.exception.ForbiddenAcademicAccessException;
import com.unigate.academic.common.exception.ResourceNotFoundException;
import com.unigate.academic.domain.entity.AcademicUser;
import com.unigate.academic.domain.entity.Course;
import com.unigate.academic.domain.entity.TeacherCourseAssignment;
import com.unigate.academic.dto.teacher.TeacherCreateRequest;
import com.unigate.academic.dto.teacher.TeacherUpdateRequest;
import com.unigate.academic.dto.teacher.TeacherUserResponse;
import com.unigate.academic.mapper.AcademicMapper;
import com.unigate.academic.repository.AcademicUserRepository;
import com.unigate.academic.repository.CourseRepository;
import com.unigate.academic.repository.TeacherCourseAssignmentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class TeacherManagementService {

    private final AcademicUserRepository userRepository;
    private final CourseRepository courseRepository;
    private final TeacherCourseAssignmentRepository assignmentRepository;
    private final PasswordEncoder passwordEncoder;
    private final AcademicMapper mapper;

    @Transactional(readOnly = true)
    public List<TeacherUserResponse> listTeachers() {
        return userRepository.findByRolesCsvContainingIgnoreCaseOrderByDisplayNameAsc("TEACHER")
                .stream()
                .map(this::toResponse)
                .toList();
    }

    public TeacherUserResponse createTeacher(TeacherCreateRequest request) {
        String username = normalizeUsername(request.username());
        if (userRepository.existsByUsernameIgnoreCase(username)) {
            throw new ConflictException("Cet identifiant existe deja: " + username);
        }
        AcademicUser teacher = AcademicUser.builder()
                .username(username)
                .passwordHash(passwordEncoder.encode(request.password()))
                .displayName(request.fullName().trim())
                .email(clean(request.email()))
                .studentCode("ENS-" + username.toUpperCase(Locale.ROOT))
                .rolesCsv("TEACHER")
                .enabled(request.enabled() == null || request.enabled())
                .enrolled(false)
                .build();
        AcademicUser saved = userRepository.save(teacher);
        replaceCourses(saved, request.courseIds());
        return toResponse(saved);
    }

    public TeacherUserResponse updateTeacher(Long teacherUserId, TeacherUpdateRequest request) {
        AcademicUser teacher = teacherById(teacherUserId);
        teacher.setDisplayName(request.fullName().trim());
        teacher.setEmail(clean(request.email()));
        if (request.enabled() != null) {
            teacher.setEnabled(request.enabled());
        }
        replaceCourses(teacher, request.courseIds());
        return toResponse(teacher);
    }

    public void assignCourses(AcademicUser teacher, List<Long> courseIds) {
        replaceCourses(teacher, courseIds);
    }

    @Transactional(readOnly = true)
    public List<Long> assignedCourseIdsForUsername(String username) {
        AcademicUser teacher = teacherByUsername(username);
        return assignmentRepository.findActiveCourseIdsByTeacherId(teacher.getId());
    }

    @Transactional(readOnly = true)
    public Set<String> assignedCourseNamesLowerForUsername(String username) {
        AcademicUser teacher = teacherByUsername(username);
        return assignmentRepository.findActiveByTeacherIdOrderByCourseName(teacher.getId())
                .stream()
                .map(TeacherCourseAssignment::getCourse)
                .map(Course::getName)
                .filter(name -> name != null && !name.isBlank())
                .map(name -> name.trim().toLowerCase(Locale.ROOT))
                .collect(Collectors.toSet());
    }

    @Transactional(readOnly = true)
    public boolean canTeach(String username, Long courseId) {
        AcademicUser user = userRepository.findByUsernameIgnoreCase(normalizeUsername(username))
                .orElseThrow(() -> new ResourceNotFoundException("Utilisateur introuvable: " + username));
        String roles = user.getRolesCsv() == null ? "" : user.getRolesCsv().toUpperCase(Locale.ROOT);
        if (roles.contains("DEPARTMENT_ADMIN") || roles.contains("SUPER_ADMIN")) {
            return true;
        }
        if (!roles.contains("TEACHER")) {
            return false;
        }
        return assignmentRepository.findActiveCourseIdsByTeacherId(user.getId()).contains(courseId);
    }

    public void assertCanTeach(String username, Long courseId) {
        if (!canTeach(username, courseId)) {
            throw new ForbiddenAcademicAccessException("Cet enseignant n'est pas affecte a cette matiere");
        }
    }

    @Transactional(readOnly = true)
    public boolean isTeacherOnly(String username) {
        AcademicUser user = userRepository.findByUsernameIgnoreCase(normalizeUsername(username))
                .orElseThrow(() -> new ResourceNotFoundException("Utilisateur introuvable: " + username));
        String roles = user.getRolesCsv() == null ? "" : user.getRolesCsv().toUpperCase(Locale.ROOT);
        return roles.contains("TEACHER") && !roles.contains("DEPARTMENT_ADMIN") && !roles.contains("SUPER_ADMIN");
    }

    @Transactional(readOnly = true)
    public AcademicUser teacherByUsername(String username) {
        AcademicUser user = userRepository.findByUsernameIgnoreCase(normalizeUsername(username))
                .orElseThrow(() -> new ResourceNotFoundException("Enseignant introuvable: " + username));
        if (user.getRolesCsv() == null || !user.getRolesCsv().toUpperCase(Locale.ROOT).contains("TEACHER")) {
            throw new ResourceNotFoundException("Enseignant introuvable: " + username);
        }
        return user;
    }

    private AcademicUser teacherById(Long id) {
        AcademicUser user = userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Enseignant introuvable: " + id));
        if (user.getRolesCsv() == null || !user.getRolesCsv().toUpperCase(Locale.ROOT).contains("TEACHER")) {
            throw new ResourceNotFoundException("Enseignant introuvable: " + id);
        }
        return user;
    }

    private void replaceCourses(AcademicUser teacher, List<Long> courseIds) {
        Set<Long> requested = new HashSet<>(courseIds == null ? List.of() : courseIds);
        List<TeacherCourseAssignment> current = assignmentRepository.findActiveByTeacherIdOrderByCourseName(teacher.getId());
        for (TeacherCourseAssignment assignment : current) {
            if (!requested.contains(assignment.getCourse().getId())) {
                assignment.setActive(false);
            }
        }
        for (Long courseId : requested) {
            Course course = courseRepository.findById(courseId)
                    .orElseThrow(() -> new ResourceNotFoundException("Matiere introuvable: " + courseId));
            TeacherCourseAssignment assignment = assignmentRepository.findByTeacherIdAndCourseId(teacher.getId(), courseId)
                    .orElseGet(() -> TeacherCourseAssignment.builder().teacher(teacher).course(course).build());
            assignment.setActive(true);
            assignmentRepository.save(assignment);
        }
    }

    private TeacherUserResponse toResponse(AcademicUser teacher) {
        return new TeacherUserResponse(
                teacher.getId(),
                teacher.getUsername(),
                teacher.getDisplayName(),
                teacher.getEmail(),
                teacher.isEnabled(),
                assignmentRepository.findActiveByTeacherIdOrderByCourseName(teacher.getId())
                        .stream()
                        .map(TeacherCourseAssignment::getCourse)
                        .map(mapper::toCourseResponse)
                        .toList()
        );
    }

    private String normalizeUsername(String username) {
        return username == null ? "" : username.trim().toLowerCase(Locale.ROOT);
    }

    private String clean(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }
}
