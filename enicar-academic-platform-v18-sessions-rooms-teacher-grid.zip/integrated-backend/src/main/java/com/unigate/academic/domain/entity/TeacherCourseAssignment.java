package com.unigate.academic.domain.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(
        name = "teacher_course_assignments",
        uniqueConstraints = @UniqueConstraint(name = "uk_teacher_course", columnNames = {"teacher_user_id", "course_id"}),
        indexes = {
                @Index(name = "idx_teacher_course_teacher", columnList = "teacher_user_id"),
                @Index(name = "idx_teacher_course_course", columnList = "course_id")
        }
)
public class TeacherCourseAssignment extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "teacher_user_id", nullable = false)
    private AcademicUser teacher;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "course_id", nullable = false)
    private Course course;

    @Column(nullable = false)
    @Builder.Default
    private boolean active = true;
}
