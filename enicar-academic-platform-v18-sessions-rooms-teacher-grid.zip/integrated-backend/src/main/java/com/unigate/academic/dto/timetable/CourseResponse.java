package com.unigate.academic.dto.timetable;

import java.math.BigDecimal;

public record CourseResponse(
        Long id,
        String name,
        String department,
        String code,
        BigDecimal defaultCoefficient,
        Integer defaultCredits
) {
}
