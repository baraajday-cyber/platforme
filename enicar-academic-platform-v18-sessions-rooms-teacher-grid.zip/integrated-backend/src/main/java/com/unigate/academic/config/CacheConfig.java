package com.unigate.academic.config;

import org.springframework.cache.CacheManager;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CacheConfig {

    public static final String WEEKLY_TIMETABLE_BY_CLASS_GROUP = "weeklyTimetableByClassGroup";
    public static final String GRADE_CONFIGS = "gradeConfigs";

    @Bean
    public CacheManager cacheManager() {
        return new ConcurrentMapCacheManager(
                WEEKLY_TIMETABLE_BY_CLASS_GROUP,
                GRADE_CONFIGS
        );
    }
}
