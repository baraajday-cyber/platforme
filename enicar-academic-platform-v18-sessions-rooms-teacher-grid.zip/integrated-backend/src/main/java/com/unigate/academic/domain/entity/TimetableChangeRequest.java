package com.unigate.academic.domain.entity;

import com.unigate.academic.domain.enums.TimetableChangeRequestStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.DayOfWeek;
import java.time.Instant;
import java.time.LocalTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(
        name = "timetable_change_requests",
        indexes = {
                @Index(name = "idx_tcr_status", columnList = "status"),
                @Index(name = "idx_tcr_teacher", columnList = "teacher_user_id"),
                @Index(name = "idx_tcr_slot", columnList = "slot_id")
        }
)
public class TimetableChangeRequest extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "teacher_user_id", nullable = false)
    private AcademicUser teacher;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "slot_id", nullable = false)
    private TimetableSlot slot;

    @Enumerated(EnumType.STRING)
    @Column(name = "requested_day_of_week", nullable = false, length = 20)
    private DayOfWeek requestedDayOfWeek;

    @Column(name = "requested_start_time", nullable = false)
    private LocalTime requestedStartTime;

    @Column(name = "requested_end_time", nullable = false)
    private LocalTime requestedEndTime;

    @Column(name = "requested_room", nullable = false, length = 80)
    private String requestedRoom;

    @Column(length = 700)
    private String reason;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    @Builder.Default
    private TimetableChangeRequestStatus status = TimetableChangeRequestStatus.PENDING;

    @Column(name = "admin_response", length = 700)
    private String adminResponse;

    @Column(name = "decided_at")
    private Instant decidedAt;
}
