package com.unigate.academic.service;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.unigate.academic.common.exception.BusinessRuleException;
import com.unigate.academic.domain.enums.Semester;
import com.unigate.academic.dto.timetable.TimetableSlotResponse;
import com.unigate.academic.dto.timetable.WeeklyTimetableResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.time.DayOfWeek;
import java.util.List;

@Service
@RequiredArgsConstructor
public class TimetablePdfExportService {

    private final TimetableService timetableService;

    public byte[] exportStudentTimetable(Long studentId, Integer year, Semester semester) {
        WeeklyTimetableResponse timetable = timetableService.getStudentTimetable(studentId, year, semester);
        return render(timetable);
    }

    public byte[] exportClassGroupTimetable(Long classGroupId) {
        WeeklyTimetableResponse timetable = timetableService.getWeeklyByClassGroup(classGroupId);
        return render(timetable);
    }

    private byte[] render(WeeklyTimetableResponse timetable) {
        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            Document document = new Document(PageSize.A4.rotate(), 24, 24, 24, 24);
            PdfWriter.getInstance(document, out);
            document.open();

            Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16);
            Font subtitleFont = FontFactory.getFont(FontFactory.HELVETICA, 10);
            Font headerFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10);
            Font cellFont = FontFactory.getFont(FontFactory.HELVETICA, 9);

            Paragraph title = new Paragraph("Emploi du temps - " + timetable.classGroupName(), titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);
            Paragraph subtitle = new Paragraph(timetable.department() + " | Annee " + timetable.year() + " | " + timetable.semester(), subtitleFont);
            subtitle.setAlignment(Element.ALIGN_CENTER);
            subtitle.setSpacingAfter(12);
            document.add(subtitle);

            PdfPTable table = new PdfPTable(6);
            table.setWidthPercentage(100);
            table.setWidths(new float[]{1, 1, 1, 1, 1, 1});

            for (DayOfWeek day : orderedDays()) {
                PdfPCell header = new PdfPCell(new Phrase(label(day), headerFont));
                header.setHorizontalAlignment(Element.ALIGN_CENTER);
                header.setPadding(6);
                table.addCell(header);
            }

            for (DayOfWeek day : orderedDays()) {
                PdfPCell cell = new PdfPCell(new Phrase(formatSlots(timetable.slotsByDay().getOrDefault(day, List.of())), cellFont));
                cell.setPadding(6);
                cell.setMinimumHeight(220);
                table.addCell(cell);
            }

            document.add(table);
            document.close();
            return out.toByteArray();
        } catch (DocumentException | java.io.IOException e) {
            throw new BusinessRuleException("Unable to export timetable PDF: " + e.getMessage());
        }
    }

    private List<DayOfWeek> orderedDays() {
        return List.of(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY, DayOfWeek.SATURDAY);
    }

    private String label(DayOfWeek day) {
        return switch (day) {
            case MONDAY -> "Lundi";
            case TUESDAY -> "Mardi";
            case WEDNESDAY -> "Mercredi";
            case THURSDAY -> "Jeudi";
            case FRIDAY -> "Vendredi";
            case SATURDAY -> "Samedi";
            default -> day.name();
        };
    }

    private String formatSlots(List<TimetableSlotResponse> slots) {
        if (slots == null || slots.isEmpty()) {
            return "Aucun cours";
        }
        StringBuilder builder = new StringBuilder();
        for (TimetableSlotResponse slot : slots) {
            builder.append(slot.startTime()).append(" - ").append(slot.endTime()).append('\n')
                    .append(slot.courseName()).append('\n')
                    .append("Salle: ").append(slot.room()).append('\n')
                    .append("Prof: ").append(slot.professorName() == null ? "-" : slot.professorName());
            if (slot.status() != null && "CANCELLED".equals(slot.status().name())) {
                builder.append('\n').append("ANNULE: ").append(slot.changeReason() == null ? "" : slot.changeReason());
            }
            builder.append("\n\n");
        }
        return builder.toString().trim();
    }
}
