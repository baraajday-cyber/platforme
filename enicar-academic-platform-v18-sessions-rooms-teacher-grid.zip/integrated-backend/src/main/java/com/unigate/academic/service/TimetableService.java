package com.unigate.academic.service;

import com.unigate.academic.common.exception.BusinessRuleException;
import com.unigate.academic.common.exception.ConflictException;
import com.unigate.academic.common.exception.ResourceNotFoundException;
import com.unigate.academic.config.CacheConfig;
import com.unigate.academic.domain.entity.ClassGroup;
import com.unigate.academic.domain.entity.Course;
import com.unigate.academic.domain.entity.StudentClassAssignment;
import com.unigate.academic.domain.entity.TimetableSlot;
import com.unigate.academic.domain.entity.AcademicUser;
import com.unigate.academic.domain.enums.Semester;
import com.unigate.academic.domain.enums.SlotStatus;
import com.unigate.academic.dto.timetable.DuplicateTimetableRequest;
import com.unigate.academic.dto.timetable.TimetableSlotMoveRequest;
import com.unigate.academic.dto.timetable.TimetableSlotRequest;
import com.unigate.academic.dto.timetable.TimetableSlotResponse;
import com.unigate.academic.dto.timetable.TimetableSlotUpdateRequest;
import com.unigate.academic.dto.timetable.RoomAvailabilityResponse;
import com.unigate.academic.dto.timetable.WeeklyTimetableResponse;
import com.unigate.academic.integration.AcademicNotificationPort;
import com.unigate.academic.integration.StudentAccessPort;
import com.unigate.academic.mapper.AcademicMapper;
import com.unigate.academic.repository.ClassGroupRepository;
import com.unigate.academic.repository.CourseRepository;
import com.unigate.academic.repository.StudentClassAssignmentRepository;
import com.unigate.academic.repository.TimetableSlotRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class TimetableService {

    private final TimetableSlotRepository timetableSlotRepository;
    private final ClassGroupRepository classGroupRepository;
    private final CourseRepository courseRepository;
    private final StudentClassAssignmentRepository assignmentRepository;
    private final StudentAccessPort studentAccessPort;
    private final AcademicNotificationPort notificationPort;
    private final AcademicMapper mapper;
    private final TeacherManagementService teacherManagementService;

    @Value("${unigate.academic.min-hour:08:00}")
    private LocalTime minHour;

    @Value("${unigate.academic.max-hour:18:00}")
    private LocalTime maxHour;

    private static final List<String> ROOM_CATALOG = List.of(
            "S21", "S22", "S23", "S24", "S25", "S26", "S27", "S30", "S31", "S32", "S33", "S34", "S36",
            "SL12", "SL27", "SL31", "SL33", "SL36", "SL MAC", "Amphi A", "Amphi B"
    );

    private static final Map<LocalTime, LocalTime> ALLOWED_SESSIONS = Map.of(
            LocalTime.of(8, 30), LocalTime.of(10, 0),
            LocalTime.of(10, 10), LocalTime.of(11, 40),
            LocalTime.of(12, 30), LocalTime.of(14, 0),
            LocalTime.of(14, 10), LocalTime.of(15, 40),
            LocalTime.of(15, 50), LocalTime.of(17, 20)
    );

    @CacheEvict(cacheNames = CacheConfig.WEEKLY_TIMETABLE_BY_CLASS_GROUP, allEntries = true)
    public TimetableSlotResponse createSlot(TimetableSlotRequest request) {
        ClassGroup group = getClassGroupOrThrow(request.classGroupId());
        Course course = getCourseOrThrow(request.courseId());
        validateSlot(request.dayOfWeek(), request.startTime(), request.endTime());
        ensureNoOverlap(group.getId(), request.dayOfWeek(), request.startTime(), request.endTime(), request.room(), request.professorId(), null);

        TimetableSlot slot = TimetableSlot.builder()
                .classGroup(group)
                .course(course)
                .dayOfWeek(request.dayOfWeek())
                .startTime(request.startTime())
                .endTime(request.endTime())
                .room(request.room().trim())
                .professorId(request.professorId())
                .professorName(request.professorName())
                .status(SlotStatus.ACTIVE)
                .build();
        TimetableSlot saved = timetableSlotRepository.save(slot);
        notificationPort.notifyTimetableChanged(group.getId(), saved, "CREATED");
        return mapper.toTimetableSlotResponse(saved);
    }

    @CacheEvict(cacheNames = CacheConfig.WEEKLY_TIMETABLE_BY_CLASS_GROUP, allEntries = true)
    public TimetableSlotResponse updateSlot(Long id, TimetableSlotUpdateRequest request) {
        TimetableSlot slot = getSlotOrThrow(id);
        Course course = getCourseOrThrow(request.courseId());
        validateSlot(request.dayOfWeek(), request.startTime(), request.endTime());
        ensureNoOverlap(slot.getClassGroup().getId(), request.dayOfWeek(), request.startTime(), request.endTime(), request.room(), request.professorId(), id);

        slot.setCourse(course);
        slot.setDayOfWeek(request.dayOfWeek());
        slot.setStartTime(request.startTime());
        slot.setEndTime(request.endTime());
        slot.setRoom(request.room().trim());
        slot.setProfessorId(request.professorId());
        slot.setProfessorName(request.professorName());
        slot.setStatus(SlotStatus.ACTIVE);
        slot.setChangeReason(request.changeReason());
        notificationPort.notifyTimetableChanged(slot.getClassGroup().getId(), slot, "UPDATED");
        return mapper.toTimetableSlotResponse(slot);
    }

    @CacheEvict(cacheNames = CacheConfig.WEEKLY_TIMETABLE_BY_CLASS_GROUP, allEntries = true)
    public TimetableSlotResponse cancelSlot(Long id, String reason) {
        TimetableSlot slot = getSlotOrThrow(id);
        slot.setStatus(SlotStatus.CANCELLED);
        slot.setChangeReason(reason);
        notificationPort.notifyTimetableChanged(slot.getClassGroup().getId(), slot, "CANCELLED");
        return mapper.toTimetableSlotResponse(slot);
    }

    @CacheEvict(cacheNames = CacheConfig.WEEKLY_TIMETABLE_BY_CLASS_GROUP, allEntries = true)
    public TimetableSlotResponse moveSlot(Long id, TimetableSlotMoveRequest request) {
        TimetableSlot slot = getSlotOrThrow(id);
        validateSlot(request.dayOfWeek(), request.startTime(), request.endTime());

        Long professorId = request.professorId() != null ? request.professorId() : slot.getProfessorId();
        String professorName = request.professorName() != null && !request.professorName().isBlank()
                ? request.professorName().trim()
                : slot.getProfessorName();

        ensureNoOverlap(
                slot.getClassGroup().getId(),
                request.dayOfWeek(),
                request.startTime(),
                request.endTime(),
                request.room(),
                professorId,
                id
        );

        slot.setDayOfWeek(request.dayOfWeek());
        slot.setStartTime(request.startTime());
        slot.setEndTime(request.endTime());
        slot.setRoom(request.room().trim());
        slot.setProfessorId(professorId);
        slot.setProfessorName(professorName);
        slot.setStatus(SlotStatus.ACTIVE);
        slot.setChangeReason(request.changeReason() == null || request.changeReason().isBlank()
                ? "Deplacement manuel avec controle de disponibilite salle"
                : request.changeReason().trim());
        notificationPort.notifyTimetableChanged(slot.getClassGroup().getId(), slot, "MOVED");
        return mapper.toTimetableSlotResponse(slot);
    }


    @Transactional(readOnly = true)
    public void validateMoveCandidate(Long slotId, TimetableSlotMoveRequest request) {
        TimetableSlot slot = getSlotOrThrow(slotId);
        validateSlot(request.dayOfWeek(), request.startTime(), request.endTime());
        Long professorId = request.professorId() != null ? request.professorId() : slot.getProfessorId();
        ensureNoOverlap(slot.getClassGroup().getId(), request.dayOfWeek(), request.startTime(), request.endTime(), request.room(), professorId, slotId);
    }

    @Transactional(readOnly = true)
    public TimetableSlotResponse getSlot(Long id) {
        return mapper.toTimetableSlotResponse(getSlotOrThrow(id));
    }

    @Transactional(readOnly = true)
    public RoomAvailabilityResponse checkRoomAvailability(String room, DayOfWeek day, LocalTime start, LocalTime end, Long excludedSlotId) {
        validateSlot(day, start, end);
        String normalizedRoom = normalizeRoom(room);
        boolean busy = isRoomBusy(normalizedRoom, day, start, end, excludedSlotId);
        String message = busy
                ? "Salle indisponible sur ce creneau"
                : "Salle libre sur ce creneau";
        return new RoomAvailabilityResponse(!busy, normalizedRoom, day, start, end, message);
    }

    @Transactional(readOnly = true)
    public List<String> listRooms() {
        TreeSet<String> rooms = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        rooms.addAll(ROOM_CATALOG);
        for (String room : timetableSlotRepository.findDistinctActiveRooms()) {
            rooms.addAll(splitRooms(room));
        }
        return new ArrayList<>(rooms);
    }

    @Transactional(readOnly = true)
    public List<String> listAvailableRooms(DayOfWeek day, LocalTime start, LocalTime end, Long excludedSlotId) {
        validateSlot(day, start, end);
        return listRooms().stream()
                .filter(room -> !isRoomBusy(room, day, start, end, excludedSlotId))
                .toList();
    }

    @CacheEvict(cacheNames = CacheConfig.WEEKLY_TIMETABLE_BY_CLASS_GROUP, allEntries = true)
    public void deleteSlot(Long id) {
        TimetableSlot slot = getSlotOrThrow(id);
        Long groupId = slot.getClassGroup().getId();
        timetableSlotRepository.delete(slot);
        notificationPort.notifyTimetableChanged(groupId, slot, "DELETED");
    }

    @CacheEvict(cacheNames = CacheConfig.WEEKLY_TIMETABLE_BY_CLASS_GROUP, allEntries = true)
    public List<TimetableSlotResponse> duplicateTimetable(DuplicateTimetableRequest request) {
        ClassGroup source = getClassGroupOrThrow(request.sourceClassGroupId());
        ClassGroup target = getClassGroupOrThrow(request.targetClassGroupId());
        if (source.getId().equals(target.getId())) {
            throw new BusinessRuleException("Source and target class groups must be different");
        }
        List<TimetableSlot> sourceSlots = timetableSlotRepository.findByClassGroupIdOrderByDayOfWeekAscStartTimeAsc(source.getId())
                .stream()
                .filter(slot -> request.copyCancelledSlots() || slot.getStatus() == SlotStatus.ACTIVE)
                .toList();

        for (TimetableSlot sourceSlot : sourceSlots) {
            ensureNoOverlap(target.getId(), sourceSlot.getDayOfWeek(), sourceSlot.getStartTime(), sourceSlot.getEndTime(), sourceSlot.getRoom(), sourceSlot.getProfessorId(), null);
        }

        List<TimetableSlot> copies = sourceSlots.stream()
                .map(slot -> TimetableSlot.builder()
                        .classGroup(target)
                        .course(slot.getCourse())
                        .dayOfWeek(slot.getDayOfWeek())
                        .startTime(slot.getStartTime())
                        .endTime(slot.getEndTime())
                        .room(slot.getRoom())
                        .professorId(slot.getProfessorId())
                        .professorName(slot.getProfessorName())
                        .status(slot.getStatus())
                        .changeReason(slot.getChangeReason())
                        .build())
                .toList();
        List<TimetableSlot> saved = timetableSlotRepository.saveAll(copies);
        saved.forEach(slot -> notificationPort.notifyTimetableChanged(target.getId(), slot, "DUPLICATED"));
        return saved.stream().map(mapper::toTimetableSlotResponse).toList();
    }

    @Transactional(readOnly = true)
    @Cacheable(cacheNames = CacheConfig.WEEKLY_TIMETABLE_BY_CLASS_GROUP, key = "#classGroupId")
    public WeeklyTimetableResponse getWeeklyByClassGroup(Long classGroupId) {
        ClassGroup group = getClassGroupOrThrow(classGroupId);
        List<TimetableSlotResponse> slots = timetableSlotRepository.findByClassGroupIdOrderByDayOfWeekAscStartTimeAsc(classGroupId)
                .stream()
                .map(mapper::toTimetableSlotResponse)
                .toList();
        return buildWeekly(group, slots);
    }

    @Transactional(readOnly = true)
    public WeeklyTimetableResponse getStudentTimetable(Long studentId, Integer year, Semester semester) {
        studentAccessPort.assertStudentIsEnrolled(studentId);
        StudentClassAssignment assignment = assignmentRepository
                .findByStudentIdAndYearAndSemesterAndActiveTrue(studentId, year, semester)
                .orElseThrow(() -> new ResourceNotFoundException("No class group assigned to student " + studentId));
        return getWeeklyByClassGroup(assignment.getClassGroup().getId());
    }

    @Transactional(readOnly = true)
    public List<TimetableSlotResponse> getTeacherSlots(String username, Integer year, Semester semester) {
        AcademicUser teacher = teacherManagementService.teacherByUsername(username);
        Set<Long> courseIds = new HashSet<>(teacherManagementService.assignedCourseIdsForUsername(username));
        Set<String> courseNamesLower = teacherManagementService.assignedCourseNamesLowerForUsername(username);
        if (courseIds.isEmpty() && courseNamesLower.isEmpty()) {
            return List.of();
        }
        return timetableSlotRepository.findByStatusAndClassGroupYearAndClassGroupSemesterOrderByDayOfWeekAscStartTimeAsc(SlotStatus.ACTIVE, year, semester)
                .stream()
                .filter(slot -> isTeacherSlot(slot, teacher.getId(), courseIds, courseNamesLower))
                .map(mapper::toTimetableSlotResponse)
                .toList();
    }

    private WeeklyTimetableResponse buildWeekly(ClassGroup group, List<TimetableSlotResponse> slots) {
        Map<DayOfWeek, List<TimetableSlotResponse>> byDay = slots.stream()
                .collect(Collectors.groupingBy(TimetableSlotResponse::dayOfWeek, () -> new EnumMap<>(DayOfWeek.class), Collectors.toList()));
        for (DayOfWeek day : List.of(DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY, DayOfWeek.SATURDAY)) {
            byDay.putIfAbsent(day, List.of());
        }
        return new WeeklyTimetableResponse(group.getId(), group.getName(), group.getDepartment(), group.getYear(), group.getSemester(), byDay);
    }

    private void validateSlot(DayOfWeek day, LocalTime start, LocalTime end) {
        if (day == DayOfWeek.SUNDAY) {
            throw new BusinessRuleException("Timetable is limited to Monday-Saturday");
        }
        if (!start.isBefore(end)) {
            throw new BusinessRuleException("Start time must be before end time");
        }
        if (start.isBefore(minHour) || end.isAfter(maxHour)) {
            throw new BusinessRuleException("Slot must be between " + minHour + " and " + maxHour);
        }
        if (!ALLOWED_SESSIONS.containsKey(start) || !ALLOWED_SESSIONS.get(start).equals(end)) {
            throw new BusinessRuleException("Choisissez un des 5 creneaux officiels de la journee");
        }
    }

    private void ensureNoOverlap(Long classGroupId, DayOfWeek day, LocalTime start, LocalTime end, String room, Long professorId, Long excludedId) {
        String normalizedRoom = normalizeRoom(room);
        if (timetableSlotRepository.existsClassGroupOverlap(classGroupId, day, start, end, excludedId)) {
            throw new ConflictException("Cette classe a deja une seance dans cette plage horaire");
        }
        if (isRoomBusy(normalizedRoom, day, start, end, excludedId)) {
            throw new ConflictException("Salle indisponible: " + normalizedRoom + " est deja occupee entre " + start + " et " + end);
        }
        if (professorId != null && timetableSlotRepository.existsProfessorOverlap(professorId, day, start, end, excludedId)) {
            throw new ConflictException("Ce professeur enseigne deja dans cette plage horaire");
        }
    }

    private boolean isTeacherSlot(TimetableSlot slot, Long teacherId, Set<Long> courseIds, Set<String> courseNamesLower) {
        Long professorId = slot.getProfessorId();
        if (professorId != null && professorId.equals(teacherId)) {
            return true;
        }
        Course course = slot.getCourse();
        if (course == null) {
            return false;
        }
        if (course.getId() != null && courseIds.contains(course.getId())) {
            return true;
        }
        String normalizedCourseName = normalizeText(course.getName());
        return courseNamesLower.stream().map(this::normalizeText).anyMatch(assigned -> assigned.equals(normalizedCourseName));
    }

    private boolean isRoomBusy(String room, DayOfWeek day, LocalTime start, LocalTime end, Long excludedId) {
        String normalizedRoom = normalizeRoom(room).toLowerCase(Locale.ROOT);
        return timetableSlotRepository.findActiveOverlappingSlots(day, start, end, excludedId).stream()
                .flatMap(slot -> splitRooms(slot.getRoom()).stream())
                .map(value -> value.toLowerCase(Locale.ROOT))
                .anyMatch(normalizedRoom::equals);
    }

    private List<String> splitRooms(String value) {
        if (value == null || value.isBlank()) {
            return List.of();
        }
        return Arrays.stream(value.split("[/,;]+"))
                .map(String::trim)
                .filter(room -> !room.isBlank())
                .distinct()
                .toList();
    }

    private String normalizeText(String value) {
        return value == null ? "" : value.trim().replaceAll("\\s+", " ").toLowerCase(Locale.ROOT);
    }

    private String normalizeRoom(String room) {
        if (room == null || room.isBlank()) {
            throw new BusinessRuleException("Room is required");
        }
        return room.trim().replaceAll("\\s+", " ");
    }

    private TimetableSlot getSlotOrThrow(Long id) {
        return timetableSlotRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Timetable slot not found: " + id));
    }

    private ClassGroup getClassGroupOrThrow(Long id) {
        return classGroupRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Class group not found: " + id));
    }

    private Course getCourseOrThrow(Long id) {
        return courseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Course not found: " + id));
    }
}
