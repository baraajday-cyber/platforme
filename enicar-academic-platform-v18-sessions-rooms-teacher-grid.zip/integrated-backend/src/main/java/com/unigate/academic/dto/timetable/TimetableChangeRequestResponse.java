package com.unigate.academic.dto.timetable;

import com.unigate.academic.domain.enums.TimetableChangeRequestStatus;

import java.time.DayOfWeek;
import java.time.Instant;
import java.time.LocalTime;

public record TimetableChangeRequestResponse(
        Long id,
        TimetableChangeRequestStatus status,
        Long teacherId,
        String teacherName,
        Long slotId,
        String courseName,
        String classGroupName,
        DayOfWeek currentDayOfWeek,
        LocalTime currentStartTime,
        LocalTime currentEndTime,
        String currentRoom,
        DayOfWeek requestedDayOfWeek,
        LocalTime requestedStartTime,
        LocalTime requestedEndTime,
        String requestedRoom,
        String reason,
        String adminResponse,
        Instant createdAt,
        Instant decidedAt
) {
}
