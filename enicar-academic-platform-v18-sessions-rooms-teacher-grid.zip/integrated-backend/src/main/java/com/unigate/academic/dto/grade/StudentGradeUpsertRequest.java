package com.unigate.academic.dto.grade;

import com.unigate.academic.domain.enums.Semester;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;

/**
 * Editable inputs only. Averages are never provided by the UI:
 * the backend recalculates subject, module and semester averages.
 */
public record StudentGradeUpsertRequest(
        @NotBlank @Size(max = 80) String department,
        @NotNull @Min(1) @Max(2) Integer year,
        @NotNull Semester semester,
        @NotNull Long subjectId,
        @DecimalMin("0.00") @DecimalMax("20.00") BigDecimal ccGrade,
        @DecimalMin("0.00") @DecimalMax("20.00") BigDecimal examGrade,
        @DecimalMin("0.00") @DecimalMax("20.00") BigDecimal tpGrade
) {
}
