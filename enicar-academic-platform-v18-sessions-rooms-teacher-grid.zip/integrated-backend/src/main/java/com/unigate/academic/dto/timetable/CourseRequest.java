package com.unigate.academic.dto.timetable;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;

public record CourseRequest(
        @NotBlank @Size(max = 120) String name,
        @NotBlank @Size(max = 80) String department,
        @Size(max = 30) String code,
        @DecimalMin("0.00") @DecimalMax("20.00") BigDecimal defaultCoefficient,
        @PositiveOrZero Integer defaultCredits
) {
}
