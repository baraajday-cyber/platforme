package com.unigate.academic.integration;

import com.unigate.academic.domain.entity.TimetableSlot;
import com.unigate.academic.dto.grade.StudentResultsResponse;

public interface AcademicNotificationPort {
    void notifyTimetableChanged(Long classGroupId, TimetableSlot slot, String action);
    void notifyGradeUpdated(Long studentId, StudentResultsResponse results);
}
