package com.unigate.academic.dto.grade;

import com.unigate.academic.domain.enums.Semester;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;

public record GradeConfigRequest(
        @NotBlank @Size(max = 80) String department,
        @NotNull @Min(1) @Max(6) Integer year,
        @NotNull Semester semester,
        @NotNull Long subjectId,
        @NotNull Long moduleId,
        @NotNull @DecimalMin("0.01") BigDecimal subjectCoefficient,
        @NotNull @DecimalMin("0.01") BigDecimal moduleCoefficient,
        @NotNull @DecimalMin("0.0000") @DecimalMax("1.0000") BigDecimal ccWeight,
        @NotNull @DecimalMin("0.0000") @DecimalMax("1.0000") BigDecimal examWeight,
        @NotNull @DecimalMin("0.0000") @DecimalMax("1.0000") BigDecimal tpWeight,
        @NotNull @Positive Integer credits
) {
}
