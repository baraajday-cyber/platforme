package com.unigate.academic.dto.student;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record StudentPasswordRequest(
        @NotBlank @Size(min = 4, max = 80) String password
) {
}
