package com.unigate.academic.domain.enums;

public enum SlotStatus {
    ACTIVE,
    CANCELLED
}
