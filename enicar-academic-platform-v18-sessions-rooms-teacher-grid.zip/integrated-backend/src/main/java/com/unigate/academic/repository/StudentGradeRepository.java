package com.unigate.academic.repository;

import com.unigate.academic.domain.entity.StudentGrade;
import com.unigate.academic.domain.enums.Semester;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface StudentGradeRepository extends JpaRepository<StudentGrade, Long> {
    Optional<StudentGrade> findByStudentIdAndYearAndSemesterAndSubjectId(Long studentId, Integer year, Semester semester, Long subjectId);
    List<StudentGrade> findByStudentIdAndDepartmentAndYearAndSemester(Long studentId, String department, Integer year, Semester semester);
    List<StudentGrade> findByStudentIdAndYearAndSemester(Long studentId, Integer year, Semester semester);
}
