package com.unigate.academic.dto.student;

import com.unigate.academic.domain.enums.Semester;

public record StudentUserResponse(
        Long id,
        Long studentId,
        String username,
        String code,
        String fullName,
        String email,
        String department,
        Integer year,
        Semester semester,
        Long classGroupId,
        String classGroupName,
        boolean enabled,
        boolean enrolled
) {
}
