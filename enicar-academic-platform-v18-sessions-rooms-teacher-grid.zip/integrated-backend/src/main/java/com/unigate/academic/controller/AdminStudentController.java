package com.unigate.academic.controller;

import com.unigate.academic.dto.student.StudentCreateRequest;
import com.unigate.academic.dto.student.StudentPasswordRequest;
import com.unigate.academic.dto.student.StudentUpdateRequest;
import com.unigate.academic.dto.student.StudentUserResponse;
import com.unigate.academic.service.StudentManagementService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/admin/academic/students")
@PreAuthorize("hasAnyRole('DEPARTMENT_ADMIN','SUPER_ADMIN')")
public class AdminStudentController {

    private final StudentManagementService studentManagementService;

    @GetMapping
    public List<StudentUserResponse> listStudents() {
        return studentManagementService.listStudents();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public StudentUserResponse createStudent(@Valid @RequestBody StudentCreateRequest request) {
        return studentManagementService.createStudent(request);
    }

    @PutMapping("/{studentId}")
    public StudentUserResponse updateStudent(@PathVariable Long studentId, @Valid @RequestBody StudentUpdateRequest request) {
        return studentManagementService.updateStudent(studentId, request);
    }

    @PutMapping("/{studentId}/password")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void changePassword(@PathVariable Long studentId, @Valid @RequestBody StudentPasswordRequest request) {
        studentManagementService.changePassword(studentId, request);
    }
}
