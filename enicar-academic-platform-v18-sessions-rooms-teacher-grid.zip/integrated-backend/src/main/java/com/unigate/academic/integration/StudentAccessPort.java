package com.unigate.academic.integration;

public interface StudentAccessPort {
    void assertStudentIsEnrolled(Long studentId);
}
