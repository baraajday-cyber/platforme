package com.unigate.academic.domain.entity;

import com.unigate.academic.domain.enums.Semester;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(
        name = "student_grades",
        uniqueConstraints = @UniqueConstraint(name = "uk_student_grade_subject", columnNames = {"student_id", "academic_year", "semester", "subject_id"}),
        indexes = @Index(name = "idx_student_grade_semester", columnList = "student_id, academic_year, semester")
)
public class StudentGrade extends BaseEntity {

    @Column(name = "student_id", nullable = false)
    private Long studentId;

    @Column(nullable = false, length = 80)
    private String department;

    @Column(name = "academic_year", nullable = false)
    private Integer year;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Semester semester;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "subject_id", nullable = false)
    private Course subject;

    @Column(name = "cc_grade", precision = 5, scale = 2)
    private BigDecimal ccGrade;

    @Column(name = "exam_grade", precision = 5, scale = 2)
    private BigDecimal examGrade;

    @Column(name = "tp_grade", precision = 5, scale = 2)
    private BigDecimal tpGrade;

    @Column(name = "subject_average", precision = 5, scale = 2)
    private BigDecimal subjectAverage;

    @Column(nullable = false)
    @Builder.Default
    private boolean validated = false;
}
