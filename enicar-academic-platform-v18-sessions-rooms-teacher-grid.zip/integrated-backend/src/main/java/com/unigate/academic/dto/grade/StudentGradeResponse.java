package com.unigate.academic.dto.grade;

import com.unigate.academic.domain.enums.Semester;

import java.math.BigDecimal;

public record StudentGradeResponse(
        Long id,
        Long studentId,
        String department,
        Integer year,
        Semester semester,
        Long subjectId,
        String subjectName,
        Long moduleId,
        String moduleName,
        BigDecimal ccGrade,
        BigDecimal examGrade,
        BigDecimal tpGrade,
        BigDecimal subjectAverage,
        boolean complete,
        boolean validated
) {
}
