package com.unigate.academic.controller;

import com.unigate.academic.domain.enums.TimetableChangeRequestStatus;
import com.unigate.academic.dto.timetable.TimetableChangeDecisionRequest;
import com.unigate.academic.dto.timetable.TimetableChangeRequestResponse;
import com.unigate.academic.service.TimetableChangeRequestService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/admin/academic/timetable/change-requests")
@PreAuthorize("hasAnyRole('DEPARTMENT_ADMIN','SUPER_ADMIN')")
public class AdminTimetableChangeRequestController {

    private final TimetableChangeRequestService requestService;

    @GetMapping
    public List<TimetableChangeRequestResponse> list(@RequestParam(required = false) TimetableChangeRequestStatus status) {
        return requestService.listForAdmin(status);
    }

    @PostMapping("/{id}/approve")
    public TimetableChangeRequestResponse approve(@PathVariable Long id, @RequestBody(required = false) TimetableChangeDecisionRequest request) {
        return requestService.approve(id, request);
    }

    @PostMapping("/{id}/reject")
    public TimetableChangeRequestResponse reject(@PathVariable Long id, @RequestBody(required = false) TimetableChangeDecisionRequest request) {
        return requestService.reject(id, request);
    }
}
