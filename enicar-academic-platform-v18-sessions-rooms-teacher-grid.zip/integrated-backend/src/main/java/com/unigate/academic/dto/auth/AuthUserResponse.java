package com.unigate.academic.dto.auth;

import com.unigate.academic.domain.enums.Semester;

import java.util.List;

public record AuthUserResponse(
        String username,
        Long studentId,
        List<String> roles,
        String displayName,
        String defaultDepartment,
        Integer defaultYear,
        Semester defaultSemester,
        String defaultClassGroupName,
        String authScheme,
        String accessToken
) {
}
