package com.unigate.academic.controller;

import com.unigate.academic.domain.enums.Semester;
import com.unigate.academic.dto.grade.GradeConfigRequest;
import com.unigate.academic.dto.grade.GradeConfigResponse;
import com.unigate.academic.service.GradeConfigService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/admin/academic/grade-configs")
@PreAuthorize("hasAnyRole('DEPARTMENT_ADMIN','SUPER_ADMIN')")
public class AdminGradeConfigController {

    private final GradeConfigService gradeConfigService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public GradeConfigResponse upsert(@Valid @RequestBody GradeConfigRequest request) {
        return gradeConfigService.upsertConfig(request);
    }

    @GetMapping
    public List<GradeConfigResponse> list(
            @RequestParam @NotBlank String department,
            @RequestParam @NotNull Integer year,
            @RequestParam @NotNull Semester semester
    ) {
        return gradeConfigService.listActiveConfigs(department, year, semester);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deactivate(@PathVariable Long id) {
        gradeConfigService.deactivateConfig(id);
    }
}
