package com.unigate.academic.common.exception;

public class ForbiddenAcademicAccessException extends RuntimeException {
    public ForbiddenAcademicAccessException(String message) {
        super(message);
    }
}
