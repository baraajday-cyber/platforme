package com.unigate.academic.integration;

import com.unigate.academic.domain.entity.TimetableSlot;
import com.unigate.academic.dto.grade.StudentResultsResponse;
import org.springframework.stereotype.Component;

@Component
public class NoopAcademicNotificationPort implements AcademicNotificationPort {
    @Override
    public void notifyTimetableChanged(Long classGroupId, TimetableSlot slot, String action) {
        // Membre 3 remplace ce bean par WebSocket/STOMP + email si necessaire.
    }

    @Override
    public void notifyGradeUpdated(Long studentId, StudentResultsResponse results) {
        // Membre 3 connecte GradeEnteredEvent -> WebSocket notes.
    }
}
