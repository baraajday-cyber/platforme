package com.unigate.academic.controller;

import com.unigate.academic.domain.enums.Semester;
import com.unigate.academic.dto.grade.StudentGradeUpsertRequest;
import com.unigate.academic.dto.grade.StudentOptionResponse;
import com.unigate.academic.dto.grade.StudentResultsResponse;
import com.unigate.academic.service.GradeCalculationService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/admin/academic/grades")
@PreAuthorize("hasAnyRole('TEACHER','DEPARTMENT_ADMIN','SUPER_ADMIN')")
public class AdminGradeController {

    private final GradeCalculationService gradeCalculationService;

    @GetMapping("/students")
    public List<StudentOptionResponse> students(Authentication authentication) {
        return gradeCalculationService.listLocalStudentOptions(authentication.getName());
    }

    @GetMapping("/students/{studentId}/results")
    public StudentResultsResponse studentResults(
            @PathVariable Long studentId,
            @RequestParam @NotBlank String department,
            @RequestParam @NotNull Integer year,
            @RequestParam @NotNull Semester semester,
            Authentication authentication
    ) {
        return gradeCalculationService.getStudentResults(studentId, department, year, semester, authentication.getName());
    }

    @PutMapping("/students/{studentId}")
    public StudentResultsResponse upsertStudentGrade(
            @PathVariable Long studentId,
            @Valid @RequestBody StudentGradeUpsertRequest request,
            Authentication authentication
    ) {
        return gradeCalculationService.upsertGrade(studentId, request, authentication.getName());
    }

    @DeleteMapping("/{gradeId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteGrade(@PathVariable Long gradeId, Authentication authentication) {
        gradeCalculationService.deleteGrade(gradeId, authentication.getName());
    }
}
