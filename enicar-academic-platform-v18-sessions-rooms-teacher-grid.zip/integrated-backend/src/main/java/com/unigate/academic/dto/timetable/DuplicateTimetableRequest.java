package com.unigate.academic.dto.timetable;

import jakarta.validation.constraints.NotNull;

public record DuplicateTimetableRequest(
        @NotNull Long sourceClassGroupId,
        @NotNull Long targetClassGroupId,
        boolean copyCancelledSlots
) {
}
