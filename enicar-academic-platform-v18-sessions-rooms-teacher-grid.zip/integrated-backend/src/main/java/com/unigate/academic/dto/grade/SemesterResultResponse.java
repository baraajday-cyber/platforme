package com.unigate.academic.dto.grade;

import com.unigate.academic.domain.enums.Semester;

import java.math.BigDecimal;

public record SemesterResultResponse(
        Long id,
        Long studentId,
        String department,
        Integer year,
        Semester semester,
        BigDecimal semesterAverage,
        Integer totalCredits,
        boolean complete,
        boolean validated
) {
}
