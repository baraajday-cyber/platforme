package com.unigate.academic.dto.timetable;

import com.unigate.academic.domain.enums.Semester;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;

public record AcademicModuleRequest(
        @NotBlank @Size(max = 120) String name,
        @NotBlank @Size(max = 80) String department,
        @NotNull @Min(1) @Max(6) Integer year,
        @NotNull Semester semester,
        @NotNull @DecimalMin("0.01") BigDecimal moduleCoefficient,
        @NotNull @Positive Integer credits
) {
}
