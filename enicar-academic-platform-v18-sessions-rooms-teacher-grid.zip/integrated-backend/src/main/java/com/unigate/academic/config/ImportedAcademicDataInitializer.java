package com.unigate.academic.config;

import com.unigate.academic.domain.entity.AcademicModule;
import com.unigate.academic.domain.entity.ClassGroup;
import com.unigate.academic.domain.entity.Course;
import com.unigate.academic.domain.entity.GradeConfig;
import com.unigate.academic.domain.entity.StudentClassAssignment;
import com.unigate.academic.domain.entity.StudentGrade;
import com.unigate.academic.domain.entity.TimetableSlot;
import com.unigate.academic.domain.enums.Semester;
import com.unigate.academic.domain.enums.SlotStatus;
import com.unigate.academic.repository.AcademicModuleRepository;
import com.unigate.academic.repository.ClassGroupRepository;
import com.unigate.academic.repository.CourseRepository;
import com.unigate.academic.repository.GradeConfigRepository;
import com.unigate.academic.repository.StudentClassAssignmentRepository;
import com.unigate.academic.repository.StudentGradeRepository;
import com.unigate.academic.repository.TimetableSlotRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;

import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Configuration
public class ImportedAcademicDataInitializer {

    private static final String DEPARTMENT = "Informatique";
    private static final Long STUDENT_ID = 1L;
    private static final Long DEMO_ADMIN_STUDENT_ID = 100L;

    @Bean
    @Order(20)
    CommandLineRunner seedImportedAcademicFilesData(
            ClassGroupRepository classGroupRepository,
            CourseRepository courseRepository,
            AcademicModuleRepository moduleRepository,
            GradeConfigRepository gradeConfigRepository,
            StudentClassAssignmentRepository assignmentRepository,
            TimetableSlotRepository timetableSlotRepository,
            StudentGradeRepository studentGradeRepository
    ) {
        return args -> {
            seedGradesFromExcel(courseRepository, moduleRepository, gradeConfigRepository, studentGradeRepository);
            Map<String, ClassGroup> groups = seedClassGroups(classGroupRepository);
            seedAssignments(assignmentRepository, groups);
            seedTimetableFromPdf(courseRepository, timetableSlotRepository, groups);
        };
    }

    private void seedGradesFromExcel(
            CourseRepository courseRepository,
            AcademicModuleRepository moduleRepository,
            GradeConfigRepository gradeConfigRepository,
            StudentGradeRepository studentGradeRepository
    ) {
        Map<String, AcademicModule> currentModuleBySemester = new HashMap<>();
        int moduleIndex = 0;
        for (GradeSeed seed : GRADE_SEEDS) {
            Course course = seedCourse(courseRepository, seed.subject(), seed.year(), seed.semester(), seed.coefficient());
            if (seed.moduleCoefficient() != null || !currentModuleBySemester.containsKey(seed.key())) {
                moduleIndex++;
                String moduleName = "UE " + seed.semester().name() + "-" + moduleIndex + " - " + shortName(seed.subject());
                AcademicModule module = seedModule(moduleRepository, moduleName, seed.year(), seed.semester(), seed.moduleCoefficient() == null ? seed.coefficient() : seed.moduleCoefficient());
                currentModuleBySemester.put(seed.key(), module);
            }
            AcademicModule module = currentModuleBySemester.get(seed.key());
            Weights weights = weightsFromFormula(seed.formula());
            seedGradeConfig(gradeConfigRepository, course, module, seed, weights);
            seedStudentGradeIfMissing(studentGradeRepository, STUDENT_ID, course, seed);
            seedStudentGradeIfMissing(studentGradeRepository, DEMO_ADMIN_STUDENT_ID, course, seed);
        }
        normalizeSemesterCredits(moduleRepository);
    }

    private Map<String, ClassGroup> seedClassGroups(ClassGroupRepository repository) {
        Map<String, ClassGroup> groups = new HashMap<>();
        for (String name : List.of("Ing Inf 1A", "Ing Inf 1B", "Ing Inf 1C", "Ing Inf 1D")) {
            groups.put(name, seedClassGroup(repository, name, 1, Semester.S2));
        }
        for (String name : List.of("Ing Inf 2A", "Ing Inf 2B", "Ing Inf 2C", "Ing Inf 2D")) {
            groups.put(name, seedClassGroup(repository, name, 2, Semester.S4));
        }
        return groups;
    }

    private void seedAssignments(StudentClassAssignmentRepository repository, Map<String, ClassGroup> groups) {
        seedAssignment(repository, STUDENT_ID, groups.get("Ing Inf 1A"), 1, Semester.S2);
        seedAssignment(repository, STUDENT_ID, groups.get("Ing Inf 2A"), 2, Semester.S4);
        seedAssignment(repository, 2L, groups.get("Ing Inf 1B"), 1, Semester.S2);
        seedAssignment(repository, 2L, groups.get("Ing Inf 2B"), 2, Semester.S4);
        seedAssignment(repository, DEMO_ADMIN_STUDENT_ID, groups.get("Ing Inf 1A"), 1, Semester.S2);
        seedAssignment(repository, DEMO_ADMIN_STUDENT_ID, groups.get("Ing Inf 2A"), 2, Semester.S4);
    }

    private void seedTimetableFromPdf(CourseRepository courseRepository, TimetableSlotRepository timetableSlotRepository, Map<String, ClassGroup> groups) {
        long professorIdSeed = 20_000L;
        for (SlotSeed seed : SLOT_SEEDS) {
            ClassGroup group = groups.get(seed.groupName());
            if (group == null) {
                continue;
            }
            Course course = seedCourse(courseRepository, seed.courseName(), seed.year(), seed.semester(), bd("1"));
            seedSlot(timetableSlotRepository, group, course, seed, professorIdSeed++);
        }
    }

    private Course seedCourse(CourseRepository repository, String name, int year, Semester semester, BigDecimal coefficient) {
        return repository.findByNameAndDepartment(name, DEPARTMENT).map(existing -> {
            if (existing.getDefaultCoefficient() == null) {
                existing.setDefaultCoefficient(coefficient);
            }
            if (existing.getDefaultCredits() == null) {
                existing.setDefaultCredits(Math.max(1, coefficient.setScale(0, BigDecimal.ROUND_HALF_UP).intValue()));
            }
            return repository.save(existing);
        }).orElseGet(() -> repository.save(Course.builder()
                .name(name)
                .department(DEPARTMENT)
                .code(codeFor(name, year, semester))
                .defaultCoefficient(coefficient)
                .defaultCredits(Math.max(1, coefficient.setScale(0, BigDecimal.ROUND_HALF_UP).intValue()))
                .build()));
    }

    private AcademicModule seedModule(AcademicModuleRepository repository, String name, int year, Semester semester, BigDecimal moduleCoefficient) {
        return repository.findByNameAndDepartmentAndYearAndSemester(name, DEPARTMENT, year, semester)
                .orElseGet(() -> repository.save(AcademicModule.builder()
                        .name(name)
                        .department(DEPARTMENT)
                        .year(year)
                        .semester(semester)
                        .moduleCoefficient(moduleCoefficient)
                        .credits(Math.max(1, moduleCoefficient.setScale(0, BigDecimal.ROUND_HALF_UP).intValue()))
                        .build()));
    }

    /**
     * Les coefficients de certains modules sont decimaux (ex. 5.5, 6.5).
     * Les credits doivent pourtant rester entiers et la somme pedagogique d'un semestre doit etre 30.
     * On applique donc une repartition par plus grands restes au lieu d'arrondir chaque module independamment,
     * car l'arrondi independant pouvait produire 31 credits pour S2/S3/S4.
     */
    private void normalizeSemesterCredits(AcademicModuleRepository repository) {
        for (int year : List.of(1, 2)) {
            for (Semester semester : List.of(Semester.S1, Semester.S2, Semester.S3, Semester.S4)) {
                List<AcademicModule> modules = repository.findByDepartmentAndYearAndSemesterOrderByName(DEPARTMENT, year, semester);
                if (modules.isEmpty()) {
                    continue;
                }
                int floorSum = 0;
                Map<Long, Integer> creditsByModuleId = new HashMap<>();
                for (AcademicModule module : modules) {
                    BigDecimal coefficient = module.getModuleCoefficient() == null ? BigDecimal.ONE : module.getModuleCoefficient();
                    int floor = Math.max(1, coefficient.setScale(0, java.math.RoundingMode.DOWN).intValue());
                    floorSum += floor;
                    creditsByModuleId.put(module.getId(), floor);
                }
                int remaining = 30 - floorSum;
                if (remaining > 0) {
                    modules.stream()
                            .sorted((a, b) -> {
                                BigDecimal af = fractionalPart(a.getModuleCoefficient());
                                BigDecimal bf = fractionalPart(b.getModuleCoefficient());
                                int cmp = bf.compareTo(af);
                                return cmp != 0 ? cmp : a.getName().compareToIgnoreCase(b.getName());
                            })
                            .limit(remaining)
                            .forEach(module -> creditsByModuleId.computeIfPresent(module.getId(), (id, value) -> value + 1));
                }
                int total = creditsByModuleId.values().stream().mapToInt(Integer::intValue).sum();
                if (total != 30 && !modules.isEmpty()) {
                    AcademicModule last = modules.get(modules.size() - 1);
                    creditsByModuleId.computeIfPresent(last.getId(), (id, value) -> Math.max(1, value + (30 - total)));
                }
                for (AcademicModule module : modules) {
                    Integer credits = creditsByModuleId.get(module.getId());
                    if (credits != null && !credits.equals(module.getCredits())) {
                        module.setCredits(credits);
                        repository.save(module);
                    }
                }
            }
        }
    }

    private BigDecimal fractionalPart(BigDecimal value) {
        if (value == null) {
            return BigDecimal.ZERO;
        }
        return value.subtract(value.setScale(0, java.math.RoundingMode.DOWN)).abs();
    }

    private void seedGradeConfig(GradeConfigRepository repository, Course course, AcademicModule module, GradeSeed seed, Weights weights) {
        GradeConfig config = repository.findByDepartmentAndYearAndSemesterAndSubjectIdAndModuleId(DEPARTMENT, seed.year(), seed.semester(), course.getId(), module.getId())
                .orElseGet(GradeConfig::new);
        config.setDepartment(DEPARTMENT);
        config.setYear(seed.year());
        config.setSemester(seed.semester());
        config.setSubject(course);
        config.setModule(module);
        config.setSubjectCoefficient(seed.coefficient());
        config.setModuleCoefficient(module.getModuleCoefficient());
        config.setCcWeight(weights.cc());
        config.setExamWeight(weights.exam());
        config.setTpWeight(weights.tp());
        config.setCredits(Math.max(1, seed.coefficient().setScale(0, BigDecimal.ROUND_HALF_UP).intValue()));
        config.setActive(true);
        repository.save(config);
    }

    private void seedStudentGradeIfMissing(StudentGradeRepository repository, Long studentId, Course course, GradeSeed seed) {
        boolean exists = repository.findByStudentIdAndYearAndSemesterAndSubjectId(studentId, seed.year(), seed.semester(), course.getId()).isPresent();
        if (exists) {
            // Never overwrite grades entered later by an admin.
            return;
        }
        StudentGrade grade = new StudentGrade();
        grade.setStudentId(studentId);
        grade.setDepartment(DEPARTMENT);
        grade.setYear(seed.year());
        grade.setSemester(seed.semester());
        grade.setSubject(course);
        grade.setCcGrade(seed.cc());
        grade.setExamGrade(seed.exam());
        grade.setTpGrade(null);
        grade.setSubjectAverage(seed.average());
        grade.setValidated(seed.average() != null && seed.average().compareTo(BigDecimal.TEN) >= 0);
        repository.save(grade);
    }

    private ClassGroup seedClassGroup(ClassGroupRepository repository, String name, int year, Semester semester) {
        return repository.findByNameAndDepartmentAndYearAndSemester(name, DEPARTMENT, year, semester)
                .orElseGet(() -> repository.save(ClassGroup.builder()
                        .name(name)
                        .department(DEPARTMENT)
                        .year(year)
                        .semester(semester)
                        .description("Import depuis EDT-INFO-25-26-S2.pdf")
                        .build()));
    }

    private void seedAssignment(StudentClassAssignmentRepository repository, Long studentId, ClassGroup group, int year, Semester semester) {
        if (group == null) {
            return;
        }
        repository.findByStudentIdAndYearAndSemesterAndActiveTrue(studentId, year, semester).orElseGet(() -> repository.save(StudentClassAssignment.builder()
                .studentId(studentId)
                .classGroup(group)
                .year(year)
                .semester(semester)
                .active(true)
                .build()));
    }

    private void seedSlot(TimetableSlotRepository repository, ClassGroup group, Course course, SlotSeed seed, Long professorId) {
        boolean exists = repository.findByClassGroupIdOrderByDayOfWeekAscStartTimeAsc(group.getId()).stream()
                .anyMatch(slot -> slot.getDayOfWeek() == seed.day()
                        && slot.getStartTime().equals(LocalTime.parse(seed.start()))
                        && slot.getEndTime().equals(LocalTime.parse(seed.end()))
                        && slot.getRoom().equalsIgnoreCase(seed.room()));
        if (!exists) {
            repository.save(TimetableSlot.builder()
                    .classGroup(group)
                    .course(course)
                    .dayOfWeek(seed.day())
                    .startTime(LocalTime.parse(seed.start()))
                    .endTime(LocalTime.parse(seed.end()))
                    .room(seed.room())
                    .professorId(professorId)
                    .professorName(seed.professor())
                    .status(SlotStatus.ACTIVE)
                    .changeReason("Import EDT PDF")
                    .build());
        }
    }

    private Weights weightsFromFormula(String formula) {
        if (formula == null) {
            return new Weights(bd("0.35"), bd("0.65"), BigDecimal.ZERO);
        }
        String normalized = formula.toLowerCase();
        if (normalized.contains("50%")) {
            return new Weights(bd("0.50"), bd("0.50"), BigDecimal.ZERO);
        }
        if (normalized.contains("examen tp")) {
            return new Weights(BigDecimal.ZERO, BigDecimal.ONE, BigDecimal.ZERO);
        }
        return new Weights(bd("0.35"), bd("0.65"), BigDecimal.ZERO);
    }

    private String shortName(String subject) {
        return subject.length() <= 42 ? subject : subject.substring(0, 42);
    }

    private String codeFor(String name, int year, Semester semester) {
        String compact = name.toUpperCase()
                .replaceAll("[^A-Z0-9]", "")
                .replaceAll("^(.{0,8}).*$", "$1");
        if (compact.isBlank()) {
            compact = "COURSE";
        }
        return compact + year + semester.name();
    }

    private static BigDecimal bd(String value) {
        return new BigDecimal(value);
    }

    private record GradeSeed(int year, Semester semester, String subject, BigDecimal cc, BigDecimal exam, BigDecimal coefficient, BigDecimal moduleCoefficient, String formula, BigDecimal average) {
        String key() {
            return year + "-" + semester.name();
        }
    }

    private record SlotSeed(String groupName, int year, Semester semester, DayOfWeek day, String start, String end, String courseName, String professor, String room) {}
    private record Weights(BigDecimal cc, BigDecimal exam, BigDecimal tp) {}

    private static final List<GradeSeed> GRADE_SEEDS = List.of(
        new GradeSeed(1, Semester.S1, "Mathématiques de l'ingénieur", null, null, bd("3"), bd("5"), "35% CC + 65% Examen", bd("0")),
        new GradeSeed(1, Semester.S1, "Analyse numérique 1", null, null, bd("2"), null, "35% CC + 65% Examen", bd("0")),
        new GradeSeed(1, Semester.S1, "Algorithmique", null, null, bd("3"), bd("7"), "35% CC + 65% Examen", bd("0")),
        new GradeSeed(1, Semester.S1, "Programmation", null, null, bd("4"), null, "50% CC + 50% Examen", bd("0")),
        new GradeSeed(1, Semester.S1, "TIC", null, null, bd("2"), bd("8"), "35% CC + 65% Examen", bd("0")),
        new GradeSeed(1, Semester.S1, "Logique formelle", null, null, bd("3"), null, "35% CC + 65% Examen", bd("0")),
        new GradeSeed(1, Semester.S1, "Génie logiciel", null, null, bd("3"), null, "35% CC + 65% Examen", bd("0")),
        new GradeSeed(1, Semester.S1, "Circuits numériques et éléments", null, null, bd("3"), bd("5"), "35% CC + 65% Examen", bd("0")),
        new GradeSeed(1, Semester.S1, "Semi-conducteurs et électronique analogique", null, null, bd("2"), null, "35% CC + 65% Examen", bd("0")),
        new GradeSeed(1, Semester.S1, "Economie de l'entreprise", null, null, bd("2"), bd("5"), "35% CC + 65% Examen", bd("0")),
        new GradeSeed(1, Semester.S1, "Basic english", null, null, bd("1.5"), null, "35% CC + 65% Examen", bd("0")),
        new GradeSeed(1, Semester.S1, "Culture et communication 1", null, null, bd("1.5"), null, "35% CC + 65% Examen", bd("0")),
        new GradeSeed(1, Semester.S2, "Probabilités et Processus Stochastique", null, null, bd("3"), bd("5"), "35% CC + 65% Examen", bd("0")),
        new GradeSeed(1, Semester.S2, "Analyse numérique 2", null, null, bd("2"), null, "35% CC + 65% Examen", bd("0")),
        new GradeSeed(1, Semester.S2, "Structures de Données", null, null, bd("2.5"), bd("6.5"), "35% CC + 65% Examen", bd("0")),
        new GradeSeed(1, Semester.S2, "Programmation Orientée Objet", null, null, bd("4"), null, "50% CC + 50% Examen", bd("0")),
        new GradeSeed(1, Semester.S2, "Architecture des systèmes à Microprocesseur", null, null, bd("2.5"), bd("7.5"), "35% CC + 65% Examen", bd("0")),
        new GradeSeed(1, Semester.S2, "Fondement des réseaux", null, null, bd("2.5"), null, "35% CC + 65% Examen", bd("0")),
        new GradeSeed(1, Semester.S2, "Technologies Web", null, null, bd("2.5"), null, "35% CC + 65% Examen", bd("0")),
        new GradeSeed(1, Semester.S2, "Base de Données", null, null, bd("2.5"), bd("6"), "35% CC + 65% Examen", bd("0")),
        new GradeSeed(1, Semester.S2, "Analyse et conception des Systèmes d'Information", null, null, bd("3.5"), null, "35% CC + 65% Examen", bd("0")),
        new GradeSeed(1, Semester.S2, "Théorie des Organisations", null, null, bd("2"), bd("5"), "35% CC + 65% Examen", bd("0")),
        new GradeSeed(1, Semester.S2, "Professional English", null, null, bd("1.5"), null, "35% CC + 65% Examen", bd("0")),
        new GradeSeed(1, Semester.S2, "Culture et communication 2", null, null, bd("1.5"), null, "35% CC + 65% Examen", bd("0")),
        new GradeSeed(2, Semester.S3, "Système d'Exploitation", bd("12"), bd("12"), bd("3"), bd("5"), "35% CC + 65% Examen", bd("12")),
        new GradeSeed(2, Semester.S3, "Atelier de Systèmes d'Exploitation", null, bd("4"), bd("2"), null, "Examen TP", bd("4")),
        new GradeSeed(2, Semester.S3, "Algorithmique Avancée", bd("7"), bd("15"), bd("3.5"), bd("7"), "35% CC + 65% Examen", bd("12.2")),
        new GradeSeed(2, Semester.S3, "Programmation Java", bd("14"), bd("6.5"), bd("3.5"), null, "50% CC + 50% Examen", bd("10.25")),
        new GradeSeed(2, Semester.S3, "Technologies Web avancées", bd("17"), bd("15"), bd("3.5"), bd("6.5"), "35% CC + 65% Examen", bd("15.7")),
        new GradeSeed(2, Semester.S3, "Réseaux d'entreprises", bd("5.8"), bd("7"), bd("3"), null, "35% CC + 65% Examen", bd("6.58")),
        new GradeSeed(2, Semester.S3, "Recherche Opérationnelle et Optimisation", bd("5"), bd("11.5"), bd("3"), bd("6.5"), "35% CC + 65% Examen", bd("9.225")),
        new GradeSeed(2, Semester.S3, "Systèmes de Gestion des Bases des Données", bd("12.75"), bd("8.75"), bd("3.5"), null, "50% CC + 50% Examen", bd("10.75")),
        new GradeSeed(2, Semester.S3, "Comptabilité d’Entreprise", bd("4.75"), bd("16"), bd("2"), bd("5"), "35% CC + 65% Examen", bd("12.0625")),
        new GradeSeed(2, Semester.S3, "Technical English", bd("16"), bd("12.25"), bd("1.5"), null, "35% CC + 65% Examen", bd("13.5625")),
        new GradeSeed(2, Semester.S3, "Techniques de Recherche d’Emploi", bd("12.25"), bd("8.5"), bd("1.5"), null, "35% CC + 65% Examen", bd("9.8125")),
        new GradeSeed(2, Semester.S4, "Théorie des Langages et Compilation", bd("7"), bd("9"), bd("3"), bd("6"), "50% CC + 50% Examen", bd("8")),
        new GradeSeed(2, Semester.S4, "Intelligence Artificielle", bd("13"), bd("12"), bd("3"), null, "35% CC + 65% Examen", bd("12.35")),
        new GradeSeed(2, Semester.S4, "Sécurité informatique", bd("14"), bd("8"), bd("2"), bd("5.5"), "35% CC + 65% Examen", bd("10.1")),
        new GradeSeed(2, Semester.S4, "Programmation et administration Système et Réseaux", bd("13"), bd("10"), bd("3.5"), null, "50% CC + 50% Examen", bd("11.5")),
        new GradeSeed(2, Semester.S4, "Développement mobile", bd("10"), bd("12"), bd("2"), bd("7"), "35% CC + 65% Examen", bd("11.3")),
        new GradeSeed(2, Semester.S4, "Plateformes de Développement", bd("12"), bd("10"), bd("3"), null, "35% CC + 65% Examen", bd("10.7")),
        new GradeSeed(2, Semester.S4, "Routage des Réseaux", bd("10"), bd("7"), bd("2"), null, "35% CC + 65% Examen", bd("8.05")),
        new GradeSeed(2, Semester.S4, "Systèmes Embarqués", bd("13"), bd("10"), bd("3"), bd("6"), "35% CC + 65% Examen", bd("11.05")),
        new GradeSeed(2, Semester.S4, "Analyse des Données", bd("13"), bd("10"), bd("3"), null, "35% CC + 65% Examen", bd("11.05")),
        new GradeSeed(2, Semester.S4, "Management des Projets", bd("15"), bd("5"), bd("2.5"), bd("5.5"), "35% CC + 65% Examen", bd("8.5")),
        new GradeSeed(2, Semester.S4, "Business English", bd("18"), bd("13"), bd("1.5"), null, "35% CC + 65% Examen", bd("14.75")),
        new GradeSeed(2, Semester.S4, "Communication en Entreprise", bd("10"), bd("10"), bd("1.5"), null, "35% CC + 65% Examen", bd("10"))
    );

    private static final List<SlotSeed> SLOT_SEEDS = List.of(
        new SlotSeed("Ing Inf 1A", 1, Semester.S2, DayOfWeek.MONDAY, "08:30", "10:00", "Rx av. & Routage", "Bahri", "SL27"),
        new SlotSeed("Ing Inf 1A", 1, Semester.S2, DayOfWeek.MONDAY, "10:10", "11:40", "Rx av. & Routage", "Bahri", "SL27"),
        new SlotSeed("Ing Inf 1A", 1, Semester.S2, DayOfWeek.MONDAY, "12:30", "14:00", "Théorie des Organisations", "Karoui S.", "S23"),
        new SlotSeed("Ing Inf 1A", 1, Semester.S2, DayOfWeek.MONDAY, "14:10", "15:40", "Proc. Stochastique", "Kammoun", "S25"),
        new SlotSeed("Ing Inf 1A", 1, Semester.S2, DayOfWeek.TUESDAY, "08:30", "10:00", "Analyse & Conception", "Daassi", "S22"),
        new SlotSeed("Ing Inf 1A", 1, Semester.S2, DayOfWeek.TUESDAY, "10:10", "11:40", "Prob. & Stat", "Debbech", "S23"),
        new SlotSeed("Ing Inf 1A", 1, Semester.S2, DayOfWeek.TUESDAY, "12:30", "14:00", "BD Relationnelles", "Moussa", "S23"),
        new SlotSeed("Ing Inf 1A", 1, Semester.S2, DayOfWeek.TUESDAY, "14:10", "15:40", "BD Relationnelles", "Moussa", "S23"),
        new SlotSeed("Ing Inf 1A", 1, Semester.S2, DayOfWeek.WEDNESDAY, "08:30", "10:00", "Analyse & Conception", "Daassi", "S23"),
        new SlotSeed("Ing Inf 1A", 1, Semester.S2, DayOfWeek.WEDNESDAY, "10:10", "11:40", "P.O.O", "Yaiche", "S23"),
        new SlotSeed("Ing Inf 1A", 1, Semester.S2, DayOfWeek.WEDNESDAY, "12:30", "14:00", "Professional English", "Moussa. W", "S26"),
        new SlotSeed("Ing Inf 1A", 1, Semester.S2, DayOfWeek.WEDNESDAY, "14:10", "15:40", "Analyse Numérique 2", "Aloui", "S23"),
        new SlotSeed("Ing Inf 1A", 1, Semester.S2, DayOfWeek.THURSDAY, "08:30", "10:00", "P.O.O", "Bessouda / Ben Nasr F.", "S33/S36"),
        new SlotSeed("Ing Inf 1A", 1, Semester.S2, DayOfWeek.THURSDAY, "10:10", "11:40", "P.O.O", "Yaiche", "S23"),
        new SlotSeed("Ing Inf 1A", 1, Semester.S2, DayOfWeek.THURSDAY, "12:30", "14:00", "Architecture des ord", "Gueddana", "S21"),
        new SlotSeed("Ing Inf 1A", 1, Semester.S2, DayOfWeek.THURSDAY, "14:10", "15:40", "Architecture des ord", "Gueddana", "S21"),
        new SlotSeed("Ing Inf 1A", 1, Semester.S2, DayOfWeek.THURSDAY, "15:50", "17:20", "Analyse Numérique 2", "Aloui", "S23"),
        new SlotSeed("Ing Inf 1A", 1, Semester.S2, DayOfWeek.FRIDAY, "08:30", "10:00", "Algo. Av. & Complxit", "Abd Elwahed", "S23"),
        new SlotSeed("Ing Inf 1A", 1, Semester.S2, DayOfWeek.FRIDAY, "10:10", "11:40", "Cult.communication 2", "Bedhief", "S23"),
        new SlotSeed("Ing Inf 1A", 1, Semester.S2, DayOfWeek.FRIDAY, "14:10", "15:40", "PE: Web Application", "BenBoukhatem / Abid", "SL31"),
        new SlotSeed("Ing Inf 1B", 1, Semester.S2, DayOfWeek.MONDAY, "08:30", "10:00", "Professional English", "Moussa. W", "S24"),
        new SlotSeed("Ing Inf 1B", 1, Semester.S2, DayOfWeek.MONDAY, "10:10", "11:40", "Théor. des Organ.", "Karoui S.", "S23"),
        new SlotSeed("Ing Inf 1B", 1, Semester.S2, DayOfWeek.MONDAY, "12:30", "14:00", "Rx av. & Routage", "Bahri", "SL27"),
        new SlotSeed("Ing Inf 1B", 1, Semester.S2, DayOfWeek.TUESDAY, "08:30", "10:00", "Prob. & Stat", "Debbech", "S23"),
        new SlotSeed("Ing Inf 1B", 1, Semester.S2, DayOfWeek.TUESDAY, "10:10", "11:40", "Rx av. & Routage", "Bahri", "SL36"),
        new SlotSeed("Ing Inf 1B", 1, Semester.S2, DayOfWeek.TUESDAY, "12:30", "14:00", "P.O.O", "Nouira", "S30"),
        new SlotSeed("Ing Inf 1B", 1, Semester.S2, DayOfWeek.TUESDAY, "14:10", "15:40", "P.O.O", "Nouira", "S30"),
        new SlotSeed("Ing Inf 1B", 1, Semester.S2, DayOfWeek.TUESDAY, "15:50", "17:20", "Analyse Numérique 2", "Aloui", "S32"),
        new SlotSeed("Ing Inf 1B", 1, Semester.S2, DayOfWeek.WEDNESDAY, "08:30", "10:00", "Analyse & Conception", "Samef", "S22"),
        new SlotSeed("Ing Inf 1B", 1, Semester.S2, DayOfWeek.WEDNESDAY, "10:10", "11:40", "Analyse & Conception", "Samef", "S22"),
        new SlotSeed("Ing Inf 1B", 1, Semester.S2, DayOfWeek.WEDNESDAY, "12:30", "14:00", "Analyse Numérique 2", "Aloui", "S23"),
        new SlotSeed("Ing Inf 1B", 1, Semester.S2, DayOfWeek.WEDNESDAY, "14:10", "15:40", "Cult.communication 2", "Harrouch", "S24"),
        new SlotSeed("Ing Inf 1B", 1, Semester.S2, DayOfWeek.THURSDAY, "08:30", "10:00", "Algo. Av. & Complxit", "Abd Elwahed", "S21"),
        new SlotSeed("Ing Inf 1B", 1, Semester.S2, DayOfWeek.THURSDAY, "10:10", "11:40", "Algo. Av. & Complxit", "Abd Elwahed", "S21"),
        new SlotSeed("Ing Inf 1B", 1, Semester.S2, DayOfWeek.THURSDAY, "12:30", "14:00", "Proc.Stochastique", "Kammoun", "S26"),
        new SlotSeed("Ing Inf 1B", 1, Semester.S2, DayOfWeek.THURSDAY, "14:10", "15:40", "P.O.O", "Ben Nasr F. / Bessouda", "S36/S33"),
        new SlotSeed("Ing Inf 1B", 1, Semester.S2, DayOfWeek.FRIDAY, "08:30", "10:00", "BD Relationnelles", "Said S.", "S22"),
        new SlotSeed("Ing Inf 1B", 1, Semester.S2, DayOfWeek.FRIDAY, "10:10", "11:40", "BD Relationnelles", "Said S.", "S22"),
        new SlotSeed("Ing Inf 1B", 1, Semester.S2, DayOfWeek.FRIDAY, "12:30", "14:00", "Architecture des ord", "Gueddana", "S21"),
        new SlotSeed("Ing Inf 1B", 1, Semester.S2, DayOfWeek.FRIDAY, "14:10", "15:40", "Architecture des ord", "Gueddana", "S21"),
        new SlotSeed("Ing Inf 1B", 1, Semester.S2, DayOfWeek.SATURDAY, "08:30", "10:00", "PE: Web Application", "BenBoukhatem / Abid", "SL27"),
        new SlotSeed("Ing Inf 1B", 1, Semester.S2, DayOfWeek.SATURDAY, "10:10", "11:40", "PE: Web Application", "BenBoukhatem / Abid", "SL27"),
        new SlotSeed("Ing Inf 1C", 1, Semester.S2, DayOfWeek.MONDAY, "08:30", "10:00", "BD Relationnelles", "Moussa", "S22"),
        new SlotSeed("Ing Inf 1C", 1, Semester.S2, DayOfWeek.MONDAY, "10:10", "11:40", "BD Relationnelles", "Moussa", "S22"),
        new SlotSeed("Ing Inf 1C", 1, Semester.S2, DayOfWeek.MONDAY, "12:30", "14:00", "Analyse Numérique 2", "Hamda H.", "S25"),
        new SlotSeed("Ing Inf 1C", 1, Semester.S2, DayOfWeek.MONDAY, "14:10", "15:40", "Théor. des Organ.", "Karoui S.", "S23"),
        new SlotSeed("Ing Inf 1C", 1, Semester.S2, DayOfWeek.MONDAY, "15:50", "17:20", "Algo. Av. & Complxit", "Fkaier", "S21"),
        new SlotSeed("Ing Inf 1C", 1, Semester.S2, DayOfWeek.TUESDAY, "08:30", "10:00", "Architecture des ord", "Tili R.", "S25"),
        new SlotSeed("Ing Inf 1C", 1, Semester.S2, DayOfWeek.TUESDAY, "10:10", "11:40", "P.O.O", "Nouira", "S21"),
        new SlotSeed("Ing Inf 1C", 1, Semester.S2, DayOfWeek.TUESDAY, "12:30", "14:00", "Rx av. & Routage", "Bahri", "SL36"),
        new SlotSeed("Ing Inf 1C", 1, Semester.S2, DayOfWeek.TUESDAY, "14:10", "15:40", "Rx av. & Routage", "Bahri", "SL36"),
        new SlotSeed("Ing Inf 1C", 1, Semester.S2, DayOfWeek.TUESDAY, "15:50", "17:20", "Algo. Av. & Complxit", "Fkaier", "S21"),
        new SlotSeed("Ing Inf 1C", 1, Semester.S2, DayOfWeek.WEDNESDAY, "08:30", "10:00", "Professional English", "Moussa. W", "S25"),
        new SlotSeed("Ing Inf 1C", 1, Semester.S2, DayOfWeek.WEDNESDAY, "10:10", "11:40", "P.O.O", "Nouira", "S21"),
        new SlotSeed("Ing Inf 1C", 1, Semester.S2, DayOfWeek.WEDNESDAY, "12:30", "14:00", "Analyse & Conception", "Samef", "S22"),
        new SlotSeed("Ing Inf 1C", 1, Semester.S2, DayOfWeek.THURSDAY, "08:30", "10:00", "Analyse Numérique 2", "Hamda H.", "S30"),
        new SlotSeed("Ing Inf 1C", 1, Semester.S2, DayOfWeek.THURSDAY, "10:10", "11:40", "Architecture des ord", "Tili R.", "S25"),
        new SlotSeed("Ing Inf 1C", 1, Semester.S2, DayOfWeek.THURSDAY, "12:30", "14:00", "Analyse & Conception", "Samef", "S32"),
        new SlotSeed("Ing Inf 1C", 1, Semester.S2, DayOfWeek.THURSDAY, "14:10", "15:40", "Proc.Stochastique", "Kammoun", "S23"),
        new SlotSeed("Ing Inf 1C", 1, Semester.S2, DayOfWeek.THURSDAY, "15:50", "17:20", "P.O.O", "Bessouda / Ben Nasr F.", "S33/S36"),
        new SlotSeed("Ing Inf 1C", 1, Semester.S2, DayOfWeek.FRIDAY, "08:30", "10:00", "Prob. & Stat", "Debbech", "S21"),
        new SlotSeed("Ing Inf 1C", 1, Semester.S2, DayOfWeek.FRIDAY, "10:10", "11:40", "Cult.communication 2", "Besbes Z", "S24"),
        new SlotSeed("Ing Inf 1C", 1, Semester.S2, DayOfWeek.FRIDAY, "12:30", "14:00", "Web Basics / PE Web", "Abid Ch. / BenBoukhatem", "SL27"),
        new SlotSeed("Ing Inf 1D", 1, Semester.S2, DayOfWeek.MONDAY, "10:10", "11:40", "Analyse Numérique 2", "Hamda H.", "S25"),
        new SlotSeed("Ing Inf 1D", 1, Semester.S2, DayOfWeek.MONDAY, "12:30", "14:00", "Proc.Stochastique", "Kammoun", "S21"),
        new SlotSeed("Ing Inf 1D", 1, Semester.S2, DayOfWeek.MONDAY, "14:10", "15:40", "Algo. Av. & Complxit", "Fkaier", "S21"),
        new SlotSeed("Ing Inf 1D", 1, Semester.S2, DayOfWeek.MONDAY, "15:50", "17:20", "Théor. des Organ.", "Karoui S.", "S23"),
        new SlotSeed("Ing Inf 1D", 1, Semester.S2, DayOfWeek.TUESDAY, "08:30", "10:00", "P.O.O", "Nouira", "S24"),
        new SlotSeed("Ing Inf 1D", 1, Semester.S2, DayOfWeek.TUESDAY, "10:10", "11:40", "Architecture des ord", "Tili R.", "S25"),
        new SlotSeed("Ing Inf 1D", 1, Semester.S2, DayOfWeek.TUESDAY, "12:30", "14:00", "Rx av. & Routage", "Louafi F.", "SL27"),
        new SlotSeed("Ing Inf 1D", 1, Semester.S2, DayOfWeek.TUESDAY, "15:50", "17:20", "P.O.O", "Nouira", "S22"),
        new SlotSeed("Ing Inf 1D", 1, Semester.S2, DayOfWeek.WEDNESDAY, "08:30", "10:00", "Rx av. & Routage", "Louafi F.", "SL27"),
        new SlotSeed("Ing Inf 1D", 1, Semester.S2, DayOfWeek.WEDNESDAY, "10:10", "11:40", "Professional English", "Moussa. W", "S24"),
        new SlotSeed("Ing Inf 1D", 1, Semester.S2, DayOfWeek.THURSDAY, "08:30", "10:00", "Architecture des ord", "Tili R.", "S25"),
        new SlotSeed("Ing Inf 1D", 1, Semester.S2, DayOfWeek.THURSDAY, "10:10", "11:40", "Analyse Numérique 2", "Hamda H.", "S30"),
        new SlotSeed("Ing Inf 1D", 1, Semester.S2, DayOfWeek.THURSDAY, "12:30", "14:00", "P.O.O", "Ben Nasr F. / Bessouda", "S31/S27"),
        new SlotSeed("Ing Inf 1D", 1, Semester.S2, DayOfWeek.THURSDAY, "14:10", "15:40", "Analyse & Conception", "Samef", "S32"),
        new SlotSeed("Ing Inf 1D", 1, Semester.S2, DayOfWeek.THURSDAY, "15:50", "17:20", "Analyse & Conception", "Samef", "S32"),
        new SlotSeed("Ing Inf 1D", 1, Semester.S2, DayOfWeek.FRIDAY, "08:30", "10:00", "Cult.communication 2", "Besbes Z", "S24"),
        new SlotSeed("Ing Inf 1D", 1, Semester.S2, DayOfWeek.FRIDAY, "10:10", "11:40", "Prob. & Stat", "Debbech", "S21"),
        new SlotSeed("Ing Inf 1D", 1, Semester.S2, DayOfWeek.FRIDAY, "12:30", "14:00", "BD Relationnelles", "Said S.", "S22"),
        new SlotSeed("Ing Inf 1D", 1, Semester.S2, DayOfWeek.FRIDAY, "14:10", "15:40", "BD Relationnelles", "Said S.", "S22"),
        new SlotSeed("Ing Inf 1D", 1, Semester.S2, DayOfWeek.SATURDAY, "08:30", "10:00", "Web Basics / PE Web", "Abid Ch. / BenBoukhatem", "SL36"),
        new SlotSeed("Ing Inf 2A", 2, Semester.S4, DayOfWeek.MONDAY, "08:30", "10:00", "Syst. embarqués", "Bouchihma", "S21"),
        new SlotSeed("Ing Inf 2A", 2, Semester.S4, DayOfWeek.MONDAY, "10:10", "11:40", "Syst. embarqués", "Bouchihma", "S21"),
        new SlotSeed("Ing Inf 2A", 2, Semester.S4, DayOfWeek.MONDAY, "12:30", "14:00", "Prog. Sys. & Rx", "Achour / Gharbi N.", "SL31/S33"),
        new SlotSeed("Ing Inf 2A", 2, Semester.S4, DayOfWeek.MONDAY, "14:10", "15:40", "Admin. Sys. et Rx.", "Gharbi N.", "S33"),
        new SlotSeed("Ing Inf 2A", 2, Semester.S4, DayOfWeek.MONDAY, "15:50", "17:20", "Admin. Sys. et Rx.", "Melliti", "SL12"),
        new SlotSeed("Ing Inf 2A", 2, Semester.S4, DayOfWeek.TUESDAY, "08:30", "10:00", "Plateformes de Dev.", "Jaidi", "S30"),
        new SlotSeed("Ing Inf 2A", 2, Semester.S4, DayOfWeek.TUESDAY, "10:10", "11:40", "Routage des Rx", "Louafi F.", "SL27"),
        new SlotSeed("Ing Inf 2A", 2, Semester.S4, DayOfWeek.TUESDAY, "12:30", "14:00", "TLA & Compilation", "Hlaoui", "S32"),
        new SlotSeed("Ing Inf 2A", 2, Semester.S4, DayOfWeek.TUESDAY, "14:10", "15:40", "TLA & Compilation", "Hlaoui", "S32"),
        new SlotSeed("Ing Inf 2A", 2, Semester.S4, DayOfWeek.TUESDAY, "15:50", "17:20", "Business english", "Nasra", "S34"),
        new SlotSeed("Ing Inf 2A", 2, Semester.S4, DayOfWeek.WEDNESDAY, "08:30", "10:00", "Intelli.Artificielle", "Ghazouani", "S21"),
        new SlotSeed("Ing Inf 2A", 2, Semester.S4, DayOfWeek.WEDNESDAY, "10:10", "11:40", "Développement Mobile", "Lamouchi O.", "S25"),
        new SlotSeed("Ing Inf 2A", 2, Semester.S4, DayOfWeek.THURSDAY, "12:30", "14:00", "Comm. en Entreprise", "Bedhief", "S24"),
        new SlotSeed("Ing Inf 2A", 2, Semester.S4, DayOfWeek.THURSDAY, "14:10", "15:40", "Analyse des Données", "Barhoumi W.", "S25"),
        new SlotSeed("Ing Inf 2A", 2, Semester.S4, DayOfWeek.THURSDAY, "15:50", "17:20", "Sécu. Informatique", "Hermassi", "SL MAC"),
        new SlotSeed("Ing Inf 2A", 2, Semester.S4, DayOfWeek.FRIDAY, "08:30", "10:00", "Analyse des Données", "Ouerghi_H", "SL33"),
        new SlotSeed("Ing Inf 2A", 2, Semester.S4, DayOfWeek.FRIDAY, "10:10", "11:40", "Prog. Sys. & Rx", "ElBedoui", "SL31"),
        new SlotSeed("Ing Inf 2A", 2, Semester.S4, DayOfWeek.FRIDAY, "12:30", "14:00", "TLA & Compilation", "BenSalem", "SL36"),
        new SlotSeed("Ing Inf 2A", 2, Semester.S4, DayOfWeek.FRIDAY, "14:10", "15:40", "Management de Projet", "Yahyaoui", "S32"),
        new SlotSeed("Ing Inf 2A", 2, Semester.S4, DayOfWeek.FRIDAY, "15:50", "17:20", "Intelli.Artificielle", "Ghazouani", "S30"),
        new SlotSeed("Ing Inf 2B", 2, Semester.S4, DayOfWeek.MONDAY, "08:30", "10:00", "Prog. Sys. & Rx", "Achour / Gharbi N.", "SL31/S33"),
        new SlotSeed("Ing Inf 2B", 2, Semester.S4, DayOfWeek.MONDAY, "12:30", "14:00", "Syst. embarqués", "BenSlimen", "S34"),
        new SlotSeed("Ing Inf 2B", 2, Semester.S4, DayOfWeek.MONDAY, "14:10", "15:40", "Syst. embarqués", "BenSlimen", "S34"),
        new SlotSeed("Ing Inf 2B", 2, Semester.S4, DayOfWeek.TUESDAY, "08:30", "10:00", "Admin. Sys. et Rx.", "Gharbi N.", "S33"),
        new SlotSeed("Ing Inf 2B", 2, Semester.S4, DayOfWeek.TUESDAY, "10:10", "11:40", "Développement Mobile", "Lamouchi O.", "S22"),
        new SlotSeed("Ing Inf 2B", 2, Semester.S4, DayOfWeek.TUESDAY, "12:30", "14:00", "Plateformes de Dev.", "Jaidi", "S22"),
        new SlotSeed("Ing Inf 2B", 2, Semester.S4, DayOfWeek.TUESDAY, "14:10", "15:40", "Analyse des Données", "Barhoumi W.", "S25"),
        new SlotSeed("Ing Inf 2B", 2, Semester.S4, DayOfWeek.TUESDAY, "15:50", "17:20", "Sécu. Informatique", "Hermassi", "SL MAC"),
        new SlotSeed("Ing Inf 2B", 2, Semester.S4, DayOfWeek.WEDNESDAY, "08:30", "10:00", "Business english", "Nasra", "S24"),
        new SlotSeed("Ing Inf 2B", 2, Semester.S4, DayOfWeek.WEDNESDAY, "10:10", "11:40", "Routage des Rx", "Louafi F.", "SL27"),
        new SlotSeed("Ing Inf 2B", 2, Semester.S4, DayOfWeek.WEDNESDAY, "12:30", "14:00", "Intelli.Artificielle", "Ghazouani", "S25"),
        new SlotSeed("Ing Inf 2B", 2, Semester.S4, DayOfWeek.WEDNESDAY, "14:10", "15:40", "Intelli.Artificielle", "Ghazouani", "S25"),
        new SlotSeed("Ing Inf 2B", 2, Semester.S4, DayOfWeek.THURSDAY, "08:30", "10:00", "Analyse des Données", "Ouerghi_H", "S32"),
        new SlotSeed("Ing Inf 2B", 2, Semester.S4, DayOfWeek.THURSDAY, "10:10", "11:40", "TLA & Compilation", "BenSalem", "S33"),
        new SlotSeed("Ing Inf 2B", 2, Semester.S4, DayOfWeek.THURSDAY, "12:30", "14:00", "TLA & Compilation", "Hlaoui", "S22"),
        new SlotSeed("Ing Inf 2B", 2, Semester.S4, DayOfWeek.THURSDAY, "14:10", "15:40", "TLA & Compilation", "Hlaoui", "S22"),
        new SlotSeed("Ing Inf 2B", 2, Semester.S4, DayOfWeek.FRIDAY, "10:10", "11:40", "Management de Projet", "Abbes", "S34"),
        new SlotSeed("Ing Inf 2B", 2, Semester.S4, DayOfWeek.FRIDAY, "12:30", "14:00", "Prog. Sys. & Rx", "ElBedoui", "SL31"),
        new SlotSeed("Ing Inf 2B", 2, Semester.S4, DayOfWeek.FRIDAY, "14:10", "15:40", "Admin. Sys. et Rx.", "Melliti", "SL33"),
        new SlotSeed("Ing Inf 2B", 2, Semester.S4, DayOfWeek.FRIDAY, "15:50", "17:20", "Comm. en Entreprise", "Bedhief", "S21"),
        new SlotSeed("Ing Inf 2C", 2, Semester.S4, DayOfWeek.MONDAY, "08:30", "10:00", "Syst. embarqués", "BenSlimen", "S34"),
        new SlotSeed("Ing Inf 2C", 2, Semester.S4, DayOfWeek.MONDAY, "10:10", "11:40", "Syst. embarqués", "BenSlimen", "S22"),
        new SlotSeed("Ing Inf 2C", 2, Semester.S4, DayOfWeek.MONDAY, "12:30", "14:00", "Intelli.Artificielle", "Fourati", "S30"),
        new SlotSeed("Ing Inf 2C", 2, Semester.S4, DayOfWeek.MONDAY, "14:10", "15:40", "Intelli.Artificielle", "Fourati", "S30"),
        new SlotSeed("Ing Inf 2C", 2, Semester.S4, DayOfWeek.MONDAY, "15:50", "17:20", "Sécu. Informatique", "Hermassi", "SL MAC"),
        new SlotSeed("Ing Inf 2C", 2, Semester.S4, DayOfWeek.TUESDAY, "08:30", "10:00", "Développement Mobile", "Lamouchi O.", "S21"),
        new SlotSeed("Ing Inf 2C", 2, Semester.S4, DayOfWeek.TUESDAY, "10:10", "11:40", "Plateformes de Dev.", "Jaidi", "S32"),
        new SlotSeed("Ing Inf 2C", 2, Semester.S4, DayOfWeek.TUESDAY, "12:30", "14:00", "Prog. Sys. & Rx", "Achour / Gharbi N.", "SL31/S33"),
        new SlotSeed("Ing Inf 2C", 2, Semester.S4, DayOfWeek.TUESDAY, "14:10", "15:40", "Admin. Sys. et Rx.", "Gharbi N.", "S33"),
        new SlotSeed("Ing Inf 2C", 2, Semester.S4, DayOfWeek.WEDNESDAY, "10:10", "11:40", "Business english", "Nasra", "S30"),
        new SlotSeed("Ing Inf 2C", 2, Semester.S4, DayOfWeek.WEDNESDAY, "12:30", "14:00", "Routage des Rx", "Louafi F.", "SL27"),
        new SlotSeed("Ing Inf 2C", 2, Semester.S4, DayOfWeek.THURSDAY, "08:30", "10:00", "TLA & Compilation", "BenSalem", "SL MAC"),
        new SlotSeed("Ing Inf 2C", 2, Semester.S4, DayOfWeek.THURSDAY, "10:10", "11:40", "Prog. Sys. & Rx", "ElBedoui", "SL31"),
        new SlotSeed("Ing Inf 2C", 2, Semester.S4, DayOfWeek.THURSDAY, "12:30", "14:00", "Analyse des Données", "Barhoumi W.", "S25"),
        new SlotSeed("Ing Inf 2C", 2, Semester.S4, DayOfWeek.THURSDAY, "14:10", "15:40", "TLA & Compilation", "BenSalem", "SL31"),
        new SlotSeed("Ing Inf 2C", 2, Semester.S4, DayOfWeek.FRIDAY, "10:10", "11:40", "Analyse des Données", "Ouerghi_H", "SL33"),
        new SlotSeed("Ing Inf 2C", 2, Semester.S4, DayOfWeek.FRIDAY, "12:30", "14:00", "Comm. en Entreprise", "Bedhief", "S25"),
        new SlotSeed("Ing Inf 2C", 2, Semester.S4, DayOfWeek.FRIDAY, "14:10", "15:40", "TLA & Compilation", "BenSalem", "SL12"),
        new SlotSeed("Ing Inf 2C", 2, Semester.S4, DayOfWeek.FRIDAY, "15:50", "17:20", "Management de Projet", "Yahyaoui", "S32"),
        new SlotSeed("Ing Inf 2D", 2, Semester.S4, DayOfWeek.MONDAY, "10:10", "11:40", "Admin. Sys. et Rx.", "Gharbi N. / Achour", "S33/SL31"),
        new SlotSeed("Ing Inf 2D", 2, Semester.S4, DayOfWeek.MONDAY, "12:30", "14:00", "Intelli.Artificielle", "Chaabani A.", "SL MAC"),
        new SlotSeed("Ing Inf 2D", 2, Semester.S4, DayOfWeek.MONDAY, "14:10", "15:40", "Intelli.Artificielle", "Chaabani A.", "SL MAC"),
        new SlotSeed("Ing Inf 2D", 2, Semester.S4, DayOfWeek.TUESDAY, "08:30", "10:00", "Routage des Rx", "Louafi F.", "SL27"),
        new SlotSeed("Ing Inf 2D", 2, Semester.S4, DayOfWeek.TUESDAY, "10:10", "11:40", "Prog. Sys. & Rx", "Achour / Gharbi N.", "SL31/S33"),
        new SlotSeed("Ing Inf 2D", 2, Semester.S4, DayOfWeek.TUESDAY, "12:30", "14:00", "Analyse des Données", "Barhoumi W.", "S25"),
        new SlotSeed("Ing Inf 2D", 2, Semester.S4, DayOfWeek.TUESDAY, "14:10", "15:40", "Business english", "Nasra", "S24"),
        new SlotSeed("Ing Inf 2D", 2, Semester.S4, DayOfWeek.WEDNESDAY, "08:30", "10:00", "Syst. embarqués", "Bouchihma", "S26"),
        new SlotSeed("Ing Inf 2D", 2, Semester.S4, DayOfWeek.WEDNESDAY, "10:10", "11:40", "Syst. embarqués", "Bouchihma", "S26"),
        new SlotSeed("Ing Inf 2D", 2, Semester.S4, DayOfWeek.WEDNESDAY, "12:30", "14:00", "Développement Mobile", "Lamouchi O.", "SL MAC"),
        new SlotSeed("Ing Inf 2D", 2, Semester.S4, DayOfWeek.THURSDAY, "08:30", "10:00", "Prog. Sys. & Rx", "ElBedoui", "SL31"),
        new SlotSeed("Ing Inf 2D", 2, Semester.S4, DayOfWeek.THURSDAY, "10:10", "11:40", "Analyse des Données", "Ouerghi_H", "S32"),
        new SlotSeed("Ing Inf 2D", 2, Semester.S4, DayOfWeek.THURSDAY, "12:30", "14:00", "TLA & Compilation", "BenSalem", "S33"),
        new SlotSeed("Ing Inf 2D", 2, Semester.S4, DayOfWeek.THURSDAY, "14:10", "15:40", "Plateformes de Dev.", "Jaidi", "SL27"),
        new SlotSeed("Ing Inf 2D", 2, Semester.S4, DayOfWeek.FRIDAY, "08:30", "10:00", "TLA & Compilation", "BenSalem", "S30"),
        new SlotSeed("Ing Inf 2D", 2, Semester.S4, DayOfWeek.FRIDAY, "10:10", "11:40", "TLA & Compilation", "BenSalem", "S30"),
        new SlotSeed("Ing Inf 2D", 2, Semester.S4, DayOfWeek.FRIDAY, "12:30", "14:00", "Management de Projet", "Abbes", "S34"),
        new SlotSeed("Ing Inf 2D", 2, Semester.S4, DayOfWeek.FRIDAY, "14:10", "15:40", "Comm. en Entreprise", "Bedhief", "S34"),
        new SlotSeed("Ing Inf 2D", 2, Semester.S4, DayOfWeek.FRIDAY, "15:50", "17:20", "Sécu. Informatique", "Hermassi", "SL MAC"),
        new SlotSeed("Ing Inf 2D", 2, Semester.S4, DayOfWeek.SATURDAY, "08:30", "10:00", "Admin. Sys. et Rx.", "Melliti", "SL31"),
        new SlotSeed("Ing Inf 2D", 2, Semester.S4, DayOfWeek.SATURDAY, "10:10", "11:40", "Admin. Sys. et Rx.", "Melliti", "SL31")
    );
}
