package com.unigate.academic.security;

import com.unigate.academic.domain.entity.AcademicUser;
import com.unigate.academic.dto.auth.AuthUserResponse;
import com.unigate.academic.repository.AcademicUserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class CurrentUserService {

    private static final Set<String> ADMIN_AUTHORITIES = Set.of("ROLE_DEPARTMENT_ADMIN", "ROLE_SUPER_ADMIN");

    private final AcademicUserRepository userRepository;

    public Long currentStudentId() {
        return currentUser().getStudentId();
    }

    public Long resolveStudentId(Long requestedStudentId) {
        Long principalStudentId = currentStudentId();
        if (requestedStudentId == null) {
            return principalStudentId;
        }
        if (isCurrentUserAdmin() || requestedStudentId.equals(principalStudentId)) {
            return requestedStudentId;
        }
        throw new AccessDeniedException("Acces refuse: un etudiant ne peut consulter que ses propres donnees.");
    }

    public boolean isCurrentUserAdmin() {
        return currentAuthorities().stream().anyMatch(ADMIN_AUTHORITIES::contains);
    }

    public String currentUsername() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated() || "anonymousUser".equals(authentication.getName())) {
            throw new AccessDeniedException("Utilisateur non authentifie.");
        }
        return authentication.getName();
    }

    @Transactional(readOnly = true)
    public AcademicUser currentUser() {
        String username = currentUsername();
        return userRepository.findByUsernameIgnoreCase(username)
                .orElseThrow(() -> new AccessDeniedException("Utilisateur local introuvable: " + username));
    }

    @Transactional(readOnly = true)
    public AuthUserResponse toAuthResponse(Authentication authentication, String token) {
        String username = authentication.getName();
        AcademicUser user = userRepository.findByUsernameIgnoreCase(username).orElse(null);
        List<String> roles = authentication.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .map(role -> role.replace("ROLE_", ""))
                .sorted()
                .toList();

        return new AuthUserResponse(
                username,
                user == null ? null : user.getStudentId(),
                roles,
                user == null ? username : user.getDisplayName(),
                user == null ? null : user.getDefaultDepartment(),
                user == null ? null : user.getDefaultYear(),
                user == null ? null : user.getDefaultSemester(),
                user == null || user.getDefaultClassGroup() == null ? null : user.getDefaultClassGroup().getName(),
                "Basic",
                token
        );
    }

    private List<String> currentAuthorities() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null) {
            return List.of();
        }
        return authentication.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .toList();
    }
}
