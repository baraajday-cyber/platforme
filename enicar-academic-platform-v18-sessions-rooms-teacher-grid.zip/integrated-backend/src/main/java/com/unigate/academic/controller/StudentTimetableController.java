package com.unigate.academic.controller;

import com.unigate.academic.domain.enums.Semester;
import com.unigate.academic.dto.timetable.WeeklyTimetableResponse;
import com.unigate.academic.security.CurrentUserService;
import com.unigate.academic.service.TimetablePdfExportService;
import com.unigate.academic.service.TimetableService;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/student/academic/timetable")
@PreAuthorize("hasRole('STUDENT')")
public class StudentTimetableController {

    private final TimetableService timetableService;
    private final TimetablePdfExportService pdfExportService;
    private final CurrentUserService currentUserService;

    @GetMapping
    public WeeklyTimetableResponse myTimetable(
            @RequestParam(required = false) Long studentId,
            @RequestParam @NotNull Integer year,
            @RequestParam @NotNull Semester semester
    ) {
        Long resolvedStudentId = currentUserService.resolveStudentId(studentId);
        return timetableService.getStudentTimetable(resolvedStudentId, year, semester);
    }

    @GetMapping(value = "/export.pdf", produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<byte[]> exportPdf(
            @RequestParam(required = false) Long studentId,
            @RequestParam @NotNull Integer year,
            @RequestParam @NotNull Semester semester
    ) {
        Long resolvedStudentId = currentUserService.resolveStudentId(studentId);
        byte[] pdf = pdfExportService.exportStudentTimetable(resolvedStudentId, year, semester);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=emploi-du-temps-" + semester + ".pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .body(pdf);
    }
}
