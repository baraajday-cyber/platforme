package com.unigate.academic.domain.enums;

/**
 * UniGate currently covers the first two academic years only.
 * Therefore only four semesters are valid in the UI and API.
 */
public enum Semester {
    S1, S2, S3, S4
}
