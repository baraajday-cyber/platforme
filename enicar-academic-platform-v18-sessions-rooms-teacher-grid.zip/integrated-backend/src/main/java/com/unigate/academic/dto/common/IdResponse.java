package com.unigate.academic.dto.common;

public record IdResponse(Long id) {
}
