package com.unigate.academic.dto.grade;

public record GradeSimulationResponse(
        boolean persisted,
        StudentResultsResponse results
) {
}
