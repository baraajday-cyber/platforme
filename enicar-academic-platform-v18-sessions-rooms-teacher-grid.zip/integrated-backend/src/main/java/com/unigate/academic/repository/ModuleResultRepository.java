package com.unigate.academic.repository;

import com.unigate.academic.domain.entity.ModuleResult;
import com.unigate.academic.domain.enums.Semester;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ModuleResultRepository extends JpaRepository<ModuleResult, Long> {
    Optional<ModuleResult> findByStudentIdAndYearAndSemesterAndModuleId(Long studentId, Integer year, Semester semester, Long moduleId);
    List<ModuleResult> findByStudentIdAndDepartmentAndYearAndSemesterOrderByModuleNameAsc(Long studentId, String department, Integer year, Semester semester);
}
