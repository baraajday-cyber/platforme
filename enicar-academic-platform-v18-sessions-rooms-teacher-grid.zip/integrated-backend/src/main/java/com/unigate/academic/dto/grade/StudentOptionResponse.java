package com.unigate.academic.dto.grade;

public record StudentOptionResponse(
        Long id,
        String code,
        String fullName,
        String defaultDepartment,
        Integer defaultYear,
        String defaultSemester,
        Long classGroupId,
        String classGroupName
) {
}
