package com.unigate.academic.service;

import com.unigate.academic.common.exception.BusinessRuleException;
import com.unigate.academic.common.exception.ResourceNotFoundException;
import com.unigate.academic.config.CacheConfig;
import com.unigate.academic.domain.entity.AcademicModule;
import com.unigate.academic.domain.entity.Course;
import com.unigate.academic.domain.entity.GradeConfig;
import com.unigate.academic.domain.enums.Semester;
import com.unigate.academic.dto.grade.GradeConfigRequest;
import com.unigate.academic.dto.grade.GradeConfigResponse;
import com.unigate.academic.mapper.AcademicMapper;
import com.unigate.academic.repository.AcademicModuleRepository;
import com.unigate.academic.repository.CourseRepository;
import com.unigate.academic.repository.GradeConfigRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class GradeConfigService {

    private static final BigDecimal ONE = BigDecimal.ONE;

    private final GradeConfigRepository gradeConfigRepository;
    private final CourseRepository courseRepository;
    private final AcademicModuleRepository academicModuleRepository;
    private final AcademicMapper mapper;

    @CacheEvict(cacheNames = CacheConfig.GRADE_CONFIGS, allEntries = true)
    public GradeConfigResponse upsertConfig(GradeConfigRequest request) {
        validateWeights(request.ccWeight(), request.examWeight(), request.tpWeight());
        Course subject = courseRepository.findById(request.subjectId())
                .orElseThrow(() -> new ResourceNotFoundException("Subject/course not found: " + request.subjectId()));
        AcademicModule module = academicModuleRepository.findById(request.moduleId())
                .orElseThrow(() -> new ResourceNotFoundException("Academic module not found: " + request.moduleId()));

        GradeConfig config = gradeConfigRepository.findByDepartmentAndYearAndSemesterAndSubjectIdAndModuleId(
                request.department(), request.year(), request.semester(), request.subjectId(), request.moduleId()
        ).orElseGet(GradeConfig::new);

        config.setDepartment(request.department().trim());
        config.setYear(request.year());
        config.setSemester(request.semester());
        config.setSubject(subject);
        config.setModule(module);
        config.setSubjectCoefficient(request.subjectCoefficient());
        config.setModuleCoefficient(request.moduleCoefficient());
        config.setCcWeight(request.ccWeight());
        config.setExamWeight(request.examWeight());
        config.setTpWeight(request.tpWeight());
        config.setCredits(request.credits());
        config.setActive(true);

        return mapper.toGradeConfigResponse(gradeConfigRepository.save(config));
    }

    @Transactional(readOnly = true)
    @Cacheable(cacheNames = CacheConfig.GRADE_CONFIGS, key = "#department + '-' + #year + '-' + #semester")
    public List<GradeConfigResponse> listActiveConfigs(String department, Integer year, Semester semester) {
        return gradeConfigRepository.findByDepartmentAndYearAndSemesterAndActiveTrueOrderByModuleNameAscSubjectNameAsc(department, year, semester)
                .stream()
                .map(mapper::toGradeConfigResponse)
                .toList();
    }

    @CacheEvict(cacheNames = CacheConfig.GRADE_CONFIGS, allEntries = true)
    public void deactivateConfig(Long id) {
        GradeConfig config = gradeConfigRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Grade config not found: " + id));
        config.setActive(false);
    }

    public void validateWeights(BigDecimal ccWeight, BigDecimal examWeight, BigDecimal tpWeight) {
        BigDecimal total = ccWeight.add(examWeight).add(tpWeight).stripTrailingZeros();
        if (total.compareTo(ONE) != 0) {
            throw new BusinessRuleException("Grade weights must sum to 1.00. Current total = " + total);
        }
    }
}
