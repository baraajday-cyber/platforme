package com.unigate.academic.dto.timetable;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record CancelSlotRequest(
        @NotBlank @Size(max = 500) String reason
) {
}
