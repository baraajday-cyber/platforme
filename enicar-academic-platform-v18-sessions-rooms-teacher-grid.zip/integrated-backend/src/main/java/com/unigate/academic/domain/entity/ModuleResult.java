package com.unigate.academic.domain.entity;

import com.unigate.academic.domain.converter.RequiredExamGradesConverter;
import com.unigate.academic.domain.enums.Semester;
import com.unigate.academic.domain.vo.RequiredExamGrade;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(
        name = "module_results",
        uniqueConstraints = @UniqueConstraint(name = "uk_module_result_student", columnNames = {"student_id", "academic_year", "semester", "module_id"})
)
public class ModuleResult extends BaseEntity {

    @Column(name = "student_id", nullable = false)
    private Long studentId;

    @Column(nullable = false, length = 80)
    private String department;

    @Column(name = "academic_year", nullable = false)
    private Integer year;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Semester semester;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "module_id", nullable = false)
    private AcademicModule module;

    @Column(name = "module_average", precision = 5, scale = 2)
    private BigDecimal moduleAverage;

    @Column(name = "credits_earned", nullable = false)
    private Integer creditsEarned;

    @Column(nullable = false)
    private boolean validated;

    @Builder.Default
    @Convert(converter = RequiredExamGradesConverter.class)
    @Column(name = "required_exam_grades", columnDefinition = "TEXT")
    private Map<Long, RequiredExamGrade> requiredExamGrades = new LinkedHashMap<>();
}
