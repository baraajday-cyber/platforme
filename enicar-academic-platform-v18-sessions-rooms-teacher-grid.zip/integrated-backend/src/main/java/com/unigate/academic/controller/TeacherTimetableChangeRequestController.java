package com.unigate.academic.controller;

import com.unigate.academic.dto.timetable.TimetableChangeRequestCreateRequest;
import com.unigate.academic.dto.timetable.TimetableChangeRequestResponse;
import com.unigate.academic.service.TimetableChangeRequestService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/teacher/academic/timetable/change-requests")
@PreAuthorize("hasRole('TEACHER')")
public class TeacherTimetableChangeRequestController {

    private final TimetableChangeRequestService requestService;

    @GetMapping
    public List<TimetableChangeRequestResponse> myRequests(Authentication authentication) {
        return requestService.listForTeacher(authentication.getName());
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public TimetableChangeRequestResponse create(@Valid @RequestBody TimetableChangeRequestCreateRequest request,
                                                 Authentication authentication) {
        return requestService.create(authentication.getName(), request);
    }
}
