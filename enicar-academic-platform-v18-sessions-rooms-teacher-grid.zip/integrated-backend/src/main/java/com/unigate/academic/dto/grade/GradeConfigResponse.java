package com.unigate.academic.dto.grade;

import com.unigate.academic.domain.enums.Semester;

import java.math.BigDecimal;

public record GradeConfigResponse(
        Long id,
        String department,
        Integer year,
        Semester semester,
        Long subjectId,
        String subjectName,
        Long moduleId,
        String moduleName,
        BigDecimal subjectCoefficient,
        BigDecimal moduleCoefficient,
        BigDecimal ccWeight,
        BigDecimal examWeight,
        BigDecimal tpWeight,
        Integer credits,
        boolean active
) {
}
