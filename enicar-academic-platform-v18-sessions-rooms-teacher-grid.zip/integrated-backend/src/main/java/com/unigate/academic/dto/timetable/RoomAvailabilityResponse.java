package com.unigate.academic.dto.timetable;

import java.time.DayOfWeek;
import java.time.LocalTime;

public record RoomAvailabilityResponse(
        boolean available,
        String room,
        DayOfWeek dayOfWeek,
        LocalTime startTime,
        LocalTime endTime,
        String message
) {
}
