package com.unigate.academic.dto.timetable;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.DayOfWeek;
import java.time.LocalTime;

public record TimetableSlotRequest(
        @NotNull Long classGroupId,
        @NotNull Long courseId,
        @NotNull DayOfWeek dayOfWeek,
        @NotNull LocalTime startTime,
        @NotNull LocalTime endTime,
        @NotBlank @Size(max = 80) String room,
        Long professorId,
        @Size(max = 120) String professorName
) {
}
