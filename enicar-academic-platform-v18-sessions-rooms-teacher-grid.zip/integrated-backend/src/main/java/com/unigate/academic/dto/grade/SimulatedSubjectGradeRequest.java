package com.unigate.academic.dto.grade;

import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

public record SimulatedSubjectGradeRequest(
        @NotNull Long subjectId,
        @DecimalMin("0.00") @DecimalMax("20.00") BigDecimal ccGrade,
        @DecimalMin("0.00") @DecimalMax("20.00") BigDecimal examGrade,
        @DecimalMin("0.00") @DecimalMax("20.00") BigDecimal tpGrade
) {
}
