package com.unigate.academic.domain.entity;

import com.unigate.academic.domain.enums.Semester;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(
        name = "semester_results",
        uniqueConstraints = @UniqueConstraint(name = "uk_semester_result_student", columnNames = {"student_id", "department", "academic_year", "semester"})
)
public class SemesterResult extends BaseEntity {

    @Column(name = "student_id", nullable = false)
    private Long studentId;

    @Column(nullable = false, length = 80)
    private String department;

    @Column(name = "academic_year", nullable = false)
    private Integer year;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Semester semester;

    @Column(name = "semester_average", precision = 5, scale = 2)
    private BigDecimal semesterAverage;

    @Column(name = "total_credits", nullable = false)
    private Integer totalCredits;

    @Column(nullable = false)
    private boolean validated;
}
