package com.unigate.academic.dto.timetable;

import com.unigate.academic.domain.enums.Semester;

import java.math.BigDecimal;

public record AcademicModuleResponse(
        Long id,
        String name,
        String department,
        Integer year,
        Semester semester,
        BigDecimal moduleCoefficient,
        Integer credits
) {
}
