package com.unigate.academic.dto.grade;

import com.unigate.academic.domain.enums.Semester;

import java.math.BigDecimal;
import java.util.List;

public record ModuleResultResponse(
        Long id,
        Long moduleId,
        String moduleName,
        String department,
        Integer year,
        Semester semester,
        BigDecimal moduleAverage,
        Integer creditsEarned,
        Integer moduleCredits,
        boolean complete,
        boolean validated,
        List<RequiredExamGradeResponse> requiredExamGrades
) {
}
