package com.unigate.academic.service;

import com.unigate.academic.common.exception.BusinessRuleException;
import com.unigate.academic.common.exception.ForbiddenAcademicAccessException;
import com.unigate.academic.common.exception.ResourceNotFoundException;
import com.unigate.academic.domain.entity.AcademicUser;
import com.unigate.academic.domain.entity.TimetableChangeRequest;
import com.unigate.academic.domain.entity.TimetableSlot;
import com.unigate.academic.domain.enums.TimetableChangeRequestStatus;
import com.unigate.academic.dto.timetable.TimetableChangeDecisionRequest;
import com.unigate.academic.dto.timetable.TimetableChangeRequestCreateRequest;
import com.unigate.academic.dto.timetable.TimetableChangeRequestResponse;
import com.unigate.academic.dto.timetable.TimetableSlotMoveRequest;
import com.unigate.academic.repository.TimetableChangeRequestRepository;
import com.unigate.academic.repository.TimetableSlotRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.Locale;

@Service
@RequiredArgsConstructor
@Transactional
public class TimetableChangeRequestService {

    private final TimetableChangeRequestRepository requestRepository;
    private final TimetableSlotRepository slotRepository;
    private final TeacherManagementService teacherManagementService;
    private final TimetableService timetableService;

    @Transactional(readOnly = true)
    public List<TimetableChangeRequestResponse> listForAdmin(TimetableChangeRequestStatus status) {
        return requestRepository.findAllWithDetails(status).stream().map(this::toResponse).toList();
    }

    @Transactional(readOnly = true)
    public List<TimetableChangeRequestResponse> listForTeacher(String username) {
        AcademicUser teacher = teacherManagementService.teacherByUsername(username);
        return requestRepository.findByTeacherWithDetails(teacher.getId()).stream().map(this::toResponse).toList();
    }

    public TimetableChangeRequestResponse create(String username, TimetableChangeRequestCreateRequest request) {
        AcademicUser teacher = teacherManagementService.teacherByUsername(username);
        TimetableSlot slot = slotRepository.findById(request.slotId())
                .orElseThrow(() -> new ResourceNotFoundException("Seance introuvable: " + request.slotId()));
        ensureTeacherOwnsSlot(username, slot);

        TimetableSlotMoveRequest move = new TimetableSlotMoveRequest(
                request.dayOfWeek(),
                request.startTime(),
                request.endTime(),
                request.room(),
                slot.getProfessorId(),
                slot.getProfessorName(),
                cleanReason(request.reason(), "Demande enseignant")
        );
        timetableService.validateMoveCandidate(slot.getId(), move);

        TimetableChangeRequest saved = requestRepository.save(TimetableChangeRequest.builder()
                .teacher(teacher)
                .slot(slot)
                .requestedDayOfWeek(request.dayOfWeek())
                .requestedStartTime(request.startTime())
                .requestedEndTime(request.endTime())
                .requestedRoom(request.room().trim())
                .reason(cleanReason(request.reason(), "Demande enseignant"))
                .status(TimetableChangeRequestStatus.PENDING)
                .build());
        return toResponse(saved);
    }

    public TimetableChangeRequestResponse approve(Long id, TimetableChangeDecisionRequest decision) {
        TimetableChangeRequest request = getRequest(id);
        ensurePending(request);
        TimetableSlot slot = request.getSlot();
        TimetableSlotMoveRequest move = new TimetableSlotMoveRequest(
                request.getRequestedDayOfWeek(),
                request.getRequestedStartTime(),
                request.getRequestedEndTime(),
                request.getRequestedRoom(),
                slot.getProfessorId(),
                slot.getProfessorName(),
                cleanReason(decision == null ? null : decision.message(), "Demande enseignant acceptee")
        );
        timetableService.moveSlot(slot.getId(), move);
        request.setStatus(TimetableChangeRequestStatus.APPROVED);
        request.setAdminResponse(cleanReason(decision == null ? null : decision.message(), "Demande acceptee par l'administration"));
        request.setDecidedAt(Instant.now());
        return toResponse(request);
    }

    public TimetableChangeRequestResponse reject(Long id, TimetableChangeDecisionRequest decision) {
        TimetableChangeRequest request = getRequest(id);
        ensurePending(request);
        request.setStatus(TimetableChangeRequestStatus.REJECTED);
        request.setAdminResponse(cleanReason(decision == null ? null : decision.message(), "Demande refusee par l'administration"));
        request.setDecidedAt(Instant.now());
        return toResponse(request);
    }

    private TimetableChangeRequest getRequest(Long id) {
        return requestRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Demande introuvable: " + id));
    }

    private void ensurePending(TimetableChangeRequest request) {
        if (request.getStatus() != TimetableChangeRequestStatus.PENDING) {
            throw new BusinessRuleException("Cette demande est deja traitee");
        }
    }

    private void ensureTeacherOwnsSlot(String username, TimetableSlot slot) {
        if (!teacherManagementService.canTeach(username, slot.getCourse().getId())) {
            String assigned = teacherManagementService.assignedCourseNamesLowerForUsername(username).toString();
            String course = slot.getCourse() == null ? "" : slot.getCourse().getName().toLowerCase(Locale.ROOT);
            boolean nameMatch = teacherManagementService.assignedCourseNamesLowerForUsername(username).contains(course);
            if (!nameMatch) {
                throw new ForbiddenAcademicAccessException("Vous pouvez demander un changement seulement pour vos matieres affectees. Affectations: " + assigned);
            }
        }
    }

    private String cleanReason(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value.trim();
    }

    private TimetableChangeRequestResponse toResponse(TimetableChangeRequest request) {
        TimetableSlot slot = request.getSlot();
        return new TimetableChangeRequestResponse(
                request.getId(),
                request.getStatus(),
                request.getTeacher().getId(),
                request.getTeacher().getDisplayName(),
                slot.getId(),
                slot.getCourse() == null ? "" : slot.getCourse().getName(),
                slot.getClassGroup() == null ? "" : slot.getClassGroup().getName(),
                slot.getDayOfWeek(),
                slot.getStartTime(),
                slot.getEndTime(),
                slot.getRoom(),
                request.getRequestedDayOfWeek(),
                request.getRequestedStartTime(),
                request.getRequestedEndTime(),
                request.getRequestedRoom(),
                request.getReason(),
                request.getAdminResponse(),
                request.getCreatedAt(),
                request.getDecidedAt()
        );
    }
}
