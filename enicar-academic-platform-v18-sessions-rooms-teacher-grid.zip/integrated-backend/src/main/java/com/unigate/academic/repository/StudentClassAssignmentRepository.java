package com.unigate.academic.repository;

import com.unigate.academic.domain.entity.StudentClassAssignment;
import com.unigate.academic.domain.enums.Semester;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface StudentClassAssignmentRepository extends JpaRepository<StudentClassAssignment, Long> {
    Optional<StudentClassAssignment> findByStudentIdAndYearAndSemesterAndActiveTrue(Long studentId, Integer year, Semester semester);
    List<StudentClassAssignment> findByClassGroupIdAndActiveTrue(Long classGroupId);
}
