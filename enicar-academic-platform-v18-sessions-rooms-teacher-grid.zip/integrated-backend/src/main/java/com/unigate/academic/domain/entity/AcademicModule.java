package com.unigate.academic.domain.entity;

import com.unigate.academic.domain.enums.Semester;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(
        name = "academic_modules",
        uniqueConstraints = @UniqueConstraint(name = "uk_academic_module_identity", columnNames = {"name", "department", "academic_year", "semester"})
)
public class AcademicModule extends BaseEntity {

    @Column(nullable = false, length = 120)
    private String name;

    @Column(nullable = false, length = 80)
    private String department;

    @Column(name = "academic_year", nullable = false)
    private Integer year;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Semester semester;

    @Column(precision = 5, scale = 2)
    private BigDecimal moduleCoefficient;

    @Column(nullable = false)
    private Integer credits;
}
