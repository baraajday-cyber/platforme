package com.unigate.academic.domain.enums;

public enum TimetableChangeRequestStatus {
    PENDING,
    APPROVED,
    REJECTED
}
