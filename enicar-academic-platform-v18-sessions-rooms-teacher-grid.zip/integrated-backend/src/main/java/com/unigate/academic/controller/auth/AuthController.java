package com.unigate.academic.controller.auth;

import com.unigate.academic.dto.auth.AuthUserResponse;
import com.unigate.academic.dto.auth.LoginRequest;
import com.unigate.academic.security.CurrentUserService;
import jakarta.validation.Valid;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final CurrentUserService currentUserService;

    public AuthController(AuthenticationManager authenticationManager, CurrentUserService currentUserService) {
        this.authenticationManager = authenticationManager;
        this.currentUserService = currentUserService;
    }

    @PostMapping("/login")
    public AuthUserResponse login(@Valid @RequestBody LoginRequest request) {
        String username = request.username().trim();
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(username, request.password())
        );
        String token = Base64.getEncoder().encodeToString((username + ":" + request.password()).getBytes(StandardCharsets.UTF_8));
        return currentUserService.toAuthResponse(authentication, token);
    }

    @GetMapping("/me")
    public AuthUserResponse me(Authentication authentication) {
        return currentUserService.toAuthResponse(authentication, null);
    }
}
