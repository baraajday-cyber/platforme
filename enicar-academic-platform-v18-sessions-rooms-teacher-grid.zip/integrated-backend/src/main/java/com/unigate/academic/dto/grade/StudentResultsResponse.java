package com.unigate.academic.dto.grade;

import java.util.List;

public record StudentResultsResponse(
        List<StudentGradeResponse> grades,
        List<ModuleResultResponse> modules,
        SemesterResultResponse semester
) {
}
