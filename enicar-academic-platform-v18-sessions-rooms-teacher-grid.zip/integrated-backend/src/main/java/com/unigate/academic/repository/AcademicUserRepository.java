package com.unigate.academic.repository;

import com.unigate.academic.domain.entity.AcademicUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface AcademicUserRepository extends JpaRepository<AcademicUser, Long> {
    Optional<AcademicUser> findByUsernameIgnoreCase(String username);
    Optional<AcademicUser> findByStudentId(Long studentId);
    boolean existsByUsernameIgnoreCase(String username);

    @Query("select coalesce(max(u.studentId), 0) from AcademicUser u")
    Long maxStudentId();

    List<AcademicUser> findByRolesCsvContainingIgnoreCaseOrderByDisplayNameAsc(String role);
}
