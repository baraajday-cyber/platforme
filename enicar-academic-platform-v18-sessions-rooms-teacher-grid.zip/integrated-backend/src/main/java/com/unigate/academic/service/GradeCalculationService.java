package com.unigate.academic.service;

import com.unigate.academic.common.exception.BusinessRuleException;
import com.unigate.academic.common.exception.ResourceNotFoundException;
import com.unigate.academic.domain.entity.AcademicModule;
import com.unigate.academic.domain.entity.Course;
import com.unigate.academic.domain.entity.GradeConfig;
import com.unigate.academic.domain.entity.ModuleResult;
import com.unigate.academic.domain.entity.SemesterResult;
import com.unigate.academic.domain.entity.StudentGrade;
import com.unigate.academic.domain.enums.Semester;
import com.unigate.academic.domain.math.GradeMath;
import com.unigate.academic.domain.vo.RequiredExamGrade;
import com.unigate.academic.dto.grade.GradeSimulationRequest;
import com.unigate.academic.dto.grade.GradeSimulationResponse;
import com.unigate.academic.dto.grade.ModuleResultResponse;
import com.unigate.academic.dto.grade.SemesterResultResponse;
import com.unigate.academic.dto.grade.SimulatedSubjectGradeRequest;
import com.unigate.academic.dto.grade.StudentGradeResponse;
import com.unigate.academic.dto.grade.StudentOptionResponse;
import com.unigate.academic.dto.grade.StudentGradeUpsertRequest;
import com.unigate.academic.dto.grade.StudentResultsResponse;
import com.unigate.academic.integration.AcademicNotificationPort;
import com.unigate.academic.integration.StudentAccessPort;
import com.unigate.academic.mapper.AcademicMapper;
import com.unigate.academic.repository.CourseRepository;
import com.unigate.academic.repository.GradeConfigRepository;
import com.unigate.academic.repository.ModuleResultRepository;
import com.unigate.academic.repository.SemesterResultRepository;
import com.unigate.academic.repository.StudentGradeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class GradeCalculationService {

    private static final MathContext MC = MathContext.DECIMAL64;

    private final GradeConfigRepository gradeConfigRepository;
    private final StudentGradeRepository studentGradeRepository;
    private final ModuleResultRepository moduleResultRepository;
    private final SemesterResultRepository semesterResultRepository;
    private final CourseRepository courseRepository;
    private final StudentAccessPort studentAccessPort;
    private final AcademicNotificationPort notificationPort;
    private final AcademicMapper mapper;
    private final StudentManagementService studentManagementService;
    private final TeacherManagementService teacherManagementService;

    @Value("${unigate.academic.semester-validation-min-credits:30}")
    private int semesterValidationMinCredits;

    public StudentResultsResponse upsertGrade(Long studentId, StudentGradeUpsertRequest request) {
        return upsertGrade(studentId, request, null);
    }

    public StudentResultsResponse upsertGrade(Long studentId, StudentGradeUpsertRequest request, String username) {
        studentAccessPort.assertStudentIsEnrolled(studentId);
        GradeConfig config = gradeConfigRepository
                .findByDepartmentAndYearAndSemesterAndSubjectIdAndActiveTrue(request.department(), request.year(), request.semester(), request.subjectId())
                .orElseThrow(() -> new ResourceNotFoundException("No active grade config for subject " + request.subjectId()));
        if (username != null) {
            teacherManagementService.assertCanTeach(username, request.subjectId());
        }

        validateGradeValue(request.ccGrade(), "CC");
        validateGradeValue(request.examGrade(), "Exam");
        validateGradeValue(request.tpGrade(), "TP");

        Course subject = courseRepository.findById(request.subjectId())
                .orElseThrow(() -> new ResourceNotFoundException("Subject/course not found: " + request.subjectId()));

        StudentGrade grade = studentGradeRepository.findByStudentIdAndYearAndSemesterAndSubjectId(
                        studentId, request.year(), request.semester(), request.subjectId())
                .orElseGet(StudentGrade::new);
        grade.setStudentId(studentId);
        grade.setDepartment(request.department().trim());
        grade.setYear(request.year());
        grade.setSemester(request.semester());
        grade.setSubject(subject);
        grade.setCcGrade(request.ccGrade());
        grade.setExamGrade(request.examGrade());
        grade.setTpGrade(request.tpGrade());
        computeAndAttachSubjectAverage(grade, config);
        studentGradeRepository.save(grade);

        StudentResultsResponse results = recalculateAndPersist(studentId, request.department(), request.year(), request.semester());
        notificationPort.notifyGradeUpdated(studentId, results);
        return results;
    }


    @Transactional(readOnly = true)
    public List<StudentOptionResponse> listLocalStudentOptions() {
        return studentManagementService.listStudentOptions();
    }

    @Transactional(readOnly = true)
    public List<StudentOptionResponse> listLocalStudentOptions(String username) {
        return studentManagementService.listStudentOptions();
    }

    public void deleteGrade(Long gradeId) {
        deleteGrade(gradeId, null);
    }

    public void deleteGrade(Long gradeId, String username) {
        StudentGrade grade = studentGradeRepository.findById(gradeId)
                .orElseThrow(() -> new ResourceNotFoundException("Student grade not found: " + gradeId));
        if (username != null) {
            teacherManagementService.assertCanTeach(username, grade.getSubject().getId());
        }
        Long studentId = grade.getStudentId();
        String department = grade.getDepartment();
        Integer year = grade.getYear();
        Semester semester = grade.getSemester();
        studentGradeRepository.delete(grade);
        StudentResultsResponse results = recalculateAndPersist(studentId, department, year, semester);
        notificationPort.notifyGradeUpdated(studentId, results);
    }

    @Transactional(readOnly = true)
    public StudentResultsResponse getStudentResults(Long studentId, String department, Integer year, Semester semester) {
        return getStudentResults(studentId, department, year, semester, null);
    }

    @Transactional(readOnly = true)
    public StudentResultsResponse getStudentResults(Long studentId, String department, Integer year, Semester semester, String username) {
        studentAccessPort.assertStudentIsEnrolled(studentId);
        List<GradeConfig> configs = loadConfigsForUser(department, year, semester, username);
        Map<Long, StudentGrade> gradeBySubject = studentGradeRepository
                .findByStudentIdAndDepartmentAndYearAndSemester(studentId, department, year, semester)
                .stream()
                .collect(Collectors.toMap(g -> g.getSubject().getId(), Function.identity(), (a, b) -> a, LinkedHashMap::new));
        CalculationSnapshot snapshot = calculateSnapshot(studentId, department, year, semester, configs, gradeBySubject, false);
        return snapshot.toResponse();
    }

    public StudentResultsResponse recalculateAndPersist(Long studentId, String department, Integer year, Semester semester) {
        List<GradeConfig> configs = loadConfigs(department, year, semester);
        Map<Long, StudentGrade> gradeBySubject = studentGradeRepository
                .findByStudentIdAndDepartmentAndYearAndSemester(studentId, department, year, semester)
                .stream()
                .collect(Collectors.toMap(g -> g.getSubject().getId(), Function.identity(), (a, b) -> a, LinkedHashMap::new));
        CalculationSnapshot snapshot = calculateSnapshot(studentId, department, year, semester, configs, gradeBySubject, true);
        return snapshot.toResponse();
    }

    @Transactional(readOnly = true)
    public GradeSimulationResponse simulate(Long studentId, GradeSimulationRequest request) {
        studentAccessPort.assertStudentIsEnrolled(studentId);
        List<GradeConfig> configs = loadConfigs(request.department(), request.year(), request.semester());
        Map<Long, StudentGrade> gradeBySubject = studentGradeRepository
                .findByStudentIdAndDepartmentAndYearAndSemester(studentId, request.department(), request.year(), request.semester())
                .stream()
                .map(this::copyGrade)
                .collect(Collectors.toMap(g -> g.getSubject().getId(), Function.identity(), (a, b) -> a, LinkedHashMap::new));

        if (request.simulatedGrades() != null) {
            for (SimulatedSubjectGradeRequest simulated : request.simulatedGrades()) {
                validateGradeValue(simulated.ccGrade(), "CC");
                validateGradeValue(simulated.examGrade(), "Exam");
                validateGradeValue(simulated.tpGrade(), "TP");
                GradeConfig config = configs.stream()
                        .filter(c -> c.getSubject().getId().equals(simulated.subjectId()))
                        .findFirst()
                        .orElseThrow(() -> new ResourceNotFoundException("No active grade config for simulated subject " + simulated.subjectId()));
                StudentGrade grade = gradeBySubject.computeIfAbsent(simulated.subjectId(), subjectId -> StudentGrade.builder()
                        .studentId(studentId)
                        .department(request.department())
                        .year(request.year())
                        .semester(request.semester())
                        .subject(config.getSubject())
                        .build());
                if (simulated.ccGrade() != null) {
                    grade.setCcGrade(simulated.ccGrade());
                }
                if (simulated.examGrade() != null) {
                    grade.setExamGrade(simulated.examGrade());
                }
                if (simulated.tpGrade() != null) {
                    grade.setTpGrade(simulated.tpGrade());
                }
                computeAndAttachSubjectAverage(grade, config);
            }
        }

        CalculationSnapshot snapshot = calculateSnapshot(studentId, request.department(), request.year(), request.semester(), configs, gradeBySubject, false);
        return new GradeSimulationResponse(false, snapshot.toResponse());
    }

    private CalculationSnapshot calculateSnapshot(
            Long studentId,
            String department,
            Integer year,
            Semester semester,
            List<GradeConfig> configs,
            Map<Long, StudentGrade> gradeBySubject,
            boolean persist
    ) {
        List<StudentGradeResponse> gradeResponses = new ArrayList<>();
        for (GradeConfig config : configs) {
            StudentGrade grade = gradeBySubject.get(config.getSubject().getId());
            if (grade == null) {
                gradeResponses.add(mapper.toMissingStudentGradeResponse(studentId, config));
            } else {
                computeAndAttachSubjectAverage(grade, config);
                if (persist) {
                    studentGradeRepository.save(grade);
                }
                gradeResponses.add(mapper.toStudentGradeResponse(grade, config, isSubjectComplete(grade, config)));
            }
        }

        Map<Long, List<GradeConfig>> configsByModule = configs.stream()
                .collect(Collectors.groupingBy(c -> c.getModule().getId(), LinkedHashMap::new, Collectors.toList()));

        List<ModuleCalc> moduleCalcs = configsByModule.values().stream()
                .map(moduleConfigs -> calculateModule(studentId, department, year, semester, moduleConfigs, gradeBySubject, persist))
                .sorted(Comparator.comparing(calc -> calc.result().getModule().getName(), String.CASE_INSENSITIVE_ORDER))
                .toList();

        SemesterCalc semesterCalc = calculateSemester(studentId, department, year, semester, moduleCalcs, persist);

        return new CalculationSnapshot(gradeResponses, moduleCalcs, semesterCalc);
    }

    private ModuleCalc calculateModule(
            Long studentId,
            String department,
            Integer year,
            Semester semester,
            List<GradeConfig> moduleConfigs,
            Map<Long, StudentGrade> gradeBySubject,
            boolean persist
    ) {
        AcademicModule module = moduleConfigs.get(0).getModule();
        BigDecimal totalSubjectCoefficient = moduleConfigs.stream()
                .map(GradeConfig::getSubjectCoefficient)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal gradedCoefficient = BigDecimal.ZERO;
        BigDecimal weightedSum = BigDecimal.ZERO;
        boolean complete = true;
        for (GradeConfig config : moduleConfigs) {
            StudentGrade grade = gradeBySubject.get(config.getSubject().getId());
            if (grade == null || !isSubjectComplete(grade, config)) {
                complete = false;
                continue;
            }
            BigDecimal average = GradeMath.nullToZero(grade.getSubjectAverage());
            weightedSum = weightedSum.add(average.multiply(config.getSubjectCoefficient(), MC), MC);
            gradedCoefficient = gradedCoefficient.add(config.getSubjectCoefficient(), MC);
        }
        BigDecimal moduleAverage = gradedCoefficient.compareTo(BigDecimal.ZERO) == 0
                ? null
                : GradeMath.round(weightedSum.divide(gradedCoefficient, 6, RoundingMode.HALF_UP));
        boolean validated = complete && moduleAverage != null && moduleAverage.compareTo(GradeMath.VALIDATION_MARK) >= 0;
        int moduleCredits = resolveModuleCredits(moduleConfigs);
        int creditsEarned = validated ? moduleCredits : 0;
        Map<Long, RequiredExamGrade> required = buildRequiredExamGrades(moduleConfigs, gradeBySubject, totalSubjectCoefficient);

        ModuleResult result = persist
                ? moduleResultRepository.findByStudentIdAndYearAndSemesterAndModuleId(studentId, year, semester, module.getId()).orElseGet(ModuleResult::new)
                : new ModuleResult();
        result.setStudentId(studentId);
        result.setDepartment(department);
        result.setYear(year);
        result.setSemester(semester);
        result.setModule(module);
        result.setModuleAverage(moduleAverage);
        result.setCreditsEarned(creditsEarned);
        result.setValidated(validated);
        result.setRequiredExamGrades(required);
        if (persist) {
            result = moduleResultRepository.save(result);
        }
        return new ModuleCalc(result, complete, moduleCredits, firstNonNull(moduleConfigs.get(0).getModuleCoefficient(), module.getModuleCoefficient(), BigDecimal.ONE));
    }

    private SemesterCalc calculateSemester(Long studentId, String department, Integer year, Semester semester, List<ModuleCalc> moduleCalcs, boolean persist) {
        BigDecimal weightedSum = BigDecimal.ZERO;
        BigDecimal totalCoefficient = BigDecimal.ZERO;
        int totalCredits = 0;
        boolean complete = true;
        for (ModuleCalc calc : moduleCalcs) {
            BigDecimal coeff = firstNonNull(calc.moduleCoefficient(), BigDecimal.ONE);
            if (calc.result().getModuleAverage() != null) {
                weightedSum = weightedSum.add(calc.result().getModuleAverage().multiply(coeff, MC), MC);
                totalCoefficient = totalCoefficient.add(coeff, MC);
            }
            totalCredits += calc.result().getCreditsEarned();
            if (!calc.complete()) {
                complete = false;
            }
        }
        BigDecimal provisionalSemesterAverage = totalCoefficient.compareTo(BigDecimal.ZERO) == 0
                ? null
                : GradeMath.round(weightedSum.divide(totalCoefficient, 6, RoundingMode.HALF_UP));

        // La moyenne generale affichee a l'etudiant doit etre une moyenne finale fiable.
        // Si plusieurs matieres sont encore vides, on ne publie pas une moyenne trompeuse basee
        // uniquement sur quelques notes saisies. Les moyennes matiere/module restent visibles.
        BigDecimal semesterAverage = complete ? provisionalSemesterAverage : null;

        boolean validated = complete
                && semesterAverage != null
                && semesterAverage.compareTo(GradeMath.VALIDATION_MARK) >= 0
                && totalCredits >= semesterValidationMinCredits;

        SemesterResult result = persist
                ? semesterResultRepository.findByStudentIdAndDepartmentAndYearAndSemester(studentId, department, year, semester).orElseGet(SemesterResult::new)
                : new SemesterResult();
        result.setStudentId(studentId);
        result.setDepartment(department);
        result.setYear(year);
        result.setSemester(semester);
        result.setSemesterAverage(semesterAverage);
        result.setTotalCredits(totalCredits);
        result.setValidated(validated);
        if (persist) {
            result = semesterResultRepository.save(result);
        }
        return new SemesterCalc(result, complete);
    }

    private Map<Long, RequiredExamGrade> buildRequiredExamGrades(List<GradeConfig> moduleConfigs, Map<Long, StudentGrade> gradeBySubject, BigDecimal totalSubjectCoefficient) {
        Map<Long, RequiredExamGrade> result = new LinkedHashMap<>();
        for (GradeConfig config : moduleConfigs) {
            StudentGrade grade = gradeBySubject.get(config.getSubject().getId());
            if (grade == null || grade.getExamGrade() != null) {
                continue;
            }
            BigDecimal fixedContribution = calculateFixedContributionWithoutSubject(moduleConfigs, gradeBySubject, config.getSubject().getId());
            RequiredExamGrade required = buildRequiredExamGrade(config, grade, fixedContribution, totalSubjectCoefficient);
            result.put(config.getSubject().getId(), required);
        }
        return result;
    }

    private RequiredExamGrade buildRequiredExamGrade(GradeConfig config, StudentGrade grade, BigDecimal fixedContribution, BigDecimal totalSubjectCoefficient) {
        if (grade.getCcGrade() == null || (GradeMath.positive(config.getTpWeight()) && grade.getTpGrade() == null)) {
            return RequiredExamGrade.builder()
                    .subjectId(config.getSubject().getId())
                    .subjectName(config.getSubject().getName())
                    .status("MISSING_CONTINUOUS_GRADE")
                    .message("Saisir d'abord la note CC" + (GradeMath.positive(config.getTpWeight()) ? " et TP" : "") + " pour calculer la note d'examen necessaire.")
                    .build();
        }

        Optional<BigDecimal> forSubject = GradeMath.requiredExamForSubject(
                GradeMath.VALIDATION_MARK,
                grade.getCcGrade(),
                grade.getTpGrade(),
                config.getCcWeight(),
                config.getExamWeight(),
                config.getTpWeight()
        );
        Optional<BigDecimal> forModule = GradeMath.requiredExamForModule(
                GradeMath.VALIDATION_MARK,
                totalSubjectCoefficient,
                fixedContribution,
                config.getSubjectCoefficient(),
                grade.getCcGrade(),
                grade.getTpGrade(),
                config.getCcWeight(),
                config.getExamWeight(),
                config.getTpWeight()
        );

        BigDecimal subjectValue = forSubject.orElse(null);
        BigDecimal moduleValue = forModule.orElse(null);
        boolean impossibleSubject = subjectValue != null && subjectValue.compareTo(GradeMath.MAX_GRADE) > 0;
        boolean impossibleModule = moduleValue != null && moduleValue.compareTo(GradeMath.MAX_GRADE) > 0;
        String message;
        if (impossibleModule || impossibleSubject) {
            message = "Plus que 20 est requis dans au moins un scenario: validation impossible sans compensation supplementaire.";
        } else {
            message = "requiredForSubject valide la matiere seule; requiredForModule tient compte de la compensation dans l'UE.";
        }

        return RequiredExamGrade.builder()
                .subjectId(config.getSubject().getId())
                .subjectName(config.getSubject().getName())
                .requiredForSubject(subjectValue)
                .requiredForModule(moduleValue)
                .impossibleForSubject(impossibleSubject)
                .impossibleForModule(impossibleModule)
                .status("OK")
                .message(message)
                .build();
    }

    private BigDecimal calculateFixedContributionWithoutSubject(List<GradeConfig> configs, Map<Long, StudentGrade> gradeBySubject, Long excludedSubjectId) {
        BigDecimal sum = BigDecimal.ZERO;
        for (GradeConfig config : configs) {
            if (config.getSubject().getId().equals(excludedSubjectId)) {
                continue;
            }
            StudentGrade grade = gradeBySubject.get(config.getSubject().getId());
            BigDecimal average = grade == null ? BigDecimal.ZERO : GradeMath.nullToZero(grade.getSubjectAverage());
            sum = sum.add(average.multiply(config.getSubjectCoefficient(), MC), MC);
        }
        return sum;
    }

    private void computeAndAttachSubjectAverage(StudentGrade grade, GradeConfig config) {
        if (!isSubjectComplete(grade, config)) {
            grade.setSubjectAverage(null);
            grade.setValidated(false);
            return;
        }
        BigDecimal average = GradeMath.weightedAverage(
                grade.getCcGrade(),
                grade.getExamGrade(),
                grade.getTpGrade(),
                config.getCcWeight(),
                config.getExamWeight(),
                config.getTpWeight()
        );
        grade.setSubjectAverage(average);
        grade.setValidated(average.compareTo(GradeMath.VALIDATION_MARK) >= 0);
    }

    private boolean isSubjectComplete(StudentGrade grade, GradeConfig config) {
        if (grade == null) {
            return false;
        }
        return (!GradeMath.positive(config.getCcWeight()) || grade.getCcGrade() != null)
                && (!GradeMath.positive(config.getExamWeight()) || grade.getExamGrade() != null)
                && (!GradeMath.positive(config.getTpWeight()) || grade.getTpGrade() != null);
    }

    private int resolveModuleCredits(List<GradeConfig> moduleConfigs) {
        AcademicModule module = moduleConfigs.get(0).getModule();
        if (module.getCredits() != null && module.getCredits() > 0) {
            return module.getCredits();
        }
        return moduleConfigs.stream().map(GradeConfig::getCredits).filter(Objects::nonNull).findFirst().orElse(0);
    }

    private List<GradeConfig> loadConfigs(String department, Integer year, Semester semester) {
        List<GradeConfig> configs = gradeConfigRepository
                .findByDepartmentAndYearAndSemesterAndActiveTrueOrderByModuleNameAscSubjectNameAsc(department, year, semester);
        if (configs.isEmpty()) {
            throw new ResourceNotFoundException("No active grade configuration for " + department + " year " + year + " " + semester);
        }
        return configs;
    }

    private List<GradeConfig> loadConfigsForUser(String department, Integer year, Semester semester, String username) {
        List<GradeConfig> configs = loadConfigs(department, year, semester);
        if (username == null || !teacherManagementService.isTeacherOnly(username)) {
            return configs;
        }
        List<Long> allowedCourseIds = teacherManagementService.assignedCourseIdsForUsername(username);
        List<GradeConfig> filtered = configs.stream()
                .filter(config -> allowedCourseIds.contains(config.getSubject().getId()))
                .toList();
        if (filtered.isEmpty()) {
            throw new ResourceNotFoundException("Aucune matiere affectee a cet enseignant pour " + semester);
        }
        return filtered;
    }

    private void validateGradeValue(BigDecimal value, String label) {
        if (value != null && !GradeMath.isValidGrade(value)) {
            throw new BusinessRuleException(label + " grade must be between 0 and 20");
        }
    }

    private StudentGrade copyGrade(StudentGrade grade) {
        return StudentGrade.builder()
                .studentId(grade.getStudentId())
                .department(grade.getDepartment())
                .year(grade.getYear())
                .semester(grade.getSemester())
                .subject(grade.getSubject())
                .ccGrade(grade.getCcGrade())
                .examGrade(grade.getExamGrade())
                .tpGrade(grade.getTpGrade())
                .subjectAverage(grade.getSubjectAverage())
                .validated(grade.isValidated())
                .build();
    }

    @SafeVarargs
    private final <T> T firstNonNull(T... values) {
        for (T value : values) {
            if (value != null) {
                return value;
            }
        }
        return null;
    }

    private record ModuleCalc(ModuleResult result, boolean complete, Integer moduleCredits, BigDecimal moduleCoefficient) {
    }

    private record SemesterCalc(SemesterResult result, boolean complete) {
    }

    private class CalculationSnapshot {
        private final List<StudentGradeResponse> grades;
        private final List<ModuleCalc> modules;
        private final SemesterCalc semester;

        private CalculationSnapshot(List<StudentGradeResponse> grades, List<ModuleCalc> modules, SemesterCalc semester) {
            this.grades = grades;
            this.modules = modules;
            this.semester = semester;
        }

        private StudentResultsResponse toResponse() {
            List<ModuleResultResponse> moduleResponses = modules.stream()
                    .map(calc -> mapper.toModuleResultResponse(calc.result(), calc.complete(), calc.moduleCredits()))
                    .toList();
            SemesterResultResponse semesterResponse = mapper.toSemesterResultResponse(semester.result(), semester.complete());
            return new StudentResultsResponse(grades, moduleResponses, semesterResponse);
        }
    }
}
