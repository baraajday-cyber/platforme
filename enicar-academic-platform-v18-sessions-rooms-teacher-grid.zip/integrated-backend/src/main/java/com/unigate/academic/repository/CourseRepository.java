package com.unigate.academic.repository;

import com.unigate.academic.domain.entity.Course;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface CourseRepository extends JpaRepository<Course, Long> {
    List<Course> findByDepartmentOrderByName(String department);
    Optional<Course> findByNameAndDepartment(String name, String department);
}
