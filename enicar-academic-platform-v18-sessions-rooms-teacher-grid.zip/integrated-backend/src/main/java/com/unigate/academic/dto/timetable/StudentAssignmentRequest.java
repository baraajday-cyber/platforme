package com.unigate.academic.dto.timetable;

import com.unigate.academic.domain.enums.Semester;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public record StudentAssignmentRequest(
        @NotNull Long studentId,
        @NotNull Long classGroupId,
        @NotNull @Min(1) @Max(6) Integer year,
        @NotNull Semester semester
) {
}
