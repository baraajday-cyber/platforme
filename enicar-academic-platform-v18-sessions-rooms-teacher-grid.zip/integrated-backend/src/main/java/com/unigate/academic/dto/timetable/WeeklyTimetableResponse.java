package com.unigate.academic.dto.timetable;

import com.unigate.academic.domain.enums.Semester;

import java.time.DayOfWeek;
import java.util.List;
import java.util.Map;

public record WeeklyTimetableResponse(
        Long classGroupId,
        String classGroupName,
        String department,
        Integer year,
        Semester semester,
        Map<DayOfWeek, List<TimetableSlotResponse>> slotsByDay
) {
}
