package com.unigate.academic.controller;

import com.unigate.academic.domain.enums.Semester;
import com.unigate.academic.dto.timetable.TimetableSlotResponse;
import com.unigate.academic.service.TimetableService;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.List;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/teacher/academic/timetable")
@PreAuthorize("hasAnyRole('TEACHER','DEPARTMENT_ADMIN','SUPER_ADMIN')")
public class TeacherTimetableController {

    private final TimetableService timetableService;

    @GetMapping
    public List<TimetableSlotResponse> mySlots(
            @RequestParam @NotNull Integer year,
            @RequestParam @NotNull Semester semester,
            Authentication authentication
    ) {
        return timetableService.getTeacherSlots(authentication.getName(), year, semester);
    }

    @GetMapping("/rooms/available")
    public List<String> availableRooms(
            @RequestParam @NotNull DayOfWeek dayOfWeek,
            @RequestParam @NotNull LocalTime startTime,
            @RequestParam @NotNull LocalTime endTime,
            @RequestParam(required = false) Long excludedSlotId
    ) {
        return timetableService.listAvailableRooms(dayOfWeek, startTime, endTime, excludedSlotId);
    }

}
