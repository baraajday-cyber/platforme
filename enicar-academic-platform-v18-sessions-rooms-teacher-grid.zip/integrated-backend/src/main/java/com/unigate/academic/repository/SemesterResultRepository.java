package com.unigate.academic.repository;

import com.unigate.academic.domain.entity.SemesterResult;
import com.unigate.academic.domain.enums.Semester;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface SemesterResultRepository extends JpaRepository<SemesterResult, Long> {
    Optional<SemesterResult> findByStudentIdAndDepartmentAndYearAndSemester(Long studentId, String department, Integer year, Semester semester);
}
