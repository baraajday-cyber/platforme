package com.unigate.academic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;

@SpringBootApplication(scanBasePackages = "com.unigate")
@EnableJpaRepositories(basePackages = "com.unigate")
@EntityScan(basePackages = "com.unigate")
@EnableCaching
@EnableAsync
@EnableMethodSecurity
public class AcademicModuleApplication {

    public static void main(String[] args) {
        SpringApplication.run(AcademicModuleApplication.class, args);
    }
}
