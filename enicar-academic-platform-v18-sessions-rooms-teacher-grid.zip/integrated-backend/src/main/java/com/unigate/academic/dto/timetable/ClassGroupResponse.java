package com.unigate.academic.dto.timetable;

import com.unigate.academic.domain.enums.Semester;

public record ClassGroupResponse(
        Long id,
        String name,
        String department,
        Integer year,
        Semester semester,
        String description
) {
}
