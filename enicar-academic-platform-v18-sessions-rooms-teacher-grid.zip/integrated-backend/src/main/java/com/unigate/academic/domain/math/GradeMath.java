package com.unigate.academic.domain.math;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.Optional;

public final class GradeMath {

    public static final BigDecimal VALIDATION_MARK = bd("10");
    public static final BigDecimal MAX_GRADE = bd("20");
    public static final BigDecimal MIN_GRADE = BigDecimal.ZERO;
    public static final MathContext MC = MathContext.DECIMAL64;

    private GradeMath() {
    }

    public static BigDecimal bd(String value) {
        return new BigDecimal(value);
    }

    public static BigDecimal round(BigDecimal value) {
        if (value == null) {
            return null;
        }
        return value.setScale(2, RoundingMode.HALF_UP);
    }

    public static boolean isValidGrade(BigDecimal grade) {
        return grade != null && grade.compareTo(MIN_GRADE) >= 0 && grade.compareTo(MAX_GRADE) <= 0;
    }

    public static BigDecimal weightedAverage(
            BigDecimal cc,
            BigDecimal exam,
            BigDecimal tp,
            BigDecimal ccWeight,
            BigDecimal examWeight,
            BigDecimal tpWeight
    ) {
        BigDecimal total = BigDecimal.ZERO;
        if (positive(ccWeight)) {
            total = total.add(cc.multiply(ccWeight, MC), MC);
        }
        if (positive(examWeight)) {
            total = total.add(exam.multiply(examWeight, MC), MC);
        }
        if (positive(tpWeight)) {
            total = total.add(tp.multiply(tpWeight, MC), MC);
        }
        return round(total);
    }

    public static Optional<BigDecimal> requiredExamForSubject(
            BigDecimal targetAverage,
            BigDecimal cc,
            BigDecimal tp,
            BigDecimal ccWeight,
            BigDecimal examWeight,
            BigDecimal tpWeight
    ) {
        if (!positive(examWeight) || cc == null || (positive(tpWeight) && tp == null)) {
            return Optional.empty();
        }
        BigDecimal known = cc.multiply(nullToZero(ccWeight), MC)
                .add(nullToZero(tp).multiply(nullToZero(tpWeight), MC), MC);
        BigDecimal required = targetAverage.subtract(known, MC).divide(examWeight, 6, RoundingMode.HALF_UP);
        return Optional.of(round(required.max(BigDecimal.ZERO)));
    }

    public static Optional<BigDecimal> requiredExamForModule(
            BigDecimal targetModuleAverage,
            BigDecimal totalSubjectCoefficient,
            BigDecimal fixedContributionWithoutSubject,
            BigDecimal subjectCoefficient,
            BigDecimal cc,
            BigDecimal tp,
            BigDecimal ccWeight,
            BigDecimal examWeight,
            BigDecimal tpWeight
    ) {
        if (!positive(examWeight) || !positive(subjectCoefficient) || !positive(totalSubjectCoefficient)
                || cc == null || (positive(tpWeight) && tp == null)) {
            return Optional.empty();
        }
        BigDecimal targetWeightedSum = targetModuleAverage.multiply(totalSubjectCoefficient, MC);
        BigDecimal requiredSubjectAverage = targetWeightedSum
                .subtract(nullToZero(fixedContributionWithoutSubject), MC)
                .divide(subjectCoefficient, 6, RoundingMode.HALF_UP);
        return requiredExamForSubject(requiredSubjectAverage, cc, tp, ccWeight, examWeight, tpWeight);
    }

    public static boolean positive(BigDecimal value) {
        return value != null && value.compareTo(BigDecimal.ZERO) > 0;
    }

    public static BigDecimal nullToZero(BigDecimal value) {
        return value == null ? BigDecimal.ZERO : value;
    }
}
