package com.unigate.academic.repository;

import com.unigate.academic.domain.entity.TimetableChangeRequest;
import com.unigate.academic.domain.enums.TimetableChangeRequestStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface TimetableChangeRequestRepository extends JpaRepository<TimetableChangeRequest, Long> {

    @Query("""
            select r
            from TimetableChangeRequest r
              join fetch r.teacher
              join fetch r.slot s
              join fetch s.classGroup
              join fetch s.course
            where (:status is null or r.status = :status)
            order by r.createdAt desc
            """)
    List<TimetableChangeRequest> findAllWithDetails(@Param("status") TimetableChangeRequestStatus status);

    @Query("""
            select r
            from TimetableChangeRequest r
              join fetch r.teacher
              join fetch r.slot s
              join fetch s.classGroup
              join fetch s.course
            where r.teacher.id = :teacherId
            order by r.createdAt desc
            """)
    List<TimetableChangeRequest> findByTeacherWithDetails(@Param("teacherId") Long teacherId);
}
