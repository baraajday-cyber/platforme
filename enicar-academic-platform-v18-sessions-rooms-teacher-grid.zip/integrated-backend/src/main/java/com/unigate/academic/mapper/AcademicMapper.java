package com.unigate.academic.mapper;

import com.unigate.academic.domain.entity.AcademicModule;
import com.unigate.academic.domain.entity.ClassGroup;
import com.unigate.academic.domain.entity.Course;
import com.unigate.academic.domain.entity.GradeConfig;
import com.unigate.academic.domain.entity.ModuleResult;
import com.unigate.academic.domain.entity.SemesterResult;
import com.unigate.academic.domain.entity.StudentGrade;
import com.unigate.academic.domain.entity.TimetableSlot;
import com.unigate.academic.domain.vo.RequiredExamGrade;
import com.unigate.academic.dto.grade.GradeConfigResponse;
import com.unigate.academic.dto.grade.ModuleResultResponse;
import com.unigate.academic.dto.grade.RequiredExamGradeResponse;
import com.unigate.academic.dto.grade.SemesterResultResponse;
import com.unigate.academic.dto.grade.StudentGradeResponse;
import com.unigate.academic.dto.timetable.AcademicModuleResponse;
import com.unigate.academic.dto.timetable.ClassGroupResponse;
import com.unigate.academic.dto.timetable.CourseResponse;
import com.unigate.academic.dto.timetable.TimetableSlotResponse;
import org.springframework.stereotype.Component;

import java.util.Comparator;
import java.util.List;

@Component
public class AcademicMapper {

    public ClassGroupResponse toClassGroupResponse(ClassGroup group) {
        return new ClassGroupResponse(
                group.getId(),
                group.getName(),
                group.getDepartment(),
                group.getYear(),
                group.getSemester(),
                group.getDescription()
        );
    }

    public CourseResponse toCourseResponse(Course course) {
        return new CourseResponse(
                course.getId(),
                course.getName(),
                course.getDepartment(),
                course.getCode(),
                course.getDefaultCoefficient(),
                course.getDefaultCredits()
        );
    }

    public AcademicModuleResponse toAcademicModuleResponse(AcademicModule module) {
        return new AcademicModuleResponse(
                module.getId(),
                module.getName(),
                module.getDepartment(),
                module.getYear(),
                module.getSemester(),
                module.getModuleCoefficient(),
                module.getCredits()
        );
    }

    public TimetableSlotResponse toTimetableSlotResponse(TimetableSlot slot) {
        return new TimetableSlotResponse(
                slot.getId(),
                slot.getClassGroup().getId(),
                slot.getClassGroup().getName(),
                slot.getCourse().getId(),
                slot.getCourse().getName(),
                slot.getDayOfWeek(),
                slot.getStartTime(),
                slot.getEndTime(),
                slot.getRoom(),
                slot.getProfessorId(),
                slot.getProfessorName(),
                slot.getStatus(),
                slot.getChangeReason()
        );
    }

    public GradeConfigResponse toGradeConfigResponse(GradeConfig config) {
        return new GradeConfigResponse(
                config.getId(),
                config.getDepartment(),
                config.getYear(),
                config.getSemester(),
                config.getSubject().getId(),
                config.getSubject().getName(),
                config.getModule().getId(),
                config.getModule().getName(),
                config.getSubjectCoefficient(),
                config.getModuleCoefficient(),
                config.getCcWeight(),
                config.getExamWeight(),
                config.getTpWeight(),
                config.getCredits(),
                config.isActive()
        );
    }

    public StudentGradeResponse toStudentGradeResponse(StudentGrade grade, GradeConfig config, boolean complete) {
        return new StudentGradeResponse(
                grade.getId(),
                grade.getStudentId(),
                grade.getDepartment(),
                grade.getYear(),
                grade.getSemester(),
                grade.getSubject().getId(),
                grade.getSubject().getName(),
                config.getModule().getId(),
                config.getModule().getName(),
                grade.getCcGrade(),
                grade.getExamGrade(),
                grade.getTpGrade(),
                grade.getSubjectAverage(),
                complete,
                grade.isValidated()
        );
    }

    public StudentGradeResponse toMissingStudentGradeResponse(Long studentId, GradeConfig config) {
        return new StudentGradeResponse(
                null,
                studentId,
                config.getDepartment(),
                config.getYear(),
                config.getSemester(),
                config.getSubject().getId(),
                config.getSubject().getName(),
                config.getModule().getId(),
                config.getModule().getName(),
                null,
                null,
                null,
                null,
                false,
                false
        );
    }

    public ModuleResultResponse toModuleResultResponse(ModuleResult result, boolean complete, Integer moduleCredits) {
        List<RequiredExamGradeResponse> required = result.getRequiredExamGrades().values().stream()
                .sorted(Comparator.comparing(RequiredExamGrade::getSubjectName, Comparator.nullsLast(String::compareToIgnoreCase)))
                .map(this::toRequiredExamGradeResponse)
                .toList();
        return new ModuleResultResponse(
                result.getId(),
                result.getModule().getId(),
                result.getModule().getName(),
                result.getDepartment(),
                result.getYear(),
                result.getSemester(),
                result.getModuleAverage(),
                result.getCreditsEarned(),
                moduleCredits,
                complete,
                result.isValidated(),
                required
        );
    }

    public SemesterResultResponse toSemesterResultResponse(SemesterResult result, boolean complete) {
        return new SemesterResultResponse(
                result.getId(),
                result.getStudentId(),
                result.getDepartment(),
                result.getYear(),
                result.getSemester(),
                result.getSemesterAverage(),
                result.getTotalCredits(),
                complete,
                result.isValidated()
        );
    }

    public RequiredExamGradeResponse toRequiredExamGradeResponse(RequiredExamGrade grade) {
        return new RequiredExamGradeResponse(
                grade.getSubjectId(),
                grade.getSubjectName(),
                grade.getRequiredForSubject(),
                grade.getRequiredForModule(),
                grade.isImpossibleForSubject(),
                grade.isImpossibleForModule(),
                grade.getStatus(),
                grade.getMessage()
        );
    }
}
