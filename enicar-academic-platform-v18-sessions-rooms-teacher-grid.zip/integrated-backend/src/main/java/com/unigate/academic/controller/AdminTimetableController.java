package com.unigate.academic.controller;

import com.unigate.academic.dto.timetable.CancelSlotRequest;
import com.unigate.academic.dto.timetable.DuplicateTimetableRequest;
import com.unigate.academic.dto.timetable.TimetableSlotMoveRequest;
import com.unigate.academic.dto.timetable.TimetableSlotRequest;
import com.unigate.academic.dto.timetable.TimetableSlotResponse;
import com.unigate.academic.dto.timetable.TimetableSlotUpdateRequest;
import com.unigate.academic.dto.timetable.RoomAvailabilityResponse;
import com.unigate.academic.dto.timetable.WeeklyTimetableResponse;
import com.unigate.academic.service.TimetablePdfExportService;
import com.unigate.academic.service.TimetableService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/admin/academic/timetable")
@PreAuthorize("hasAnyRole('DEPARTMENT_ADMIN','SUPER_ADMIN')")
public class AdminTimetableController {

    private final TimetableService timetableService;
    private final TimetablePdfExportService pdfExportService;

    @PostMapping("/slots")
    @ResponseStatus(HttpStatus.CREATED)
    public TimetableSlotResponse createSlot(@Valid @RequestBody TimetableSlotRequest request) {
        return timetableService.createSlot(request);
    }

    @PutMapping("/slots/{id}")
    public TimetableSlotResponse updateSlot(@PathVariable Long id, @Valid @RequestBody TimetableSlotUpdateRequest request) {
        return timetableService.updateSlot(id, request);
    }

    @PatchMapping("/slots/{id}/move")
    public TimetableSlotResponse moveSlot(@PathVariable Long id, @Valid @RequestBody TimetableSlotMoveRequest request) {
        return timetableService.moveSlot(id, request);
    }

    @GetMapping("/rooms")
    public List<String> listRooms() {
        return timetableService.listRooms();
    }

    @GetMapping("/rooms/available")
    public List<String> listAvailableRooms(
            @RequestParam DayOfWeek dayOfWeek,
            @RequestParam LocalTime startTime,
            @RequestParam LocalTime endTime,
            @RequestParam(required = false) Long excludedSlotId
    ) {
        return timetableService.listAvailableRooms(dayOfWeek, startTime, endTime, excludedSlotId);
    }

    @GetMapping("/rooms/availability")
    public RoomAvailabilityResponse checkRoomAvailability(
            @RequestParam String room,
            @RequestParam DayOfWeek dayOfWeek,
            @RequestParam LocalTime startTime,
            @RequestParam LocalTime endTime,
            @RequestParam(required = false) Long excludedSlotId
    ) {
        return timetableService.checkRoomAvailability(room, dayOfWeek, startTime, endTime, excludedSlotId);
    }

    @PostMapping("/slots/{id}/cancel")
    public TimetableSlotResponse cancelSlot(@PathVariable Long id, @Valid @RequestBody CancelSlotRequest request) {
        return timetableService.cancelSlot(id, request.reason());
    }

    @DeleteMapping("/slots/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteSlot(@PathVariable Long id) {
        timetableService.deleteSlot(id);
    }

    @PostMapping("/duplicate")
    @ResponseStatus(HttpStatus.CREATED)
    public List<TimetableSlotResponse> duplicate(@Valid @RequestBody DuplicateTimetableRequest request) {
        return timetableService.duplicateTimetable(request);
    }

    @GetMapping("/class-groups/{classGroupId}")
    public WeeklyTimetableResponse getClassGroupTimetable(@PathVariable Long classGroupId) {
        return timetableService.getWeeklyByClassGroup(classGroupId);
    }

    @GetMapping(value = "/class-groups/{classGroupId}/export.pdf", produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<byte[]> exportClassGroupPdf(@PathVariable Long classGroupId) {
        byte[] pdf = pdfExportService.exportClassGroupTimetable(classGroupId);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=emploi-du-temps-classe-" + classGroupId + ".pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .body(pdf);
    }
}
