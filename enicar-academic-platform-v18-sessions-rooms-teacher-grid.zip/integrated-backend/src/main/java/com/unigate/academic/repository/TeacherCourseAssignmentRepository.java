package com.unigate.academic.repository;

import com.unigate.academic.domain.entity.TeacherCourseAssignment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface TeacherCourseAssignmentRepository extends JpaRepository<TeacherCourseAssignment, Long> {
    @Query("""
            select a
            from TeacherCourseAssignment a
            join fetch a.course c
            where a.teacher.id = :teacherId and a.active = true
            order by c.name asc
            """)
    List<TeacherCourseAssignment> findActiveByTeacherIdOrderByCourseName(@Param("teacherId") Long teacherId);

    Optional<TeacherCourseAssignment> findByTeacherIdAndCourseId(Long teacherId, Long courseId);

    @Query("""
            select a.course.id
            from TeacherCourseAssignment a
            where a.teacher.id = :teacherId and a.active = true
            """)
    List<Long> findActiveCourseIdsByTeacherId(@Param("teacherId") Long teacherId);

    void deleteByTeacherId(Long teacherId);
}
