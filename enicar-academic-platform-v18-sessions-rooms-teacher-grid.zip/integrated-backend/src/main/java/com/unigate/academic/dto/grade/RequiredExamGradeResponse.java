package com.unigate.academic.dto.grade;

import java.math.BigDecimal;

public record RequiredExamGradeResponse(
        Long subjectId,
        String subjectName,
        BigDecimal requiredForSubject,
        BigDecimal requiredForModule,
        boolean impossibleForSubject,
        boolean impossibleForModule,
        String status,
        String message
) {
}
