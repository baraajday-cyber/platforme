package com.unigate.academic.dto.timetable;

public record TimetableChangeDecisionRequest(String message) {
}
