package com.unigate.academic.controller;

import com.unigate.academic.dto.teacher.TeacherCreateRequest;
import com.unigate.academic.dto.teacher.TeacherUpdateRequest;
import com.unigate.academic.dto.teacher.TeacherUserResponse;
import com.unigate.academic.service.TeacherManagementService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/admin/academic/teachers")
@PreAuthorize("hasAnyRole('DEPARTMENT_ADMIN','SUPER_ADMIN')")
public class AdminTeacherController {

    private final TeacherManagementService teacherManagementService;

    @GetMapping
    public List<TeacherUserResponse> listTeachers() {
        return teacherManagementService.listTeachers();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public TeacherUserResponse createTeacher(@Valid @RequestBody TeacherCreateRequest request) {
        return teacherManagementService.createTeacher(request);
    }

    @PutMapping("/{teacherUserId}")
    public TeacherUserResponse updateTeacher(@PathVariable Long teacherUserId, @Valid @RequestBody TeacherUpdateRequest request) {
        return teacherManagementService.updateTeacher(teacherUserId, request);
    }
}
