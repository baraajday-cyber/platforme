package com.unigate.communication.controller;

import com.unigate.academic.security.CurrentUserService;
import com.unigate.communication.dto.skill.SkillSwapCreateRequest;
import com.unigate.communication.dto.skill.SkillSwapDecisionRequest;
import com.unigate.communication.dto.skill.SkillSwapResponse;
import com.unigate.communication.dto.skill.SkillSwapScheduleRequest;
import com.unigate.communication.dto.skill.SwapRatingRequest;
import com.unigate.communication.dto.skill.SwapRatingResponse;
import com.unigate.communication.service.SkillSwapService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/student/skill-swap/swaps")
@PreAuthorize("hasRole('STUDENT')")
@Tag(name = "Skill Swap lifecycle", description = "Request, accept, schedule, complete and rate swaps")
public class SkillSwapController {

    private final SkillSwapService swapService;
    private final CurrentUserService currentUserService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public SkillSwapResponse create(@RequestParam(required = false) Long studentId, @Valid @RequestBody SkillSwapCreateRequest request) {
        return swapService.createRequest(currentUserService.resolveStudentId(studentId), request);
    }

    @GetMapping
    public List<SkillSwapResponse> mySwaps(@RequestParam(required = false) Long studentId) {
        return swapService.mySwaps(currentUserService.resolveStudentId(studentId));
    }

    @PostMapping("/{swapId}/accept")
    public SkillSwapResponse accept(
            @RequestParam(required = false) Long studentId,
            @PathVariable Long swapId,
            @RequestBody(required = false) SkillSwapDecisionRequest request
    ) {
        return swapService.accept(currentUserService.resolveStudentId(studentId), swapId, request == null ? new SkillSwapDecisionRequest(null) : request);
    }

    @PostMapping("/{swapId}/reject")
    public SkillSwapResponse reject(
            @RequestParam(required = false) Long studentId,
            @PathVariable Long swapId,
            @RequestBody(required = false) SkillSwapDecisionRequest request
    ) {
        return swapService.reject(currentUserService.resolveStudentId(studentId), swapId, request == null ? new SkillSwapDecisionRequest(null) : request);
    }

    @PostMapping("/{swapId}/schedule")
    public SkillSwapResponse schedule(
            @RequestParam(required = false) Long studentId,
            @PathVariable Long swapId,
            @Valid @RequestBody SkillSwapScheduleRequest request
    ) {
        return swapService.schedule(currentUserService.resolveStudentId(studentId), swapId, request);
    }

    @PostMapping("/{swapId}/complete")
    public SkillSwapResponse complete(@RequestParam(required = false) Long studentId, @PathVariable Long swapId) {
        return swapService.complete(currentUserService.resolveStudentId(studentId), swapId);
    }

    @PostMapping("/{swapId}/rating")
    @ResponseStatus(HttpStatus.CREATED)
    public SwapRatingResponse rate(
            @RequestParam(required = false) Long studentId,
            @PathVariable Long swapId,
            @Valid @RequestBody SwapRatingRequest request
    ) {
        return swapService.rate(currentUserService.resolveStudentId(studentId), swapId, request);
    }
}
