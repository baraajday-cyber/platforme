package com.unigate.communication.controller;

import com.unigate.academic.security.CurrentUserService;
import com.unigate.communication.dto.common.PageResponse;
import com.unigate.communication.dto.notification.NotificationPreferenceRequest;
import com.unigate.communication.dto.notification.NotificationPreferenceResponse;
import com.unigate.communication.dto.notification.NotificationResponse;
import com.unigate.communication.dto.notification.UnreadCountResponse;
import com.unigate.communication.service.NotificationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/student/communication/notifications")
@PreAuthorize("hasRole('STUDENT')")
@Tag(name = "Student notifications", description = "Feed temps reel et preferences de notification")
public class NotificationController {

    private final NotificationService notificationService;
    private final CurrentUserService currentUserService;

    @GetMapping
    @Operation(summary = "Lister les notifications de l'etudiant authentifie")
    public PageResponse<NotificationResponse> list(
            @RequestParam(required = false) Long studentId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size
    ) {
        Long resolvedStudentId = currentUserService.resolveStudentId(studentId);
        return notificationService.list(resolvedStudentId, page, size);
    }

    @GetMapping("/unread-count")
    public UnreadCountResponse unreadCount(@RequestParam(required = false) Long studentId) {
        Long resolvedStudentId = currentUserService.resolveStudentId(studentId);
        return new UnreadCountResponse(notificationService.unreadCount(resolvedStudentId));
    }

    @PatchMapping("/{notificationId}/read")
    public NotificationResponse markRead(@RequestParam(required = false) Long studentId, @PathVariable Long notificationId) {
        Long resolvedStudentId = currentUserService.resolveStudentId(studentId);
        return notificationService.markRead(resolvedStudentId, notificationId);
    }

    @PatchMapping("/mark-all-read")
    public int markAllRead(@RequestParam(required = false) Long studentId) {
        Long resolvedStudentId = currentUserService.resolveStudentId(studentId);
        return notificationService.markAllRead(resolvedStudentId);
    }

    @GetMapping("/preferences")
    public NotificationPreferenceResponse preferences(@RequestParam(required = false) Long studentId) {
        Long resolvedStudentId = currentUserService.resolveStudentId(studentId);
        return notificationService.getPreferences(resolvedStudentId);
    }

    @PutMapping("/preferences")
    public NotificationPreferenceResponse updatePreferences(
            @RequestParam(required = false) Long studentId,
            @Valid @RequestBody NotificationPreferenceRequest request
    ) {
        Long resolvedStudentId = currentUserService.resolveStudentId(studentId);
        return notificationService.updatePreferences(resolvedStudentId, request);
    }
}
