package com.unigate.communication.dto.common;

public record IdResponse(Long id) {
}
