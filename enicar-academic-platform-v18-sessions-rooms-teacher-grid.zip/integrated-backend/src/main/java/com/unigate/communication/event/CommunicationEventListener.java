package com.unigate.communication.event;

import com.unigate.communication.domain.enums.NotificationPriority;
import com.unigate.communication.domain.enums.NotificationType;
import com.unigate.communication.service.NotificationCommand;
import com.unigate.communication.service.NotificationService;
import com.unigate.communication.websocket.WebSocketPublisher;
import lombok.RequiredArgsConstructor;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;

@Component
@RequiredArgsConstructor
public class CommunicationEventListener {

    private final NotificationService notificationService;
    private final WebSocketPublisher webSocketPublisher;

    @EventListener
    public void onRegistrationStatusChanged(RegistrationStatusChangedEvent event) {
        notificationService.notifyStudent(NotificationCommand.builder()
                .recipientId(event.studentId())
                .type(NotificationType.REGISTRATION_STATUS)
                .priority(NotificationPriority.HIGH)
                .title("Statut d'inscription mis a jour")
                .message(event.message() == null ? "Votre inscription est maintenant: " + event.newStatus() : event.message())
                .payload(registrationPayload(event))
                .linkUrl("/student/registration")
                .build());
    }

    @EventListener
    public void onDocumentReview(DocumentReviewEvent event) {
        notificationService.notifyStudent(NotificationCommand.builder()
                .recipientId(event.studentId())
                .type(NotificationType.DOCUMENT_REVIEW)
                .priority(NotificationPriority.HIGH)
                .title("Document verifie: " + event.documentType())
                .message(event.reviewerComment() == null ? "Statut du document: " + event.status() : event.reviewerComment())
                .payload(documentPayload(event))
                .linkUrl("/student/documents")
                .build());
    }

    @EventListener
    public void onGradeEntered(GradeEnteredEvent event) {
        notificationService.notifyStudent(NotificationCommand.builder()
                .recipientId(event.studentId())
                .type(NotificationType.GRADE_UPDATED)
                .priority(NotificationPriority.NORMAL)
                .title("Notes recalculees")
                .message("Une note a ete saisie. Vos moyennes peuvent etre consultees en temps reel.")
                .payload(gradePayload(event))
                .linkUrl("/academic/grades")
                .build());
    }

    @EventListener
    public void onSkillSwapStatusChanged(SkillSwapStatusChangedEvent event) {
        webSocketPublisher.sendToStudent(event.requesterId(), "/queue/skill-swaps", event);
        webSocketPublisher.sendToStudent(event.receiverId(), "/queue/skill-swaps", event);
    }
    private Map<String, Object> registrationPayload(RegistrationStatusChangedEvent event) {
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("previousStatus", event.previousStatus());
        payload.put("newStatus", event.newStatus());
        payload.put("occurredAt", event.occurredAt() == null ? null : event.occurredAt().toString());
        return payload;
    }

    private Map<String, Object> documentPayload(DocumentReviewEvent event) {
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("documentId", event.documentId());
        payload.put("documentType", event.documentType());
        payload.put("status", event.status());
        payload.put("reviewerComment", event.reviewerComment());
        return payload;
    }

    private Map<String, Object> gradePayload(GradeEnteredEvent event) {
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("department", event.department());
        payload.put("year", event.year());
        payload.put("semester", event.semester() == null ? null : event.semester().name());
        payload.put("subjectId", event.subjectId());
        return payload;
    }

}
