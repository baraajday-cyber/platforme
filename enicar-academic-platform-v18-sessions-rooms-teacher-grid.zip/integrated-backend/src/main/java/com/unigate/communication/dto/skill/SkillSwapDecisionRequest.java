package com.unigate.communication.dto.skill;

import jakarta.validation.constraints.Size;

public record SkillSwapDecisionRequest(@Size(max = 500) String reason) {
}
