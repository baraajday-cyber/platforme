package com.unigate.communication.dto.notification;

public record NotificationPreferenceResponse(
        Long studentId,
        boolean websocketEnabled,
        boolean emailEnabled,
        boolean timetableUpdates,
        boolean gradeUpdates,
        boolean swapUpdates,
        boolean registrationUpdates,
        boolean weeklyDigest
) {
}
