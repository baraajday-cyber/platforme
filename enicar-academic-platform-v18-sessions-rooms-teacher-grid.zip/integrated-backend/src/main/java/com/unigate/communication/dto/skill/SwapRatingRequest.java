package com.unigate.communication.dto.skill;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;

public record SwapRatingRequest(
        @Min(1) @Max(5) int score,
        @Size(max = 1000) String comment
) {
}
