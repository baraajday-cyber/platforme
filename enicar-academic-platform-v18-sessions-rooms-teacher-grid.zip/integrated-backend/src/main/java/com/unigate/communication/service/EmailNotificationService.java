package com.unigate.communication.service;

import com.unigate.communication.domain.entity.Notification;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class EmailNotificationService {

    private final ObjectProvider<JavaMailSender> mailSenderProvider;
    private final TemplateEngine templateEngine;

    @Value("${unigate.communication.frontend-base-url:http://localhost:4200}")
    private String frontendBaseUrl;

    @Async
    public void sendNotificationEmail(Notification notification, Optional<String> recipientEmail) {
        if (recipientEmail.isEmpty()) {
            log.debug("No email address available for student {}. Email skipped.", notification.getRecipientId());
            return;
        }
        JavaMailSender mailSender = mailSenderProvider.getIfAvailable();
        if (mailSender == null) {
            log.debug("JavaMailSender not configured. Email skipped for notification {}.", notification.getId());
            return;
        }
        try {
            Context context = new Context(Locale.FRENCH);
            context.setVariable("title", notification.getTitle());
            context.setVariable("message", notification.getMessage());
            context.setVariable("linkUrl", notification.getLinkUrl() == null ? frontendBaseUrl : frontendBaseUrl + notification.getLinkUrl());
            context.setVariable("type", notification.getType().name());
            String html = templateEngine.process("mail/notification", context);

            var mimeMessage = mailSender.createMimeMessage();
            var helper = new MimeMessageHelper(mimeMessage, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED, StandardCharsets.UTF_8.name());
            helper.setTo(recipientEmail.get());
            helper.setSubject("UniGate - " + notification.getTitle());
            helper.setText(html, true);
            mailSender.send(mimeMessage);
        } catch (Exception ex) {
            log.warn("Unable to send notification email {} to student {}: {}", notification.getId(), notification.getRecipientId(), ex.getMessage());
        }
    }
}
