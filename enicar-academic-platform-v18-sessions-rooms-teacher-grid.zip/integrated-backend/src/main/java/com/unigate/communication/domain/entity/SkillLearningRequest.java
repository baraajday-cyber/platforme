package com.unigate.communication.domain.entity;

import com.unigate.communication.domain.enums.SkillLevel;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(
        name = "skill_requests",
        uniqueConstraints = @UniqueConstraint(name = "uk_skill_request_student_skill", columnNames = {"student_id", "skill_id"}),
        indexes = {
                @Index(name = "idx_skill_request_skill_active", columnList = "skill_id, active"),
                @Index(name = "idx_skill_request_student", columnList = "student_id")
        }
)
public class SkillLearningRequest extends BaseCommunicationEntity {

    @Column(name = "student_id", nullable = false)
    private Long studentId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "skill_id", nullable = false)
    private Skill skill;

    @Enumerated(EnumType.STRING)
    @Column(name = "target_level", nullable = false, length = 30)
    private SkillLevel targetLevel;

    @Column(length = 700)
    private String objective;

    @Column(nullable = false)
    @Builder.Default
    private boolean active = true;
}
