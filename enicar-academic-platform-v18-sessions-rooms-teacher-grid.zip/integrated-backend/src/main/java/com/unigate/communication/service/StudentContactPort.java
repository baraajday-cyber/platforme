package com.unigate.communication.service;

import java.util.Optional;

public interface StudentContactPort {
    Optional<String> emailForStudent(Long studentId);
    Optional<String> displayNameForStudent(Long studentId);
}
