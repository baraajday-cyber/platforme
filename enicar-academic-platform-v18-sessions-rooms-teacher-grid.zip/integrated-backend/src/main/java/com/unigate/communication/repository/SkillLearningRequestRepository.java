package com.unigate.communication.repository;

import com.unigate.communication.domain.entity.SkillLearningRequest;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface SkillLearningRequestRepository extends JpaRepository<SkillLearningRequest, Long> {
    List<SkillLearningRequest> findByStudentIdAndActiveTrue(Long studentId);
    List<SkillLearningRequest> findBySkillIdAndActiveTrue(Long skillId);
    Optional<SkillLearningRequest> findByStudentIdAndSkillId(Long studentId, Long skillId);
    boolean existsByStudentIdAndSkillIdAndActiveTrue(Long studentId, Long skillId);
}
