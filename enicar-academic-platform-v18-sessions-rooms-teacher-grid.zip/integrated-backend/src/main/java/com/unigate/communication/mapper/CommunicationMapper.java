package com.unigate.communication.mapper;

import com.unigate.communication.domain.entity.Notification;
import com.unigate.communication.domain.entity.NotificationPreference;
import com.unigate.communication.domain.entity.Skill;
import com.unigate.communication.domain.entity.SkillLearningRequest;
import com.unigate.communication.domain.entity.SkillOffer;
import com.unigate.communication.domain.entity.SkillSwap;
import com.unigate.communication.domain.entity.SwapRating;
import com.unigate.communication.dto.notification.NotificationPreferenceResponse;
import com.unigate.communication.dto.notification.NotificationResponse;
import com.unigate.communication.dto.skill.SkillNeedResponse;
import com.unigate.communication.dto.skill.SkillOfferResponse;
import com.unigate.communication.dto.skill.SkillResponse;
import com.unigate.communication.dto.skill.SkillSwapResponse;
import com.unigate.communication.dto.skill.SwapRatingResponse;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class CommunicationMapper {

    public NotificationResponse toResponse(Notification notification) {
        return new NotificationResponse(
                notification.getId(),
                notification.getRecipientId(),
                notification.getSenderId(),
                notification.getType(),
                notification.getPriority(),
                notification.getTitle(),
                notification.getMessage(),
                notification.getPayloadJson(),
                notification.getLinkUrl(),
                notification.isRead(),
                notification.getDeliveredAt(),
                notification.getEmailSentAt(),
                notification.getReadAt(),
                notification.getCreatedAt()
        );
    }

    public NotificationPreferenceResponse toResponse(NotificationPreference preference) {
        return new NotificationPreferenceResponse(
                preference.getStudentId(),
                preference.isWebsocketEnabled(),
                preference.isEmailEnabled(),
                preference.isTimetableUpdates(),
                preference.isGradeUpdates(),
                preference.isSwapUpdates(),
                preference.isRegistrationUpdates(),
                preference.isWeeklyDigest()
        );
    }

    public SkillResponse toResponse(Skill skill) {
        if (skill == null) {
            return null;
        }
        return new SkillResponse(
                skill.getId(),
                skill.getName(),
                skill.getNormalizedName(),
                skill.getCategory(),
                skill.getDescription(),
                skill.getAcademicCourseId(),
                skill.getDepartment(),
                skill.isActive()
        );
    }

    public SkillOfferResponse toResponse(SkillOffer offer) {
        return new SkillOfferResponse(
                offer.getId(),
                offer.getStudentId(),
                toResponse(offer.getSkill()),
                offer.getLevel(),
                offer.getDescription(),
                offer.isActive()
        );
    }

    public SkillNeedResponse toResponse(SkillLearningRequest request) {
        return new SkillNeedResponse(
                request.getId(),
                request.getStudentId(),
                toResponse(request.getSkill()),
                request.getTargetLevel(),
                request.getObjective(),
                request.isActive()
        );
    }

    public SwapRatingResponse toResponse(SwapRating rating) {
        return new SwapRatingResponse(
                rating.getId(),
                rating.getSwap().getId(),
                rating.getRaterId(),
                rating.getRatedId(),
                rating.getScore(),
                rating.getComment(),
                rating.getCreatedAt()
        );
    }

    public SkillSwapResponse toResponse(SkillSwap swap, List<SwapRating> ratings) {
        return new SkillSwapResponse(
                swap.getId(),
                swap.getRequesterId(),
                swap.getReceiverId(),
                toResponse(swap.getRequesterLearnsSkill()),
                toResponse(swap.getReceiverLearnsSkill()),
                swap.getStatus(),
                swap.getScheduledAt(),
                swap.getLocation(),
                swap.getMessage(),
                swap.getDecisionReason(),
                swap.getDecidedAt(),
                swap.getCompletedAt(),
                ratings.stream().map(this::toResponse).toList(),
                swap.getCreatedAt()
        );
    }
}
