package com.unigate.communication.repository;

import com.unigate.communication.domain.entity.SkillOffer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface SkillOfferRepository extends JpaRepository<SkillOffer, Long> {
    List<SkillOffer> findByStudentIdAndActiveTrue(Long studentId);
    List<SkillOffer> findBySkillIdAndActiveTrue(Long skillId);
    Optional<SkillOffer> findByStudentIdAndSkillId(Long studentId, Long skillId);
    boolean existsByStudentIdAndSkillIdAndActiveTrue(Long studentId, Long skillId);
}
