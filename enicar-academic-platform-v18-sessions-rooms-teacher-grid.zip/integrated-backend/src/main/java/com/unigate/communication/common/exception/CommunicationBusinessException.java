package com.unigate.communication.common.exception;

public class CommunicationBusinessException extends RuntimeException {
    public CommunicationBusinessException(String message) {
        super(message);
    }
}
