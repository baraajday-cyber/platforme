package com.unigate.communication.service.matching;

import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;

@Component
public class SkillMatchingAlgorithm {

    private static final double SKILL_WEIGHT = 0.30;
    private static final double AVAILABILITY_WEIGHT = 0.25;
    private static final double TUTOR_GRADE_WEIGHT = 0.25;
    private static final double HISTORY_WEIGHT = 0.10;
    private static final double DEPARTMENT_WEIGHT = 0.10;

    private static final int COMMON_AVAILABILITY_TARGET_MINUTES = 180;

    public MatchScore score(MatchInput input) {
        double skill = skillComplementarity(input.candidateTeachesRequestedSkill(), input.mutualExchange());
        double availability = Math.min(1.0, Math.max(0.0, input.commonAvailabilityMinutes() / (double) COMMON_AVAILABILITY_TARGET_MINUTES));
        double tutorGrade = normalizeTutorGrade(input.tutorGrade());
        double history = normalizeRating(input.averageRating());
        double department = input.sameDepartment() ? 1.0 : 0.4;

        double total = 100.0 * (
                SKILL_WEIGHT * skill
                        + AVAILABILITY_WEIGHT * availability
                        + TUTOR_GRADE_WEIGHT * tutorGrade
                        + HISTORY_WEIGHT * history
                        + DEPARTMENT_WEIGHT * department
        );
        return new MatchScore(
                decimal(total),
                decimal(skill * 100.0),
                decimal(availability * 100.0),
                decimal(tutorGrade * 100.0),
                decimal(history * 100.0),
                decimal(department * 100.0),
                input.mutualExchange()
        );
    }

    private double skillComplementarity(boolean candidateTeachesRequestedSkill, boolean mutualExchange) {
        if (candidateTeachesRequestedSkill && mutualExchange) {
            return 1.0;
        }
        if (candidateTeachesRequestedSkill) {
            return 0.65;
        }
        return 0.0;
    }

    private double normalizeTutorGrade(BigDecimal tutorGrade) {
        if (tutorGrade == null) {
            return 0.55;
        }
        return clamp(tutorGrade.doubleValue() / 20.0);
    }

    private double normalizeRating(BigDecimal rating) {
        if (rating == null || rating.compareTo(BigDecimal.ZERO) <= 0) {
            return 0.70;
        }
        return clamp(rating.doubleValue() / 5.0);
    }

    private double clamp(double value) {
        return Math.max(0.0, Math.min(1.0, value));
    }

    private BigDecimal decimal(double value) {
        return BigDecimal.valueOf(value).setScale(2, RoundingMode.HALF_UP);
    }
}
