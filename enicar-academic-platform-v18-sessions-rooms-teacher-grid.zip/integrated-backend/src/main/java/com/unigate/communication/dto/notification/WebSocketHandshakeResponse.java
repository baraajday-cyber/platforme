package com.unigate.communication.dto.notification;

import java.time.Instant;

public record WebSocketHandshakeResponse(Long studentId, String status, Instant serverTime) {
}
