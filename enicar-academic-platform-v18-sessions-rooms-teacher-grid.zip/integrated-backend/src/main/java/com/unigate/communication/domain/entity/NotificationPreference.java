package com.unigate.communication.domain.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "notification_preferences", indexes = @Index(name = "idx_notification_pref_student", columnList = "student_id", unique = true))
public class NotificationPreference extends BaseCommunicationEntity {

    @Column(name = "student_id", nullable = false, unique = true)
    private Long studentId;

    @Column(nullable = false)
    @Builder.Default
    private boolean websocketEnabled = true;

    @Column(nullable = false)
    @Builder.Default
    private boolean emailEnabled = false;

    @Column(nullable = false)
    @Builder.Default
    private boolean timetableUpdates = true;

    @Column(nullable = false)
    @Builder.Default
    private boolean gradeUpdates = true;

    @Column(nullable = false)
    @Builder.Default
    private boolean swapUpdates = true;

    @Column(nullable = false)
    @Builder.Default
    private boolean registrationUpdates = true;

    @Column(nullable = false)
    @Builder.Default
    private boolean weeklyDigest = false;
}
