package com.unigate.communication.domain.enums;

public enum SkillCategory {
    PROGRAMMING,
    DATABASE,
    MATHEMATICS,
    LANGUAGES,
    DESIGN,
    DATA_AI,
    NETWORK_SECURITY,
    SOFT_SKILLS,
    OTHER
}
