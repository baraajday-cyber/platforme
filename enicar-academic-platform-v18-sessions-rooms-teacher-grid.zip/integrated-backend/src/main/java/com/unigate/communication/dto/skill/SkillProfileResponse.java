package com.unigate.communication.dto.skill;

import java.util.List;

public record SkillProfileResponse(
        Long studentId,
        List<SkillOfferResponse> offers,
        List<SkillNeedResponse> needs
) {
}
