package com.unigate.communication.domain.entity;

import com.unigate.communication.domain.enums.SkillSwapStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(
        name = "skill_swaps",
        indexes = {
                @Index(name = "idx_skill_swap_requester", columnList = "requester_id"),
                @Index(name = "idx_skill_swap_receiver", columnList = "receiver_id"),
                @Index(name = "idx_skill_swap_status", columnList = "status")
        }
)
public class SkillSwap extends BaseCommunicationEntity {

    @Column(name = "requester_id", nullable = false)
    private Long requesterId;

    @Column(name = "receiver_id", nullable = false)
    private Long receiverId;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "requester_learns_skill_id", nullable = false)
    private Skill requesterLearnsSkill;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "receiver_learns_skill_id")
    private Skill receiverLearnsSkill;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    @Builder.Default
    private SkillSwapStatus status = SkillSwapStatus.PENDING;

    @Column(name = "scheduled_at")
    private Instant scheduledAt;

    @Column(length = 160)
    private String location;

    @Column(length = 1000)
    private String message;

    @Column(name = "decision_reason", length = 500)
    private String decisionReason;

    @Column(name = "decided_at")
    private Instant decidedAt;

    @Column(name = "completed_at")
    private Instant completedAt;

    public boolean involves(Long studentId) {
        return requesterId.equals(studentId) || receiverId.equals(studentId);
    }

    public Long otherParticipant(Long studentId) {
        if (requesterId.equals(studentId)) {
            return receiverId;
        }
        if (receiverId.equals(studentId)) {
            return requesterId;
        }
        return null;
    }
}
