package com.unigate.communication.domain.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(
        name = "swap_ratings",
        uniqueConstraints = @UniqueConstraint(name = "uk_swap_rating_once", columnNames = {"swap_id", "rater_id", "rated_id"}),
        indexes = @Index(name = "idx_swap_rating_rated", columnList = "rated_id")
)
public class SwapRating extends BaseCommunicationEntity {

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "swap_id", nullable = false)
    private SkillSwap swap;

    @Column(name = "rater_id", nullable = false)
    private Long raterId;

    @Column(name = "rated_id", nullable = false)
    private Long ratedId;

    @Min(1)
    @Max(5)
    @Column(nullable = false)
    private int score;

    @Column(length = 1000)
    private String comment;
}
