package com.unigate.communication.service.matching;

import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalTime;
import java.util.Optional;

public record TimeWindow(DayOfWeek dayOfWeek, LocalTime startTime, LocalTime endTime) {
    public TimeWindow {
        if (dayOfWeek == null || startTime == null || endTime == null) {
            throw new IllegalArgumentException("dayOfWeek, startTime and endTime are required");
        }
        if (!startTime.isBefore(endTime)) {
            throw new IllegalArgumentException("A time window start must be before its end");
        }
    }

    public int minutes() {
        return Math.toIntExact(Duration.between(startTime, endTime).toMinutes());
    }

    public Optional<TimeWindow> intersection(TimeWindow other) {
        if (!dayOfWeek.equals(other.dayOfWeek())) {
            return Optional.empty();
        }
        LocalTime start = startTime.isAfter(other.startTime()) ? startTime : other.startTime();
        LocalTime end = endTime.isBefore(other.endTime()) ? endTime : other.endTime();
        if (start.isBefore(end)) {
            return Optional.of(new TimeWindow(dayOfWeek, start, end));
        }
        return Optional.empty();
    }
}
