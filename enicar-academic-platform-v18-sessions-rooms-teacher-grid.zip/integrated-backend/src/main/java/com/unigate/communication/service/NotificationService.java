package com.unigate.communication.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.unigate.communication.common.exception.CommunicationForbiddenException;
import com.unigate.communication.common.exception.CommunicationNotFoundException;
import com.unigate.communication.domain.entity.Notification;
import com.unigate.communication.domain.entity.NotificationPreference;
import com.unigate.communication.domain.enums.NotificationPriority;
import com.unigate.communication.domain.enums.NotificationType;
import com.unigate.communication.dto.common.PageResponse;
import com.unigate.communication.dto.notification.NotificationPreferenceRequest;
import com.unigate.communication.dto.notification.NotificationPreferenceResponse;
import com.unigate.communication.dto.notification.NotificationResponse;
import com.unigate.communication.mapper.CommunicationMapper;
import com.unigate.communication.repository.NotificationPreferenceRepository;
import com.unigate.communication.repository.NotificationRepository;
import com.unigate.communication.websocket.WebSocketPublisher;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.Collection;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class NotificationService {

    private final NotificationRepository notificationRepository;
    private final NotificationPreferenceRepository preferenceRepository;
    private final CommunicationMapper mapper;
    private final WebSocketPublisher webSocketPublisher;
    private final EmailNotificationService emailNotificationService;
    private final StudentContactPort studentContactPort;
    private final ObjectMapper objectMapper;

    @Value("${unigate.communication.default-email-enabled:false}")
    private boolean defaultEmailEnabled;

    @Transactional
    public NotificationResponse notifyStudent(NotificationCommand command) {
        NotificationPreference preference = preferenceFor(command.recipientId());
        Notification notification = Notification.builder()
                .recipientId(command.recipientId())
                .senderId(command.senderId())
                .type(command.type())
                .priority(command.priority() == null ? NotificationPriority.NORMAL : command.priority())
                .title(command.title())
                .message(command.message())
                .payloadJson(toJson(command.payload()))
                .linkUrl(command.linkUrl())
                .build();
        Notification saved = notificationRepository.save(notification);
        NotificationResponse response = mapper.toResponse(saved);

        if (preference.isWebsocketEnabled() && typeEnabled(preference, saved.getType())) {
            saved.setDeliveredAt(Instant.now());
            webSocketPublisher.sendToStudent(saved.getRecipientId(), "/queue/notifications", response);
        }

        if (preference.isEmailEnabled() && typeEnabled(preference, saved.getType())) {
            emailNotificationService.sendNotificationEmail(saved, studentContactPort.emailForStudent(saved.getRecipientId()));
            saved.setEmailSentAt(Instant.now());
        }
        return mapper.toResponse(saved);
    }

    @Transactional
    public void notifyStudents(Collection<Long> studentIds, NotificationCommand prototype) {
        studentIds.stream().distinct().forEach(studentId -> notifyStudent(NotificationCommand.builder()
                .recipientId(studentId)
                .senderId(prototype.senderId())
                .type(prototype.type())
                .priority(prototype.priority())
                .title(prototype.title())
                .message(prototype.message())
                .payload(prototype.payload())
                .linkUrl(prototype.linkUrl())
                .build()));
    }

    @Transactional(readOnly = true)
    public PageResponse<NotificationResponse> list(Long studentId, int page, int size) {
        int safePage = Math.max(0, page);
        int safeSize = Math.min(Math.max(1, size), 100);
        var pageable = PageRequest.of(safePage, safeSize, Sort.by(Sort.Direction.DESC, "createdAt"));
        return PageResponse.from(notificationRepository.findByRecipientIdOrderByCreatedAtDesc(studentId, pageable).map(mapper::toResponse));
    }

    @Transactional(readOnly = true)
    public long unreadCount(Long studentId) {
        return notificationRepository.countByRecipientIdAndReadAtIsNull(studentId);
    }

    @Transactional
    public NotificationResponse markRead(Long studentId, Long notificationId) {
        Notification notification = notificationRepository.findById(notificationId)
                .orElseThrow(() -> new CommunicationNotFoundException("Notification introuvable: " + notificationId));
        if (!notification.getRecipientId().equals(studentId)) {
            throw new CommunicationForbiddenException("Cette notification appartient a un autre etudiant.");
        }
        if (notification.getReadAt() == null) {
            notification.setReadAt(Instant.now());
        }
        return mapper.toResponse(notification);
    }

    @Transactional
    public int markAllRead(Long studentId) {
        return notificationRepository.markAllAsRead(studentId, Instant.now());
    }

    @Transactional
    public NotificationPreferenceResponse getPreferences(Long studentId) {
        return mapper.toResponse(preferenceFor(studentId));
    }

    @Transactional
    public NotificationPreferenceResponse updatePreferences(Long studentId, NotificationPreferenceRequest request) {
        NotificationPreference preference = preferenceFor(studentId);
        preference.setWebsocketEnabled(request.websocketEnabled());
        preference.setEmailEnabled(request.emailEnabled());
        preference.setTimetableUpdates(request.timetableUpdates());
        preference.setGradeUpdates(request.gradeUpdates());
        preference.setSwapUpdates(request.swapUpdates());
        preference.setRegistrationUpdates(request.registrationUpdates());
        preference.setWeeklyDigest(request.weeklyDigest());
        return mapper.toResponse(preference);
    }

    private NotificationPreference preferenceFor(Long studentId) {
        return preferenceRepository.findByStudentId(studentId).orElseGet(() -> preferenceRepository.save(NotificationPreference.builder()
                .studentId(studentId)
                .websocketEnabled(true)
                .emailEnabled(defaultEmailEnabled)
                .timetableUpdates(true)
                .gradeUpdates(true)
                .swapUpdates(true)
                .registrationUpdates(true)
                .weeklyDigest(false)
                .build()));
    }

    private boolean typeEnabled(NotificationPreference preference, NotificationType type) {
        return switch (type) {
            case TIMETABLE_CHANGED -> preference.isTimetableUpdates();
            case GRADE_UPDATED, GRADE_SIMULATION -> preference.isGradeUpdates();
            case SKILL_SWAP_REQUEST, SKILL_SWAP_ACCEPTED, SKILL_SWAP_REJECTED, SKILL_SWAP_SCHEDULED, SKILL_SWAP_COMPLETED, SWAP_RATED -> preference.isSwapUpdates();
            case REGISTRATION_STATUS, DOCUMENT_REVIEW -> preference.isRegistrationUpdates();
            case SYSTEM -> true;
        };
    }

    private String toJson(Map<String, Object> payload) {
        if (payload == null || payload.isEmpty()) {
            return null;
        }
        try {
            return objectMapper.writeValueAsString(payload);
        } catch (JsonProcessingException ex) {
            return "{}";
        }
    }
}
