package com.unigate.communication.service.matching;

import org.springframework.stereotype.Service;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;

@Service
public class AvailabilityService {

    private static final EnumSet<DayOfWeek> UNIVERSITY_DAYS = EnumSet.of(
            DayOfWeek.MONDAY,
            DayOfWeek.TUESDAY,
            DayOfWeek.WEDNESDAY,
            DayOfWeek.THURSDAY,
            DayOfWeek.FRIDAY,
            DayOfWeek.SATURDAY
    );

    public List<TimeWindow> freeWindows(List<TimeWindow> busyWindows, LocalTime dayStart, LocalTime dayEnd) {
        List<TimeWindow> free = new ArrayList<>();
        for (DayOfWeek day : UNIVERSITY_DAYS) {
            List<TimeWindow> dayBusy = busyWindows.stream()
                    .filter(w -> w.dayOfWeek().equals(day))
                    .map(w -> clip(w, dayStart, dayEnd))
                    .flatMap(List::stream)
                    .sorted(Comparator.comparing(TimeWindow::startTime))
                    .toList();

            LocalTime cursor = dayStart;
            for (TimeWindow busy : merge(dayBusy)) {
                if (cursor.isBefore(busy.startTime())) {
                    free.add(new TimeWindow(day, cursor, busy.startTime()));
                }
                if (busy.endTime().isAfter(cursor)) {
                    cursor = busy.endTime();
                }
            }
            if (cursor.isBefore(dayEnd)) {
                free.add(new TimeWindow(day, cursor, dayEnd));
            }
        }
        return free;
    }

    public List<TimeWindow> commonFreeWindows(List<TimeWindow> busyA, List<TimeWindow> busyB, LocalTime dayStart, LocalTime dayEnd) {
        List<TimeWindow> freeA = freeWindows(busyA, dayStart, dayEnd);
        List<TimeWindow> freeB = freeWindows(busyB, dayStart, dayEnd);
        List<TimeWindow> common = new ArrayList<>();
        for (TimeWindow a : freeA) {
            for (TimeWindow b : freeB) {
                a.intersection(b).ifPresent(common::add);
            }
        }
        return common.stream()
                .filter(window -> window.minutes() > 0)
                .sorted(Comparator.comparing(TimeWindow::dayOfWeek).thenComparing(TimeWindow::startTime))
                .toList();
    }

    public int totalMinutes(List<TimeWindow> windows) {
        return windows.stream().mapToInt(TimeWindow::minutes).sum();
    }

    private List<TimeWindow> clip(TimeWindow window, LocalTime dayStart, LocalTime dayEnd) {
        LocalTime start = window.startTime().isBefore(dayStart) ? dayStart : window.startTime();
        LocalTime end = window.endTime().isAfter(dayEnd) ? dayEnd : window.endTime();
        if (!start.isBefore(end)) {
            return List.of();
        }
        return List.of(new TimeWindow(window.dayOfWeek(), start, end));
    }

    private List<TimeWindow> merge(List<TimeWindow> windows) {
        List<TimeWindow> merged = new ArrayList<>();
        for (TimeWindow current : windows) {
            if (merged.isEmpty()) {
                merged.add(current);
                continue;
            }
            TimeWindow last = merged.get(merged.size() - 1);
            boolean overlapOrTouch = !current.startTime().isAfter(last.endTime());
            if (last.dayOfWeek().equals(current.dayOfWeek()) && overlapOrTouch) {
                LocalTime end = current.endTime().isAfter(last.endTime()) ? current.endTime() : last.endTime();
                merged.set(merged.size() - 1, new TimeWindow(last.dayOfWeek(), last.startTime(), end));
            } else {
                merged.add(current);
            }
        }
        return merged;
    }
}
