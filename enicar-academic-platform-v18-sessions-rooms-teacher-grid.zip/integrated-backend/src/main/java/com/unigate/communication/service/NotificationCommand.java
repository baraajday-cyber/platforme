package com.unigate.communication.service;

import com.unigate.communication.domain.enums.NotificationPriority;
import com.unigate.communication.domain.enums.NotificationType;
import lombok.Builder;

import java.util.Map;

@Builder
public record NotificationCommand(
        Long recipientId,
        Long senderId,
        NotificationType type,
        NotificationPriority priority,
        String title,
        String message,
        Map<String, Object> payload,
        String linkUrl
) {
}
