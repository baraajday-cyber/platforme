package com.unigate.communication.service.matching;

import java.math.BigDecimal;

public record MatchInput(
        boolean candidateTeachesRequestedSkill,
        boolean mutualExchange,
        int commonAvailabilityMinutes,
        BigDecimal tutorGrade,
        BigDecimal averageRating,
        boolean sameDepartment
) {
}
