package com.unigate.communication.service;

import com.unigate.communication.common.exception.CommunicationBusinessException;
import com.unigate.communication.common.exception.CommunicationForbiddenException;
import com.unigate.communication.common.exception.CommunicationNotFoundException;
import com.unigate.communication.domain.entity.Skill;
import com.unigate.communication.domain.entity.SkillSwap;
import com.unigate.communication.domain.entity.SwapRating;
import com.unigate.communication.domain.enums.NotificationPriority;
import com.unigate.communication.domain.enums.NotificationType;
import com.unigate.communication.domain.enums.SkillSwapStatus;
import com.unigate.communication.dto.skill.SkillSwapCreateRequest;
import com.unigate.communication.dto.skill.SkillSwapDecisionRequest;
import com.unigate.communication.dto.skill.SkillSwapResponse;
import com.unigate.communication.dto.skill.SkillSwapScheduleRequest;
import com.unigate.communication.dto.skill.SwapRatingRequest;
import com.unigate.communication.dto.skill.SwapRatingResponse;
import com.unigate.communication.event.SkillSwapStatusChangedEvent;
import com.unigate.communication.mapper.CommunicationMapper;
import com.unigate.communication.repository.SkillOfferRepository;
import com.unigate.communication.repository.SkillSwapRepository;
import com.unigate.communication.repository.SwapRatingRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class SkillSwapService {

    private final SkillCatalogService skillCatalogService;
    private final AcademicBridgeService academicBridgeService;
    private final SkillOfferRepository offerRepository;
    private final SkillSwapRepository swapRepository;
    private final SwapRatingRepository ratingRepository;
    private final NotificationService notificationService;
    private final CommunicationMapper mapper;
    private final ApplicationEventPublisher eventPublisher;

    @Transactional
    public SkillSwapResponse createRequest(Long requesterId, SkillSwapCreateRequest request) {
        if (requesterId.equals(request.receiverId())) {
            throw new CommunicationBusinessException("Un etudiant ne peut pas envoyer une demande Skill Swap a lui-meme.");
        }
        academicBridgeService.assertSkillSwapAccess(requesterId, request.year(), request.semester());
        academicBridgeService.assertSkillSwapAccess(request.receiverId(), request.year(), request.semester());
        Skill requesterLearns = skillCatalogService.getRequired(request.requesterLearnsSkillId());
        Skill receiverLearns = request.receiverLearnsSkillId() == null ? null : skillCatalogService.getRequired(request.receiverLearnsSkillId());
        if (!offerRepository.existsByStudentIdAndSkillIdAndActiveTrue(request.receiverId(), request.requesterLearnsSkillId())) {
            throw new CommunicationBusinessException("Le destinataire n'offre pas cette competence.");
        }
        if (swapRepository.existsByRequesterIdAndReceiverIdAndRequesterLearnsSkillIdAndStatus(
                requesterId, request.receiverId(), request.requesterLearnsSkillId(), SkillSwapStatus.PENDING)) {
            throw new CommunicationBusinessException("Une demande Skill Swap similaire est deja en attente.");
        }

        SkillSwap swap = SkillSwap.builder()
                .requesterId(requesterId)
                .receiverId(request.receiverId())
                .requesterLearnsSkill(requesterLearns)
                .receiverLearnsSkill(receiverLearns)
                .message(request.message())
                .status(SkillSwapStatus.PENDING)
                .build();
        SkillSwap saved = swapRepository.save(swap);
        notifySwap(saved, request.receiverId(), requesterId, NotificationType.SKILL_SWAP_REQUEST,
                "Nouvelle demande Skill Swap",
                "Un etudiant souhaite apprendre " + requesterLearns.getName() + " avec vous.");
        publish(saved, SkillSwapStatus.PENDING);
        return toResponse(saved);
    }

    @Transactional
    public SkillSwapResponse accept(Long studentId, Long swapId, SkillSwapDecisionRequest request) {
        SkillSwap swap = getRequired(swapId);
        assertReceiver(studentId, swap);
        assertStatus(swap, SkillSwapStatus.PENDING);
        swap.setStatus(SkillSwapStatus.ACCEPTED);
        swap.setDecisionReason(request == null ? null : request.reason());
        swap.setDecidedAt(Instant.now());
        notifySwap(swap, swap.getRequesterId(), studentId, NotificationType.SKILL_SWAP_ACCEPTED,
                "Demande Skill Swap acceptee",
                "Votre demande pour " + swap.getRequesterLearnsSkill().getName() + " a ete acceptee.");
        publish(swap, SkillSwapStatus.ACCEPTED);
        return toResponse(swap);
    }

    @Transactional
    public SkillSwapResponse reject(Long studentId, Long swapId, SkillSwapDecisionRequest request) {
        SkillSwap swap = getRequired(swapId);
        assertReceiver(studentId, swap);
        assertStatus(swap, SkillSwapStatus.PENDING);
        swap.setStatus(SkillSwapStatus.REJECTED);
        swap.setDecisionReason(request == null ? null : request.reason());
        swap.setDecidedAt(Instant.now());
        notifySwap(swap, swap.getRequesterId(), studentId, NotificationType.SKILL_SWAP_REJECTED,
                "Demande Skill Swap refusee",
                "Votre demande pour " + swap.getRequesterLearnsSkill().getName() + " a ete refusee.");
        publish(swap, SkillSwapStatus.REJECTED);
        return toResponse(swap);
    }

    @Transactional
    public SkillSwapResponse schedule(Long studentId, Long swapId, SkillSwapScheduleRequest request) {
        SkillSwap swap = getRequired(swapId);
        assertParticipant(studentId, swap);
        if (!(swap.getStatus() == SkillSwapStatus.ACCEPTED || swap.getStatus() == SkillSwapStatus.SCHEDULED)) {
            throw new CommunicationBusinessException("Seule une demande acceptee peut etre planifiee.");
        }
        swap.setStatus(SkillSwapStatus.SCHEDULED);
        swap.setScheduledAt(request.scheduledAt());
        swap.setLocation(request.location());
        notifySwap(swap, swap.otherParticipant(studentId), studentId, NotificationType.SKILL_SWAP_SCHEDULED,
                "Session Skill Swap planifiee",
                "Une session Skill Swap a ete planifiee pour " + swap.getRequesterLearnsSkill().getName() + ".");
        publish(swap, SkillSwapStatus.SCHEDULED);
        return toResponse(swap);
    }

    @Transactional
    public SkillSwapResponse complete(Long studentId, Long swapId) {
        SkillSwap swap = getRequired(swapId);
        assertParticipant(studentId, swap);
        if (!(swap.getStatus() == SkillSwapStatus.ACCEPTED || swap.getStatus() == SkillSwapStatus.SCHEDULED)) {
            throw new CommunicationBusinessException("Ce swap ne peut pas etre marque comme termine.");
        }
        swap.setStatus(SkillSwapStatus.COMPLETED);
        swap.setCompletedAt(Instant.now());
        notifySwap(swap, swap.otherParticipant(studentId), studentId, NotificationType.SKILL_SWAP_COMPLETED,
                "Skill Swap termine",
                "Votre session Skill Swap est marquee comme terminee. Vous pouvez maintenant noter votre partenaire.");
        publish(swap, SkillSwapStatus.COMPLETED);
        return toResponse(swap);
    }

    @Transactional
    public SwapRatingResponse rate(Long studentId, Long swapId, SwapRatingRequest request) {
        SkillSwap swap = getRequired(swapId);
        assertParticipant(studentId, swap);
        assertStatus(swap, SkillSwapStatus.COMPLETED);
        Long ratedId = swap.otherParticipant(studentId);
        if (ratingRepository.existsBySwapIdAndRaterIdAndRatedId(swapId, studentId, ratedId)) {
            throw new CommunicationBusinessException("Vous avez deja note ce partenaire pour ce swap.");
        }
        SwapRating rating = SwapRating.builder()
                .swap(swap)
                .raterId(studentId)
                .ratedId(ratedId)
                .score(request.score())
                .comment(request.comment())
                .build();
        SwapRating saved = ratingRepository.save(rating);
        notificationService.notifyStudent(NotificationCommand.builder()
                .recipientId(ratedId)
                .senderId(studentId)
                .type(NotificationType.SWAP_RATED)
                .priority(NotificationPriority.NORMAL)
                .title("Nouvelle evaluation Skill Swap")
                .message("Vous avez recu une note de " + request.score() + "/5.")
                .payload(Map.of("swapId", swapId, "ratingId", saved.getId(), "score", request.score()))
                .linkUrl("/skill-swap/swaps/" + swapId)
                .build());
        return mapper.toResponse(saved);
    }

    @Transactional(readOnly = true)
    public List<SkillSwapResponse> mySwaps(Long studentId) {
        return swapRepository.findForStudent(studentId).stream().map(this::toResponse).toList();
    }

    private SkillSwap getRequired(Long swapId) {
        return swapRepository.findById(swapId)
                .orElseThrow(() -> new CommunicationNotFoundException("Skill Swap introuvable: " + swapId));
    }

    private SkillSwapResponse toResponse(SkillSwap swap) {
        return mapper.toResponse(swap, ratingRepository.findBySwapIdOrderByCreatedAtDesc(swap.getId()));
    }

    private void assertParticipant(Long studentId, SkillSwap swap) {
        if (!swap.involves(studentId)) {
            throw new CommunicationForbiddenException("Vous n'etes pas participant de ce Skill Swap.");
        }
    }

    private void assertReceiver(Long studentId, SkillSwap swap) {
        if (!swap.getReceiverId().equals(studentId)) {
            throw new CommunicationForbiddenException("Seul le destinataire peut accepter ou refuser cette demande.");
        }
    }

    private void assertStatus(SkillSwap swap, SkillSwapStatus expected) {
        if (swap.getStatus() != expected) {
            throw new CommunicationBusinessException("Statut invalide. Statut attendu: " + expected + ", statut actuel: " + swap.getStatus());
        }
    }

    private void notifySwap(SkillSwap swap, Long recipientId, Long senderId, NotificationType type, String title, String message) {
        if (recipientId == null) {
            return;
        }
        notificationService.notifyStudent(NotificationCommand.builder()
                .recipientId(recipientId)
                .senderId(senderId)
                .type(type)
                .priority(NotificationPriority.HIGH)
                .title(title)
                .message(message)
                .payload(Map.of("swapId", swap.getId(), "status", swap.getStatus().name()))
                .linkUrl("/skill-swap/swaps/" + swap.getId())
                .build());
    }

    private void publish(SkillSwap swap, SkillSwapStatus status) {
        eventPublisher.publishEvent(new SkillSwapStatusChangedEvent(swap.getId(), swap.getRequesterId(), swap.getReceiverId(), status, Instant.now()));
    }
}
