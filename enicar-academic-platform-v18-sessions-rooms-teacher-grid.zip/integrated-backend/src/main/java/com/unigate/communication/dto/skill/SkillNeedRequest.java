package com.unigate.communication.dto.skill;

import com.unigate.communication.domain.enums.SkillLevel;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record SkillNeedRequest(
        @NotNull Long skillId,
        @NotNull SkillLevel targetLevel,
        @Size(max = 700) String objective
) {
}
