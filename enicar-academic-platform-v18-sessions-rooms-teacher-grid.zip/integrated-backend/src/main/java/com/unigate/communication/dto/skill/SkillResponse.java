package com.unigate.communication.dto.skill;

import com.unigate.communication.domain.enums.SkillCategory;

public record SkillResponse(
        Long id,
        String name,
        String normalizedName,
        SkillCategory category,
        String description,
        Long academicCourseId,
        String department,
        boolean active
) {
}
