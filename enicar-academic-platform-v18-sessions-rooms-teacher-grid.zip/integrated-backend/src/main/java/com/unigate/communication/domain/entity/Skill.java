package com.unigate.communication.domain.entity;

import com.unigate.communication.domain.enums.SkillCategory;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Index;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(
        name = "skills",
        uniqueConstraints = @UniqueConstraint(name = "uk_skill_normalized", columnNames = "normalized_name"),
        indexes = @Index(name = "idx_skill_category", columnList = "category")
)
public class Skill extends BaseCommunicationEntity {

    @Column(nullable = false, length = 120)
    private String name;

    @Column(name = "normalized_name", nullable = false, length = 140)
    private String normalizedName;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 40)
    private SkillCategory category;

    @Column(length = 500)
    private String description;

    @Column(name = "academic_course_id")
    private Long academicCourseId;

    @Column(length = 80)
    private String department;

    @Column(nullable = false)
    @Builder.Default
    private boolean active = true;
}
