package com.unigate.communication.config;

import com.unigate.academic.domain.entity.AcademicModule;
import com.unigate.academic.domain.entity.ClassGroup;
import com.unigate.academic.domain.entity.Course;
import com.unigate.academic.domain.entity.GradeConfig;
import com.unigate.academic.domain.entity.StudentClassAssignment;
import com.unigate.academic.domain.entity.StudentGrade;
import com.unigate.academic.domain.entity.TimetableSlot;
import com.unigate.academic.domain.enums.Semester;
import com.unigate.academic.domain.enums.SlotStatus;
import com.unigate.academic.repository.AcademicModuleRepository;
import com.unigate.academic.repository.ClassGroupRepository;
import com.unigate.academic.repository.CourseRepository;
import com.unigate.academic.repository.GradeConfigRepository;
import com.unigate.academic.repository.StudentClassAssignmentRepository;
import com.unigate.academic.repository.StudentGradeRepository;
import com.unigate.academic.repository.TimetableSlotRepository;
import com.unigate.communication.domain.entity.Notification;
import com.unigate.communication.domain.entity.NotificationPreference;
import com.unigate.communication.domain.entity.Skill;
import com.unigate.communication.domain.entity.SkillLearningRequest;
import com.unigate.communication.domain.entity.SkillOffer;
import com.unigate.communication.domain.enums.NotificationPriority;
import com.unigate.communication.domain.enums.NotificationType;
import com.unigate.communication.domain.enums.SkillCategory;
import com.unigate.communication.domain.enums.SkillLevel;
import com.unigate.communication.repository.NotificationPreferenceRepository;
import com.unigate.communication.repository.NotificationRepository;
import com.unigate.communication.repository.SkillLearningRequestRepository;
import com.unigate.communication.repository.SkillOfferRepository;
import com.unigate.communication.repository.SkillRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.time.LocalTime;

@Configuration
public class DemoDataInitializer {

    private static final String DEPARTMENT = "Informatique";
    private static final int YEAR = 1;
    private static final Semester SEMESTER = Semester.S1;

    @Bean
    CommandLineRunner seedUniGateDemoData(
            SkillRepository skillRepository,
            SkillOfferRepository offerRepository,
            SkillLearningRequestRepository needRepository,
            NotificationRepository notificationRepository,
            NotificationPreferenceRepository preferenceRepository,
            ClassGroupRepository classGroupRepository,
            CourseRepository courseRepository,
            AcademicModuleRepository moduleRepository,
            GradeConfigRepository gradeConfigRepository,
            StudentClassAssignmentRepository assignmentRepository,
            TimetableSlotRepository timetableSlotRepository,
            StudentGradeRepository studentGradeRepository
    ) {
        return args -> {
            Course javaCourse = seedCourse(courseRepository, "Java", "JAVA101", "Programmation orientee objet", 3, 5);
            Course sqlCourse = seedCourse(courseRepository, "SQL", "DB101", "Bases de donnees relationnelles", 2, 4);
            Course pythonCourse = seedCourse(courseRepository, "Python", "PY101", "Programmation Python", 2, 4);
            Course networkCourse = seedCourse(courseRepository, "Reseaux", "NET101", "Fondamentaux reseaux", 2, 3);

            AcademicModule devModule = seedModule(moduleRepository, "UE Developpement", 3, 10);
            AcademicModule dataModule = seedModule(moduleRepository, "UE Donnees et Reseaux", 2, 7);

            seedGradeConfig(gradeConfigRepository, javaCourse, devModule, "3", "3", "0.35", "0.65", "0.00", 5);
            seedGradeConfig(gradeConfigRepository, pythonCourse, devModule, "2", "3", "0.40", "0.60", "0.00", 5);
            seedGradeConfig(gradeConfigRepository, sqlCourse, dataModule, "2", "2", "0.35", "0.50", "0.15", 4);
            seedGradeConfig(gradeConfigRepository, networkCourse, dataModule, "2", "2", "0.30", "0.70", "0.00", 3);

            ClassGroup gl1 = seedClassGroup(classGroupRepository, "GL-1A", "Groupe demo etudiant #1");
            ClassGroup gl2 = seedClassGroup(classGroupRepository, "GL-1B", "Groupe demo etudiant #2");

            seedAssignment(assignmentRepository, 1L, gl1);
            seedAssignment(assignmentRepository, 2L, gl2);
            seedAssignment(assignmentRepository, 100L, gl1);

            seedSlot(timetableSlotRepository, gl1, javaCourse, DayOfWeek.MONDAY, "08:30", "10:00", "A101", 501L, "Mme Ben Salem");
            seedSlot(timetableSlotRepository, gl1, sqlCourse, DayOfWeek.TUESDAY, "10:15", "11:45", "B204", 502L, "M. Trabelsi");
            seedSlot(timetableSlotRepository, gl1, networkCourse, DayOfWeek.THURSDAY, "14:00", "15:30", "Lab Reseaux", 503L, "Mme Mansouri");

            seedSlot(timetableSlotRepository, gl2, pythonCourse, DayOfWeek.MONDAY, "10:15", "11:45", "C301", 504L, "M. Gharbi");
            seedSlot(timetableSlotRepository, gl2, sqlCourse, DayOfWeek.WEDNESDAY, "08:30", "10:00", "B204", 502L, "M. Trabelsi");
            seedSlot(timetableSlotRepository, gl2, javaCourse, DayOfWeek.THURSDAY, "10:15", "11:45", "Lab Dev", 501L, "Mme Ben Salem");

            seedGrade(studentGradeRepository, 1L, javaCourse, "14.00", "12.00", null, "12.70");
            seedGrade(studentGradeRepository, 1L, sqlCourse, "13.50", "10.00", "15.00", "12.23");
            seedGrade(studentGradeRepository, 1L, pythonCourse, "11.00", null, null, null);

            seedGrade(studentGradeRepository, 2L, javaCourse, "17.00", "16.00", null, "16.35");
            seedGrade(studentGradeRepository, 2L, sqlCourse, "15.00", "15.50", "16.00", "15.45");
            seedGrade(studentGradeRepository, 2L, pythonCourse, "14.00", "15.00", null, "14.60");

            Skill java = seedSkill(skillRepository, "Java", SkillCategory.PROGRAMMING, "Spring Boot, OOP, collections", DEPARTMENT, javaCourse.getId());
            Skill sql = seedSkill(skillRepository, "SQL", SkillCategory.DATABASE, "Requetes, jointures, modelisation", DEPARTMENT, sqlCourse.getId());
            Skill python = seedSkill(skillRepository, "Python", SkillCategory.PROGRAMMING, "Scripts, data, automatisation", DEPARTMENT, pythonCourse.getId());
            Skill ml = seedSkill(skillRepository, "Machine Learning", SkillCategory.DATA_AI, "Classification, regression, notebooks", DEPARTMENT, null);
            Skill networks = seedSkill(skillRepository, "Reseaux", SkillCategory.NETWORK_SECURITY, "TCP/IP, routage, CCNA", "Telecom", networkCourse.getId());
            Skill english = seedSkill(skillRepository, "Anglais technique", SkillCategory.LANGUAGES, "Presentation et redaction technique", "General", null);

            seedOffer(offerRepository, 1L, sql, SkillLevel.ADVANCED, "Je peux expliquer les jointures et la modelisation.");
            seedNeed(needRepository, 1L, java, SkillLevel.ADVANCED, "Je veux renforcer Spring Boot et POO.");
            seedNeed(needRepository, 1L, python, SkillLevel.INTERMEDIATE, "Je veux pratiquer les scripts et notebooks.");

            seedOffer(offerRepository, 2L, java, SkillLevel.EXPERT, "Tres bon niveau en Java et design objet.");
            seedOffer(offerRepository, 2L, python, SkillLevel.ADVANCED, "Python pour data et automatisation.");
            seedNeed(needRepository, 2L, sql, SkillLevel.INTERMEDIATE, "Je veux mieux comprendre les requetes SQL.");
            seedOffer(offerRepository, 100L, networks, SkillLevel.ADVANCED, "Aide ponctuelle sur reseaux.");
            seedNeed(needRepository, 100L, english, SkillLevel.INTERMEDIATE, "Preparation presentation technique.");

            seedPreferences(preferenceRepository, 1L);
            seedPreferences(preferenceRepository, 2L);
            seedPreferences(preferenceRepository, 100L);
            seedNotifications(notificationRepository);
        };
    }

    private Course seedCourse(CourseRepository repository, String name, String code, String description, int coefficient, int credits) {
        return repository.findByNameAndDepartment(name, DEPARTMENT).orElseGet(() -> repository.save(Course.builder()
                .name(name)
                .department(DEPARTMENT)
                .code(code)
                .defaultCoefficient(BigDecimal.valueOf(coefficient))
                .defaultCredits(credits)
                .build()));
    }

    private AcademicModule seedModule(AcademicModuleRepository repository, String name, int coefficient, int credits) {
        return repository.findByNameAndDepartmentAndYearAndSemester(name, DEPARTMENT, YEAR, SEMESTER).orElseGet(() -> repository.save(AcademicModule.builder()
                .name(name)
                .department(DEPARTMENT)
                .year(YEAR)
                .semester(SEMESTER)
                .moduleCoefficient(BigDecimal.valueOf(coefficient))
                .credits(credits)
                .build()));
    }

    private void seedGradeConfig(GradeConfigRepository repository, Course course, AcademicModule module, String subjectCoeff, String moduleCoeff, String cc, String exam, String tp, int credits) {
        repository.findByDepartmentAndYearAndSemesterAndSubjectIdAndModuleId(DEPARTMENT, YEAR, SEMESTER, course.getId(), module.getId()).orElseGet(() -> repository.save(GradeConfig.builder()
                .department(DEPARTMENT)
                .year(YEAR)
                .semester(SEMESTER)
                .subject(course)
                .module(module)
                .subjectCoefficient(new BigDecimal(subjectCoeff))
                .moduleCoefficient(new BigDecimal(moduleCoeff))
                .ccWeight(new BigDecimal(cc))
                .examWeight(new BigDecimal(exam))
                .tpWeight(new BigDecimal(tp))
                .credits(credits)
                .active(true)
                .build()));
    }

    private ClassGroup seedClassGroup(ClassGroupRepository repository, String name, String description) {
        return repository.findByNameAndDepartmentAndYearAndSemester(name, DEPARTMENT, YEAR, SEMESTER).orElseGet(() -> repository.save(ClassGroup.builder()
                .name(name)
                .department(DEPARTMENT)
                .year(YEAR)
                .semester(SEMESTER)
                .description(description)
                .build()));
    }

    private void seedAssignment(StudentClassAssignmentRepository repository, Long studentId, ClassGroup classGroup) {
        repository.findByStudentIdAndYearAndSemesterAndActiveTrue(studentId, YEAR, SEMESTER).orElseGet(() -> repository.save(StudentClassAssignment.builder()
                .studentId(studentId)
                .year(YEAR)
                .semester(SEMESTER)
                .classGroup(classGroup)
                .active(true)
                .build()));
    }

    private void seedSlot(TimetableSlotRepository repository, ClassGroup group, Course course, DayOfWeek day, String start, String end, String room, Long professorId, String professorName) {
        boolean exists = repository.findByClassGroupIdOrderByDayOfWeekAscStartTimeAsc(group.getId()).stream()
                .anyMatch(slot -> slot.getCourse() != null
                        && slot.getCourse().getId().equals(course.getId())
                        && slot.getDayOfWeek() == day
                        && slot.getStartTime().equals(LocalTime.parse(start)));
        if (!exists) {
            repository.save(TimetableSlot.builder()
                    .classGroup(group)
                    .course(course)
                    .dayOfWeek(day)
                    .startTime(LocalTime.parse(start))
                    .endTime(LocalTime.parse(end))
                    .room(room)
                    .professorId(professorId)
                    .professorName(professorName)
                    .status(SlotStatus.ACTIVE)
                    .build());
        }
    }

    private void seedGrade(StudentGradeRepository repository, Long studentId, Course course, String cc, String exam, String tp, String average) {
        repository.findByStudentIdAndYearAndSemesterAndSubjectId(studentId, YEAR, SEMESTER, course.getId()).orElseGet(() -> repository.save(StudentGrade.builder()
                .studentId(studentId)
                .department(DEPARTMENT)
                .year(YEAR)
                .semester(SEMESTER)
                .subject(course)
                .ccGrade(cc == null ? null : new BigDecimal(cc))
                .examGrade(exam == null ? null : new BigDecimal(exam))
                .tpGrade(tp == null ? null : new BigDecimal(tp))
                .subjectAverage(average == null ? null : new BigDecimal(average))
                .validated(average != null && new BigDecimal(average).compareTo(BigDecimal.TEN) >= 0)
                .build()));
    }

    private Skill seedSkill(SkillRepository repository, String name, SkillCategory category, String description, String department, Long courseId) {
        String normalizedName = name.trim().toLowerCase().replaceAll("\\s+", "-");
        return repository.findByNormalizedName(normalizedName).map(existing -> {
            if (existing.getAcademicCourseId() == null && courseId != null) {
                existing.setAcademicCourseId(courseId);
                return repository.save(existing);
            }
            return existing;
        }).orElseGet(() -> repository.save(Skill.builder()
                .name(name)
                .normalizedName(normalizedName)
                .category(category)
                .description(description)
                .department(department)
                .academicCourseId(courseId)
                .active(true)
                .build()));
    }

    private void seedOffer(SkillOfferRepository repository, Long studentId, Skill skill, SkillLevel level, String description) {
        repository.findByStudentIdAndSkillId(studentId, skill.getId()).orElseGet(() -> repository.save(SkillOffer.builder()
                .studentId(studentId)
                .skill(skill)
                .level(level)
                .description(description)
                .active(true)
                .build()));
    }

    private void seedNeed(SkillLearningRequestRepository repository, Long studentId, Skill skill, SkillLevel level, String objective) {
        repository.findByStudentIdAndSkillId(studentId, skill.getId()).orElseGet(() -> repository.save(SkillLearningRequest.builder()
                .studentId(studentId)
                .skill(skill)
                .targetLevel(level)
                .objective(objective)
                .active(true)
                .build()));
    }

    private void seedPreferences(NotificationPreferenceRepository repository, Long studentId) {
        repository.findByStudentId(studentId).orElseGet(() -> repository.save(NotificationPreference.builder()
                .studentId(studentId)
                .websocketEnabled(true)
                .emailEnabled(false)
                .timetableUpdates(true)
                .gradeUpdates(true)
                .swapUpdates(true)
                .registrationUpdates(true)
                .weeklyDigest(false)
                .build()));
    }

    private void seedNotifications(NotificationRepository repository) {
        if (repository.countByRecipientIdAndReadAtIsNull(1L) == 0) {
            repository.save(Notification.builder()
                    .recipientId(1L)
                    .type(NotificationType.SYSTEM)
                    .priority(NotificationPriority.NORMAL)
                    .title("Bienvenue dans UniGate")
                    .message("Ton espace Skill Swap, notes et notifications est pret pour les tests locaux.")
                    .linkUrl("/notifications")
                    .build());
            repository.save(Notification.builder()
                    .recipientId(1L)
                    .type(NotificationType.TIMETABLE_CHANGED)
                    .priority(NotificationPriority.HIGH)
                    .title("Emploi du temps mis a jour")
                    .message("Un changement de salle ou de creneau sera affiche ici en temps reel.")
                    .linkUrl("/timetable")
                    .build());
            repository.save(Notification.builder()
                    .recipientId(1L)
                    .type(NotificationType.GRADE_UPDATED)
                    .priority(NotificationPriority.NORMAL)
                    .title("Moyennes disponibles")
                    .message("Consulte tes notes, credits et la note necessaire pour valider.")
                    .linkUrl("/grades")
                    .build());
        }
    }
}
