package com.unigate.communication.common.api;

import java.time.Instant;
import java.util.Map;

public record CommunicationApiError(
        Instant timestamp,
        int status,
        String code,
        String message,
        String path,
        Map<String, String> fields
) {
    public static CommunicationApiError of(int status, String code, String message, String path) {
        return new CommunicationApiError(Instant.now(), status, code, message, path, Map.of());
    }

    public static CommunicationApiError withFields(int status, String code, String message, String path, Map<String, String> fields) {
        return new CommunicationApiError(Instant.now(), status, code, message, path, fields);
    }
}
