package com.unigate.communication.websocket;

import lombok.RequiredArgsConstructor;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class WebSocketPublisher {

    private final SimpMessagingTemplate messagingTemplate;

    public void sendToStudent(Long studentId, String queueSuffix, Object payload) {
        String suffix = queueSuffix.startsWith("/") ? queueSuffix : "/" + queueSuffix;
        messagingTemplate.convertAndSendToUser(studentId.toString(), suffix, payload);
        messagingTemplate.convertAndSend("/topic/students/" + studentId + suffix, payload);
    }

    public void sendToClassGroup(Long classGroupId, String topicSuffix, Object payload) {
        String suffix = topicSuffix.startsWith("/") ? topicSuffix : "/" + topicSuffix;
        messagingTemplate.convertAndSend("/topic/class-groups/" + classGroupId + suffix, payload);
    }

    public void sendToPublicTopic(String topic, Object payload) {
        String destination = topic.startsWith("/topic/") ? topic : "/topic/" + topic;
        messagingTemplate.convertAndSend(destination, payload);
    }
}
