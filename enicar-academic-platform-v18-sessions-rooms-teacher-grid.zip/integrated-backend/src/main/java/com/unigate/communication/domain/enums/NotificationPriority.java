package com.unigate.communication.domain.enums;

public enum NotificationPriority {
    LOW,
    NORMAL,
    HIGH,
    URGENT
}
