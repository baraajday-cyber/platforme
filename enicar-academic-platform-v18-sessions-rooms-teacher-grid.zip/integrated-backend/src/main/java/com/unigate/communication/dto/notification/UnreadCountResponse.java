package com.unigate.communication.dto.notification;

public record UnreadCountResponse(long unreadCount) {
}
