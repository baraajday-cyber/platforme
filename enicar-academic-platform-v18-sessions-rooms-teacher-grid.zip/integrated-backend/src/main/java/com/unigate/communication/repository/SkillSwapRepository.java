package com.unigate.communication.repository;

import com.unigate.communication.domain.entity.SkillSwap;
import com.unigate.communication.domain.enums.SkillSwapStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface SkillSwapRepository extends JpaRepository<SkillSwap, Long> {
    @Query("""
            select s from SkillSwap s
            where s.requesterId = :studentId or s.receiverId = :studentId
            order by s.createdAt desc
            """)
    List<SkillSwap> findForStudent(@Param("studentId") Long studentId);

    boolean existsByRequesterIdAndReceiverIdAndRequesterLearnsSkillIdAndStatus(
            Long requesterId,
            Long receiverId,
            Long requesterLearnsSkillId,
            SkillSwapStatus status
    );
}
