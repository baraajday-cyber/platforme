package com.unigate.communication.controller;

import com.unigate.communication.domain.enums.SkillCategory;
import com.unigate.communication.dto.skill.SkillRequestDto;
import com.unigate.communication.dto.skill.SkillResponse;
import com.unigate.communication.service.SkillCatalogService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/skills")
@Tag(name = "Skills catalog", description = "Catalogue de competences lie au Skill Swap")
public class SkillCatalogController {

    private final SkillCatalogService skillCatalogService;

    @GetMapping
    @PreAuthorize("hasAnyRole('STUDENT','DEPARTMENT_ADMIN','SUPER_ADMIN')")
    public List<SkillResponse> search(
            @RequestParam(required = false) String query,
            @RequestParam(required = false) SkillCategory category
    ) {
        return skillCatalogService.search(query, category);
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasAnyRole('DEPARTMENT_ADMIN','SUPER_ADMIN')")
    public SkillResponse create(@Valid @RequestBody SkillRequestDto request) {
        return skillCatalogService.create(request);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('DEPARTMENT_ADMIN','SUPER_ADMIN')")
    public SkillResponse update(@PathVariable Long id, @Valid @RequestBody SkillRequestDto request) {
        return skillCatalogService.update(id, request);
    }
}
