package com.unigate.communication.service.matching;

import java.math.BigDecimal;

public record MatchScore(
        BigDecimal totalScore,
        BigDecimal skillComplementarityScore,
        BigDecimal availabilityScore,
        BigDecimal tutorGradeScore,
        BigDecimal historyScore,
        BigDecimal departmentScore,
        boolean mutualExchange
) {
}
