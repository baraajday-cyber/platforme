package com.unigate.communication.dto.skill;

import com.unigate.communication.domain.enums.SkillLevel;

public record SkillNeedResponse(
        Long id,
        Long studentId,
        SkillResponse skill,
        SkillLevel targetLevel,
        String objective,
        boolean active
) {
}
