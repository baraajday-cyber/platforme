package com.unigate.communication.service;

import com.unigate.communication.common.exception.CommunicationBusinessException;
import com.unigate.communication.common.exception.CommunicationNotFoundException;
import com.unigate.communication.domain.entity.Skill;
import com.unigate.communication.domain.enums.SkillCategory;
import com.unigate.communication.dto.skill.SkillRequestDto;
import com.unigate.communication.dto.skill.SkillResponse;
import com.unigate.communication.mapper.CommunicationMapper;
import com.unigate.communication.repository.SkillRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.Normalizer;
import java.util.List;
import java.util.Locale;

@Service
@RequiredArgsConstructor
public class SkillCatalogService {

    private final SkillRepository skillRepository;
    private final CommunicationMapper mapper;

    @Transactional
    public SkillResponse create(SkillRequestDto request) {
        String normalizedName = normalize(request.name());
        skillRepository.findByNormalizedName(normalizedName).ifPresent(existing -> {
            throw new CommunicationBusinessException("Cette competence existe deja: " + existing.getName());
        });
        Skill skill = Skill.builder()
                .name(request.name().trim())
                .normalizedName(normalizedName)
                .category(request.category())
                .description(request.description())
                .academicCourseId(request.academicCourseId())
                .department(request.department())
                .active(request.active() == null || request.active())
                .build();
        return mapper.toResponse(skillRepository.save(skill));
    }

    @Transactional
    public SkillResponse update(Long id, SkillRequestDto request) {
        Skill skill = skillRepository.findById(id)
                .orElseThrow(() -> new CommunicationNotFoundException("Competence introuvable: " + id));
        String normalizedName = normalize(request.name());
        skillRepository.findByNormalizedName(normalizedName)
                .filter(other -> !other.getId().equals(id))
                .ifPresent(other -> {
                    throw new CommunicationBusinessException("Une autre competence porte deja ce nom: " + other.getName());
                });
        skill.setName(request.name().trim());
        skill.setNormalizedName(normalizedName);
        skill.setCategory(request.category());
        skill.setDescription(request.description());
        skill.setAcademicCourseId(request.academicCourseId());
        skill.setDepartment(request.department());
        skill.setActive(request.active() == null || request.active());
        return mapper.toResponse(skill);
    }

    @Transactional(readOnly = true)
    public List<SkillResponse> search(String query, SkillCategory category) {
        List<Skill> skills;
        if (category != null) {
            skills = skillRepository.findByCategoryAndActiveTrueOrderByNameAsc(category);
        } else if (query != null && !query.isBlank()) {
            skills = skillRepository.findByNameContainingIgnoreCaseAndActiveTrueOrderByNameAsc(query.trim());
        } else {
            skills = skillRepository.findByActiveTrueOrderByNameAsc();
        }
        return skills.stream().map(mapper::toResponse).toList();
    }

    @Transactional(readOnly = true)
    public Skill getRequired(Long skillId) {
        return skillRepository.findById(skillId)
                .orElseThrow(() -> new CommunicationNotFoundException("Competence introuvable: " + skillId));
    }

    public String normalize(String value) {
        String text = Normalizer.normalize(value == null ? "" : value, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return text.toLowerCase(Locale.ROOT).trim().replaceAll("\\s+", " ");
    }
}
