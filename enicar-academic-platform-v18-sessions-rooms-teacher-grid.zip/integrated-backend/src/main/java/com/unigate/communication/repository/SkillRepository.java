package com.unigate.communication.repository;

import com.unigate.communication.domain.entity.Skill;
import com.unigate.communication.domain.enums.SkillCategory;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface SkillRepository extends JpaRepository<Skill, Long> {
    Optional<Skill> findByNormalizedName(String normalizedName);
    List<Skill> findByActiveTrueOrderByNameAsc();
    List<Skill> findByCategoryAndActiveTrueOrderByNameAsc(SkillCategory category);
    List<Skill> findByNameContainingIgnoreCaseAndActiveTrueOrderByNameAsc(String query);
}
