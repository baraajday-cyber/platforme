package com.unigate.communication.event;

import java.time.Instant;

public record DocumentReviewEvent(
        Long studentId,
        Long documentId,
        String documentType,
        String status,
        String reviewerComment,
        Instant occurredAt
) {
}
