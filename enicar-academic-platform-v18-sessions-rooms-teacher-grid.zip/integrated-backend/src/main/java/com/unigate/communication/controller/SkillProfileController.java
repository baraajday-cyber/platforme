package com.unigate.communication.controller;

import com.unigate.academic.security.CurrentUserService;
import com.unigate.communication.dto.skill.SkillNeedRequest;
import com.unigate.communication.dto.skill.SkillNeedResponse;
import com.unigate.communication.dto.skill.SkillOfferRequest;
import com.unigate.communication.dto.skill.SkillOfferResponse;
import com.unigate.communication.dto.skill.SkillProfileResponse;
import com.unigate.communication.service.SkillProfileService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/student/skill-swap/profile")
@PreAuthorize("hasRole('STUDENT')")
@Tag(name = "Skill profile", description = "Offres et demandes de competences d'un etudiant")
public class SkillProfileController {

    private final SkillProfileService profileService;
    private final CurrentUserService currentUserService;

    @GetMapping
    public SkillProfileResponse profile(@RequestParam(required = false) Long studentId) {
        return profileService.profile(currentUserService.resolveStudentId(studentId));
    }

    @PostMapping("/offers")
    @ResponseStatus(HttpStatus.CREATED)
    public SkillOfferResponse addOffer(@RequestParam(required = false) Long studentId, @Valid @RequestBody SkillOfferRequest request) {
        return profileService.addOffer(currentUserService.resolveStudentId(studentId), request);
    }

    @PostMapping("/needs")
    @ResponseStatus(HttpStatus.CREATED)
    public SkillNeedResponse addNeed(@RequestParam(required = false) Long studentId, @Valid @RequestBody SkillNeedRequest request) {
        return profileService.addNeed(currentUserService.resolveStudentId(studentId), request);
    }

    @DeleteMapping("/offers/{offerId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deactivateOffer(@RequestParam(required = false) Long studentId, @PathVariable Long offerId) {
        profileService.deactivateOffer(currentUserService.resolveStudentId(studentId), offerId);
    }

    @DeleteMapping("/needs/{needId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deactivateNeed(@RequestParam(required = false) Long studentId, @PathVariable Long needId) {
        profileService.deactivateNeed(currentUserService.resolveStudentId(studentId), needId);
    }
}
