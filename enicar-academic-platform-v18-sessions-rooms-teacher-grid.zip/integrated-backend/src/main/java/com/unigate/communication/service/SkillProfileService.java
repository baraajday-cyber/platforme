package com.unigate.communication.service;

import com.unigate.communication.common.exception.CommunicationNotFoundException;
import com.unigate.communication.domain.entity.Skill;
import com.unigate.communication.domain.entity.SkillLearningRequest;
import com.unigate.communication.domain.entity.SkillOffer;
import com.unigate.communication.dto.skill.SkillNeedRequest;
import com.unigate.communication.dto.skill.SkillNeedResponse;
import com.unigate.communication.dto.skill.SkillOfferRequest;
import com.unigate.communication.dto.skill.SkillOfferResponse;
import com.unigate.communication.dto.skill.SkillProfileResponse;
import com.unigate.communication.mapper.CommunicationMapper;
import com.unigate.communication.repository.SkillLearningRequestRepository;
import com.unigate.communication.repository.SkillOfferRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;

@Service
@RequiredArgsConstructor
public class SkillProfileService {

    private final SkillCatalogService skillCatalogService;
    private final SkillOfferRepository offerRepository;
    private final SkillLearningRequestRepository requestRepository;
    private final CommunicationMapper mapper;

    @Transactional
    public SkillOfferResponse addOffer(Long studentId, SkillOfferRequest request) {
        Skill skill = skillCatalogService.getRequired(request.skillId());
        SkillOffer offer = offerRepository.findByStudentIdAndSkillId(studentId, request.skillId())
                .orElseGet(() -> SkillOffer.builder().studentId(studentId).skill(skill).build());
        offer.setSkill(skill);
        offer.setLevel(request.level());
        offer.setDescription(request.description());
        offer.setActive(true);
        return mapper.toResponse(offerRepository.save(offer));
    }

    @Transactional
    public SkillNeedResponse addNeed(Long studentId, SkillNeedRequest request) {
        Skill skill = skillCatalogService.getRequired(request.skillId());
        SkillLearningRequest need = requestRepository.findByStudentIdAndSkillId(studentId, request.skillId())
                .orElseGet(() -> SkillLearningRequest.builder().studentId(studentId).skill(skill).build());
        need.setSkill(skill);
        need.setTargetLevel(request.targetLevel());
        need.setObjective(request.objective());
        need.setActive(true);
        return mapper.toResponse(requestRepository.save(need));
    }

    @Transactional
    public void deactivateOffer(Long studentId, Long offerId) {
        SkillOffer offer = offerRepository.findById(offerId)
                .orElseThrow(() -> new CommunicationNotFoundException("Offre introuvable: " + offerId));
        if (!offer.getStudentId().equals(studentId)) {
            throw new CommunicationNotFoundException("Offre introuvable pour cet etudiant.");
        }
        offer.setActive(false);
    }

    @Transactional
    public void deactivateNeed(Long studentId, Long needId) {
        SkillLearningRequest need = requestRepository.findById(needId)
                .orElseThrow(() -> new CommunicationNotFoundException("Demande introuvable: " + needId));
        if (!need.getStudentId().equals(studentId)) {
            throw new CommunicationNotFoundException("Demande introuvable pour cet etudiant.");
        }
        need.setActive(false);
    }

    @Transactional(readOnly = true)
    public SkillProfileResponse profile(Long studentId) {
        var offers = offerRepository.findByStudentIdAndActiveTrue(studentId).stream()
                .sorted(Comparator.comparing(o -> o.getSkill().getName()))
                .map(mapper::toResponse)
                .toList();
        var needs = requestRepository.findByStudentIdAndActiveTrue(studentId).stream()
                .sorted(Comparator.comparing(n -> n.getSkill().getName()))
                .map(mapper::toResponse)
                .toList();
        return new SkillProfileResponse(studentId, offers, needs);
    }
}
