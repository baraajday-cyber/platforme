package com.unigate.communication.config;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import org.springframework.context.annotation.Configuration;

@Configuration
@OpenAPIDefinition(
        info = @Info(
                title = "UniGate - Modules Academique, Communication et Skill Swap API",
                version = "1.3.0",
                description = "Endpoints Membre 2 et Membre 3 : emploi du temps, notes, notifications temps reel, preferences, Skill Swap et matching algorithmique. Auth locale: student/student, admin/admin, demo/demo."
        ),
        security = @SecurityRequirement(name = "basicAuth")
)
@SecurityScheme(
        name = "basicAuth",
        type = SecuritySchemeType.HTTP,
        scheme = "basic"
)
public class CommunicationOpenApiConfig {
}
