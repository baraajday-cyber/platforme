package com.unigate.communication.event;

import java.time.Instant;

public record RegistrationStatusChangedEvent(
        Long studentId,
        String previousStatus,
        String newStatus,
        String message,
        Instant occurredAt
) {
}
