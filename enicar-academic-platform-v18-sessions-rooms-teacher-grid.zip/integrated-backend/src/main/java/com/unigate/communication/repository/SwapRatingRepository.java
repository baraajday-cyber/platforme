package com.unigate.communication.repository;

import com.unigate.communication.domain.entity.SwapRating;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface SwapRatingRepository extends JpaRepository<SwapRating, Long> {
    List<SwapRating> findBySwapIdOrderByCreatedAtDesc(Long swapId);
    boolean existsBySwapIdAndRaterIdAndRatedId(Long swapId, Long raterId, Long ratedId);

    @Query("select coalesce(avg(r.score), 0.0) from SwapRating r where r.ratedId = :studentId")
    Double averageScoreForStudent(@Param("studentId") Long studentId);
}
