package com.unigate.communication.dto.skill;

import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.Instant;

public record SkillSwapScheduleRequest(
        @NotNull @FutureOrPresent Instant scheduledAt,
        @Size(max = 160) String location
) {
}
