package com.unigate.communication.controller;

import com.unigate.communication.dto.notification.WebSocketHandshakeResponse;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.annotation.SendToUser;
import org.springframework.stereotype.Controller;

import java.time.Instant;

@Controller
public class NotificationWebSocketController {

    @MessageMapping("/notifications/hello")
    @SendToUser("/queue/notifications-handshake")
    public WebSocketHandshakeResponse hello(@Payload Long studentId) {
        return new WebSocketHandshakeResponse(studentId, "CONNECTED", Instant.now());
    }
}
