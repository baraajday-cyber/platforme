package com.unigate.communication.dto.skill;

import java.util.List;

public record SkillMatchResponse(
        Long candidateStudentId,
        String candidateDepartment,
        SkillResponse candidateTeachesSkill,
        SkillResponse candidateWantsSkill,
        ScoreBreakdownResponse score,
        List<CommonAvailabilityResponse.Window> commonAvailability,
        String recommendation
) {
}
