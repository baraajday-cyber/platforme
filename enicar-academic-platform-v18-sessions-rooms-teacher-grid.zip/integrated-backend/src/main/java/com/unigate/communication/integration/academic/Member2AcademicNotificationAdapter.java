package com.unigate.communication.integration.academic;

import com.unigate.academic.domain.entity.TimetableSlot;
import com.unigate.academic.dto.grade.StudentResultsResponse;
import com.unigate.academic.integration.AcademicNotificationPort;
import com.unigate.communication.domain.enums.NotificationPriority;
import com.unigate.communication.domain.enums.NotificationType;
import com.unigate.communication.service.AcademicBridgeService;
import com.unigate.communication.service.NotificationCommand;
import com.unigate.communication.service.NotificationService;
import com.unigate.communication.websocket.WebSocketPublisher;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.util.LinkedHashMap;
import java.util.Map;

@Component
@Primary
@RequiredArgsConstructor
public class Member2AcademicNotificationAdapter implements AcademicNotificationPort {

    private final AcademicBridgeService academicBridgeService;
    private final NotificationService notificationService;
    private final WebSocketPublisher webSocketPublisher;

    @Override
    public void notifyTimetableChanged(Long classGroupId, TimetableSlot slot, String action) {
        Map<String, Object> payload = timetablePayload(classGroupId, slot, action);
        webSocketPublisher.sendToClassGroup(classGroupId, "/timetable", payload);
        notificationService.notifyStudents(academicBridgeService.studentIdsInClassGroup(classGroupId), NotificationCommand.builder()
                .type(NotificationType.TIMETABLE_CHANGED)
                .priority(NotificationPriority.HIGH)
                .title("Emploi du temps modifie")
                .message(timetableMessage(slot, action))
                .payload(payload)
                .linkUrl("/timetable")
                .build());
    }

    @Override
    public void notifyGradeUpdated(Long studentId, StudentResultsResponse results) {
        webSocketPublisher.sendToStudent(studentId, "/queue/grades", results);
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("department", results.semester() == null ? "" : results.semester().department());
        payload.put("semesterAverage", results.semester() == null || results.semester().semesterAverage() == null ? "" : results.semester().semesterAverage());
        payload.put("totalCredits", results.semester() == null || results.semester().totalCredits() == null ? 0 : results.semester().totalCredits());
        notificationService.notifyStudent(NotificationCommand.builder()
                .recipientId(studentId)
                .type(NotificationType.GRADE_UPDATED)
                .priority(NotificationPriority.NORMAL)
                .title("Moyennes mises a jour")
                .message("Vos notes, moyennes, credits et notes necessaires ont ete recalcules.")
                .payload(payload)
                .linkUrl("/grades")
                .build());
    }

    private Map<String, Object> timetablePayload(Long classGroupId, TimetableSlot slot, String action) {
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("classGroupId", classGroupId);
        payload.put("slotId", slot.getId());
        payload.put("action", action);
        payload.put("dayOfWeek", slot.getDayOfWeek() == null ? null : slot.getDayOfWeek().name());
        payload.put("startTime", slot.getStartTime() == null ? null : slot.getStartTime().toString());
        payload.put("endTime", slot.getEndTime() == null ? null : slot.getEndTime().toString());
        payload.put("room", slot.getRoom());
        payload.put("professorId", slot.getProfessorId());
        payload.put("professorName", slot.getProfessorName());
        payload.put("courseId", slot.getCourse() == null ? null : slot.getCourse().getId());
        payload.put("courseName", slot.getCourse() == null ? null : slot.getCourse().getName());
        payload.put("status", slot.getStatus() == null ? null : slot.getStatus().name());
        payload.put("changeReason", slot.getChangeReason());
        return payload;
    }

    private String timetableMessage(TimetableSlot slot, String action) {
        String courseName = slot.getCourse() == null ? "un cours" : slot.getCourse().getName();
        String day = slot.getDayOfWeek() == null ? "" : slot.getDayOfWeek().name();
        String time = slot.getStartTime() == null ? "" : slot.getStartTime() + "-" + slot.getEndTime();
        return switch (action == null ? "UPDATED" : action) {
            case "CREATED" -> "Nouveau creneau ajoute: " + courseName + " " + day + " " + time + ".";
            case "CANCELLED" -> "Creneau annule: " + courseName + " " + day + " " + time + ".";
            case "DELETED" -> "Creneau supprime: " + courseName + " " + day + " " + time + ".";
            case "DUPLICATED" -> "Creneau duplique dans votre emploi du temps: " + courseName + ".";
            default -> "Creneau modifie: " + courseName + " " + day + " " + time + ".";
        };
    }
}
