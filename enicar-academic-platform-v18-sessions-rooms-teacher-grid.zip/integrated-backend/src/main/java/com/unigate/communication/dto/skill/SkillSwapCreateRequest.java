package com.unigate.communication.dto.skill;

import com.unigate.academic.domain.enums.Semester;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record SkillSwapCreateRequest(
        @NotNull Long receiverId,
        @NotNull Long requesterLearnsSkillId,
        Long receiverLearnsSkillId,
        @Size(max = 1000) String message,
        @NotNull Integer year,
        @NotNull Semester semester
) {
}
