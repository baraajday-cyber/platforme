package com.unigate.communication.common.exception;

public class CommunicationNotFoundException extends RuntimeException {
    public CommunicationNotFoundException(String message) {
        super(message);
    }
}
