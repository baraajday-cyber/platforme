package com.unigate.communication.dto.skill;

import java.time.DayOfWeek;
import java.time.LocalTime;
import java.util.List;

public record CommonAvailabilityResponse(
        Long student1Id,
        Long student2Id,
        int totalCommonMinutes,
        List<Window> windows
) {
    public record Window(DayOfWeek dayOfWeek, LocalTime startTime, LocalTime endTime, int minutes) {
    }
}
