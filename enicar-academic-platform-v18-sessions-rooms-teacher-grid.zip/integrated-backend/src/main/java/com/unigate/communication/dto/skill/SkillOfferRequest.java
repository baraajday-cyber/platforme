package com.unigate.communication.dto.skill;

import com.unigate.communication.domain.enums.SkillLevel;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record SkillOfferRequest(
        @NotNull Long skillId,
        @NotNull SkillLevel level,
        @Size(max = 700) String description
) {
}
