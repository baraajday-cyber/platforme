package com.unigate.communication.service;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@Primary
public class NoopStudentContactPort implements StudentContactPort {
    @Override
    public Optional<String> emailForStudent(Long studentId) {
        return Optional.empty();
    }

    @Override
    public Optional<String> displayNameForStudent(Long studentId) {
        return Optional.of("Etudiant #" + studentId);
    }
}
