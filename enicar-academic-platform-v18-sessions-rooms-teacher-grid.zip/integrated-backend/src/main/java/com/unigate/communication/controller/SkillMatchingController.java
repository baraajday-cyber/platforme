package com.unigate.communication.controller;

import com.unigate.academic.domain.enums.Semester;
import com.unigate.academic.security.CurrentUserService;
import com.unigate.communication.dto.skill.CommonAvailabilityResponse;
import com.unigate.communication.dto.skill.SkillMatchResponse;
import com.unigate.communication.service.SkillMatchingService;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/student/skill-swap")
@PreAuthorize("hasRole('STUDENT')")
@Tag(name = "Skill matching", description = "Matching pondere: skills, disponibilites, notes, ratings, departement")
public class SkillMatchingController {

    private final SkillMatchingService matchingService;
    private final CurrentUserService currentUserService;

    @GetMapping("/matches")
    public List<SkillMatchResponse> matches(
            @RequestParam(required = false) Long studentId,
            @RequestParam @NotNull Integer year,
            @RequestParam @NotNull Semester semester,
            @RequestParam(defaultValue = "10") int limit
    ) {
        Long resolvedStudentId = currentUserService.resolveStudentId(studentId);
        return matchingService.browseMatches(resolvedStudentId, year, semester, limit);
    }

    @GetMapping("/availability/common")
    public CommonAvailabilityResponse commonAvailability(
            @RequestParam(required = false) Long student1Id,
            @RequestParam @NotNull Long student2Id,
            @RequestParam @NotNull Integer year,
            @RequestParam @NotNull Semester semester
    ) {
        Long resolvedStudent1Id = currentUserService.resolveStudentId(student1Id);
        return matchingService.commonAvailability(resolvedStudent1Id, student2Id, year, semester);
    }
}
