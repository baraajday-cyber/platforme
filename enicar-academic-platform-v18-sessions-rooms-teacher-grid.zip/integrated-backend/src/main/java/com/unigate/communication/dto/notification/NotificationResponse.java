package com.unigate.communication.dto.notification;

import com.unigate.communication.domain.enums.NotificationPriority;
import com.unigate.communication.domain.enums.NotificationType;

import java.time.Instant;

public record NotificationResponse(
        Long id,
        Long recipientId,
        Long senderId,
        NotificationType type,
        NotificationPriority priority,
        String title,
        String message,
        String payloadJson,
        String linkUrl,
        boolean read,
        Instant deliveredAt,
        Instant emailSentAt,
        Instant readAt,
        Instant createdAt
) {
}
