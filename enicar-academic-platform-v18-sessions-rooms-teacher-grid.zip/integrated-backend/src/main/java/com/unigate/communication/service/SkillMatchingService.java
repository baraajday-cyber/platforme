package com.unigate.communication.service;

import com.unigate.academic.domain.enums.Semester;
import com.unigate.communication.domain.entity.Skill;
import com.unigate.communication.domain.entity.SkillLearningRequest;
import com.unigate.communication.domain.entity.SkillOffer;
import com.unigate.communication.dto.skill.CommonAvailabilityResponse;
import com.unigate.communication.dto.skill.ScoreBreakdownResponse;
import com.unigate.communication.dto.skill.SkillMatchResponse;
import com.unigate.communication.mapper.CommunicationMapper;
import com.unigate.communication.repository.SkillLearningRequestRepository;
import com.unigate.communication.repository.SkillOfferRepository;
import com.unigate.communication.repository.SwapRatingRepository;
import com.unigate.communication.service.matching.MatchInput;
import com.unigate.communication.service.matching.MatchScore;
import com.unigate.communication.service.matching.SkillMatchingAlgorithm;
import com.unigate.communication.service.matching.TimeWindow;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class SkillMatchingService {

    private final AcademicBridgeService academicBridgeService;
    private final SkillOfferRepository offerRepository;
    private final SkillLearningRequestRepository requestRepository;
    private final SwapRatingRepository ratingRepository;
    private final SkillMatchingAlgorithm algorithm;
    private final CommunicationMapper mapper;

    @Value("${unigate.communication.availability.minimum-common-minutes:60}")
    private int minimumCommonMinutes;

    @Transactional(readOnly = true)
    public List<SkillMatchResponse> browseMatches(Long studentId, Integer year, Semester semester, int limit) {
        academicBridgeService.assertSkillSwapAccess(studentId, year, semester);

        List<SkillLearningRequest> myNeeds = requestRepository.findByStudentIdAndActiveTrue(studentId);
        Set<Long> myOfferSkillIds = offerRepository.findByStudentIdAndActiveTrue(studentId).stream()
                .map(offer -> offer.getSkill().getId())
                .collect(java.util.stream.Collectors.toSet());
        String myDepartment = academicBridgeService.departmentForStudent(studentId, year, semester).orElse(null);

        return myNeeds.stream()
                .flatMap(need -> offerRepository.findBySkillIdAndActiveTrue(need.getSkill().getId()).stream()
                        .filter(offer -> !offer.getStudentId().equals(studentId))
                        .map(offer -> toMatch(studentId, offer, need.getSkill(), myOfferSkillIds, myDepartment, year, semester)))
                .filter(match -> match.score().commonAvailabilityMinutes() >= minimumCommonMinutes || match.score().totalScore().compareTo(BigDecimal.valueOf(60)) >= 0)
                .sorted(Comparator.comparing((SkillMatchResponse m) -> m.score().totalScore()).reversed())
                .limit(Math.max(1, limit))
                .toList();
    }

    @Transactional(readOnly = true)
    public CommonAvailabilityResponse commonAvailability(Long student1Id, Long student2Id, Integer year, Semester semester) {
        List<TimeWindow> common = academicBridgeService.commonAvailability(student1Id, student2Id, year, semester);
        return new CommonAvailabilityResponse(student1Id, student2Id, academicBridgeService.totalCommonMinutes(common), toWindows(common));
    }

    private SkillMatchResponse toMatch(
            Long studentId,
            SkillOffer candidateOffer,
            Skill requestedSkill,
            Set<Long> myOfferSkillIds,
            String myDepartment,
            Integer year,
            Semester semester
    ) {
        Long candidateId = candidateOffer.getStudentId();
        List<TimeWindow> commonWindows = academicBridgeService.commonAvailability(studentId, candidateId, year, semester);
        int commonMinutes = academicBridgeService.totalCommonMinutes(commonWindows);
        BigDecimal tutorGrade = academicBridgeService.gradeForSkill(candidateId, candidateOffer.getSkill(), year, semester).orElse(null);
        Double rating = ratingRepository.averageScoreForStudent(candidateId);
        BigDecimal averageRating = rating == null ? null : BigDecimal.valueOf(rating);
        String candidateDepartment = academicBridgeService.departmentForStudent(candidateId, year, semester).orElse(null);

        Skill candidateWantsSkill = requestRepository.findByStudentIdAndActiveTrue(candidateId).stream()
                .map(SkillLearningRequest::getSkill)
                .filter(skill -> myOfferSkillIds.contains(skill.getId()))
                .findFirst()
                .orElse(null);

        boolean sameDepartment = myDepartment != null && myDepartment.equalsIgnoreCase(candidateDepartment == null ? "" : candidateDepartment);
        boolean mutual = candidateWantsSkill != null;
        MatchScore score = algorithm.score(new MatchInput(true, mutual, commonMinutes, tutorGrade, averageRating, sameDepartment));

        return new SkillMatchResponse(
                candidateId,
                candidateDepartment,
                mapper.toResponse(candidateOffer.getSkill()),
                mapper.toResponse(candidateWantsSkill),
                new ScoreBreakdownResponse(
                        score.totalScore(),
                        score.skillComplementarityScore(),
                        score.availabilityScore(),
                        score.tutorGradeScore(),
                        score.historyScore(),
                        score.departmentScore(),
                        commonMinutes,
                        tutorGrade,
                        averageRating,
                        sameDepartment,
                        mutual
                ),
                toWindows(commonWindows),
                recommendation(score.totalScore(), mutual, commonMinutes)
        );
    }

    private List<CommonAvailabilityResponse.Window> toWindows(List<TimeWindow> windows) {
        return windows.stream()
                .map(window -> new CommonAvailabilityResponse.Window(window.dayOfWeek(), window.startTime(), window.endTime(), window.minutes()))
                .toList();
    }

    private String recommendation(BigDecimal totalScore, boolean mutual, int commonMinutes) {
        if (totalScore.compareTo(BigDecimal.valueOf(80)) >= 0 && mutual) {
            return "Excellent match: echange reciproque, bonne disponibilite et profil fiable.";
        }
        if (totalScore.compareTo(BigDecimal.valueOf(65)) >= 0) {
            return "Bon match: compatible pour une session Skill Swap.";
        }
        if (commonMinutes < minimumCommonMinutes) {
            return "Match possible, mais disponibilite commune limitee.";
        }
        return "Match moyen: a verifier selon vos objectifs.";
    }
}
