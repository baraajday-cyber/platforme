package com.unigate.communication.domain.enums;

public enum SkillSwapStatus {
    PENDING,
    ACCEPTED,
    REJECTED,
    SCHEDULED,
    COMPLETED,
    CANCELLED
}
