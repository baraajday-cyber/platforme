package com.unigate.communication.dto.skill;

import java.time.Instant;

public record SwapRatingResponse(
        Long id,
        Long swapId,
        Long raterId,
        Long ratedId,
        int score,
        String comment,
        Instant createdAt
) {
}
