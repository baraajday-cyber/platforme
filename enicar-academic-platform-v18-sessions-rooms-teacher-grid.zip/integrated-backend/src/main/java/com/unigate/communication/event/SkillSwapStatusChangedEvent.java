package com.unigate.communication.event;

import com.unigate.communication.domain.enums.SkillSwapStatus;

import java.time.Instant;

public record SkillSwapStatusChangedEvent(
        Long swapId,
        Long requesterId,
        Long receiverId,
        SkillSwapStatus status,
        Instant occurredAt
) {
}
