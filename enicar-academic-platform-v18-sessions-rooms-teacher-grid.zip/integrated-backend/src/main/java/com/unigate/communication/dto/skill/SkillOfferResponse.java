package com.unigate.communication.dto.skill;

import com.unigate.communication.domain.enums.SkillLevel;

public record SkillOfferResponse(
        Long id,
        Long studentId,
        SkillResponse skill,
        SkillLevel level,
        String description,
        boolean active
) {
}
