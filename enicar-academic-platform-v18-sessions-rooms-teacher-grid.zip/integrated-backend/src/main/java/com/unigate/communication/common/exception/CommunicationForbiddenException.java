package com.unigate.communication.common.exception;

public class CommunicationForbiddenException extends RuntimeException {
    public CommunicationForbiddenException(String message) {
        super(message);
    }
}
