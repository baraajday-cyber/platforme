package com.unigate.communication.dto.skill;

import java.math.BigDecimal;

public record ScoreBreakdownResponse(
        BigDecimal totalScore,
        BigDecimal skillComplementarityScore,
        BigDecimal availabilityScore,
        BigDecimal tutorGradeScore,
        BigDecimal historyScore,
        BigDecimal departmentScore,
        int commonAvailabilityMinutes,
        BigDecimal tutorGrade,
        BigDecimal averageRating,
        boolean sameDepartment,
        boolean mutualExchange
) {
}
