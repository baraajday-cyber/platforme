package com.unigate.communication.dto.skill;

import com.unigate.communication.domain.enums.SkillCategory;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record SkillRequestDto(
        @NotBlank @Size(max = 120) String name,
        @NotNull SkillCategory category,
        @Size(max = 500) String description,
        Long academicCourseId,
        @Size(max = 80) String department,
        Boolean active
) {
}
