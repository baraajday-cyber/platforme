package com.unigate.communication.service;

import com.unigate.academic.domain.entity.StudentGrade;
import com.unigate.academic.domain.entity.TimetableSlot;
import com.unigate.academic.domain.enums.Semester;
import com.unigate.academic.domain.enums.SlotStatus;
import com.unigate.academic.integration.StudentAccessPort;
import com.unigate.academic.repository.StudentClassAssignmentRepository;
import com.unigate.academic.repository.StudentGradeRepository;
import com.unigate.academic.repository.TimetableSlotRepository;
import com.unigate.communication.common.exception.CommunicationBusinessException;
import com.unigate.communication.domain.entity.Skill;
import com.unigate.communication.service.matching.AvailabilityService;
import com.unigate.communication.service.matching.TimeWindow;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.text.Normalizer;
import java.time.LocalTime;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class AcademicBridgeService {

    private final StudentAccessPort studentAccessPort;
    private final StudentClassAssignmentRepository assignmentRepository;
    private final TimetableSlotRepository timetableSlotRepository;
    private final StudentGradeRepository studentGradeRepository;
    private final AvailabilityService availabilityService;

    @Value("${unigate.communication.availability.day-start:08:00}")
    private String dayStart;

    @Value("${unigate.communication.availability.day-end:18:00}")
    private String dayEnd;

    @Transactional(readOnly = true)
    public void assertSkillSwapAccess(Long studentId, Integer year, Semester semester) {
        studentAccessPort.assertStudentIsEnrolled(studentId);
        boolean hasTimetable = assignmentRepository.findByStudentIdAndYearAndSemesterAndActiveTrue(studentId, year, semester)
                .map(a -> !timetableSlotRepository.findByClassGroupIdAndStatusOrderByDayOfWeekAscStartTimeAsc(a.getClassGroup().getId(), SlotStatus.ACTIVE).isEmpty())
                .orElse(false);
        if (!hasTimetable) {
            throw new CommunicationBusinessException("Skill Swap exige une inscription approuvee et un emploi du temps attribue.");
        }
    }

    @Transactional(readOnly = true)
    public List<Long> studentIdsInClassGroup(Long classGroupId) {
        return assignmentRepository.findByClassGroupIdAndActiveTrue(classGroupId).stream()
                .map(a -> a.getStudentId())
                .distinct()
                .toList();
    }

    @Transactional(readOnly = true)
    public Optional<String> departmentForStudent(Long studentId, Integer year, Semester semester) {
        return assignmentRepository.findByStudentIdAndYearAndSemesterAndActiveTrue(studentId, year, semester)
                .map(a -> a.getClassGroup().getDepartment())
                .or(() -> studentGradeRepository.findByStudentIdAndYearAndSemester(studentId, year, semester)
                        .stream()
                        .findFirst()
                        .map(StudentGrade::getDepartment));
    }

    @Transactional(readOnly = true)
    public List<TimeWindow> busyWindows(Long studentId, Integer year, Semester semester) {
        return assignmentRepository.findByStudentIdAndYearAndSemesterAndActiveTrue(studentId, year, semester)
                .map(a -> timetableSlotRepository.findByClassGroupIdAndStatusOrderByDayOfWeekAscStartTimeAsc(a.getClassGroup().getId(), SlotStatus.ACTIVE))
                .orElse(List.of())
                .stream()
                .map(this::toWindow)
                .toList();
    }

    @Transactional(readOnly = true)
    public List<TimeWindow> commonAvailability(Long student1Id, Long student2Id, Integer year, Semester semester) {
        return availabilityService.commonFreeWindows(
                busyWindows(student1Id, year, semester),
                busyWindows(student2Id, year, semester),
                LocalTime.parse(dayStart),
                LocalTime.parse(dayEnd)
        );
    }

    @Transactional(readOnly = true)
    public Optional<BigDecimal> gradeForSkill(Long studentId, Skill skill, Integer year, Semester semester) {
        if (skill.getAcademicCourseId() != null) {
            return studentGradeRepository.findByStudentIdAndYearAndSemesterAndSubjectId(studentId, year, semester, skill.getAcademicCourseId())
                    .map(StudentGrade::getSubjectAverage);
        }
        String normalizedSkill = normalize(skill.getName());
        return studentGradeRepository.findByStudentIdAndYearAndSemester(studentId, year, semester).stream()
                .filter(grade -> grade.getSubject() != null)
                .filter(grade -> normalize(grade.getSubject().getName()).contains(normalizedSkill)
                        || normalizedSkill.contains(normalize(grade.getSubject().getName())))
                .map(StudentGrade::getSubjectAverage)
                .filter(avg -> avg != null)
                .findFirst();
    }

    public int totalCommonMinutes(List<TimeWindow> commonWindows) {
        return availabilityService.totalMinutes(commonWindows);
    }

    private TimeWindow toWindow(TimetableSlot slot) {
        return new TimeWindow(slot.getDayOfWeek(), slot.getStartTime(), slot.getEndTime());
    }

    private String normalize(String value) {
        if (value == null) {
            return "";
        }
        String text = Normalizer.normalize(value, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return text.toLowerCase(Locale.ROOT).trim();
    }
}
