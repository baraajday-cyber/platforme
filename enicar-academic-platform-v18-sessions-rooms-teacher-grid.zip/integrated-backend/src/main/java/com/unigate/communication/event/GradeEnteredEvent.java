package com.unigate.communication.event;

import com.unigate.academic.domain.enums.Semester;

import java.time.Instant;

public record GradeEnteredEvent(
        Long studentId,
        String department,
        Integer year,
        Semester semester,
        Long subjectId,
        Instant occurredAt
) {
}
