package com.unigate.communication.dto.skill;

import com.unigate.communication.domain.enums.SkillSwapStatus;

import java.time.Instant;
import java.util.List;

public record SkillSwapResponse(
        Long id,
        Long requesterId,
        Long receiverId,
        SkillResponse requesterLearnsSkill,
        SkillResponse receiverLearnsSkill,
        SkillSwapStatus status,
        Instant scheduledAt,
        String location,
        String message,
        String decisionReason,
        Instant decidedAt,
        Instant completedAt,
        List<SwapRatingResponse> ratings,
        Instant createdAt
) {
}
