package com.unigate.communication.dto.notification;

public record NotificationPreferenceRequest(
        boolean websocketEnabled,
        boolean emailEnabled,
        boolean timetableUpdates,
        boolean gradeUpdates,
        boolean swapUpdates,
        boolean registrationUpdates,
        boolean weeklyDigest
) {
}
