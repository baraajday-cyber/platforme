@echo off
setlocal
cd /d "%~dp0integrated-backend"
if exist "C:\Program Files\apache-maven-3.9.15\bin\mvn.cmd" (
  "C:\Program Files\apache-maven-3.9.15\bin\mvn.cmd" spring-boot:run
) else (
  mvn spring-boot:run
)
endlocal
