# ENI Carthage Academic Platform V14

Plateforme académique ENI Carthage : gestion des étudiants, enseignants, administration, emplois du temps, notes, moyennes automatiques et notifications.

Cette version corrige les problèmes rencontrés lors des tests :

- `npm start` ne bloque plus si le backend n'est pas encore lancé ;
- health check mail désactivé, donc plus d'erreur bloquante liée à `localhost:1025` ;
- scripts `.cmd` ajoutés pour éviter l'erreur PowerShell `execution policy` ;
- proxy Angular vers `127.0.0.1:8081` ;
- Angular verrouillé en version stable, sans migration forcée.

## 1. Préparer PostgreSQL

Dans pgAdmin, ouvre la base `unigate`, puis exécute une seule fois le contenu de :

```text
RESET_DATABASE.sql
```

Important : colle le contenu SQL du fichier, pas le nom `RESET_DATABASE.sql`.

## 2. Lancer le backend

Méthode recommandée Windows :

```text
START_BACKEND.cmd
```

Ou en terminal :

```powershell
cd integrated-backend
"C:\Program Files\apache-maven-3.9.15\bin\mvn.cmd" spring-boot:run
```

Attends le message :

```text
Tomcat started on port 8081
Started AcademicModuleApplication
```

## 3. Lancer le frontend

Méthode recommandée Windows :

```text
START_FRONTEND.cmd
```

Ou en terminal :

```powershell
cd frontend/angular
npm install
npm start
```

Puis ouvre :

```text
http://localhost:4200/login
```

## 4. Comptes de test

```text
admin / admin
teacher / teacher
student / student
student2 / student2
demo / demo
```

## 5. Ne pas faire

Ne lance pas :

```powershell
npm audit fix --force
```

Cette commande force Angular vers une version majeure incompatible avec la configuration du projet.
Les warnings `npm audit` ne bloquent pas l'exécution locale.

## 6. URLs utiles

```text
Frontend : http://localhost:4200/login
Backend  : http://127.0.0.1:8081
Health   : http://127.0.0.1:8081/actuator/health
Swagger  : http://127.0.0.1:8081/swagger-ui/index.html
```

## 7. Fonctionnalités incluses

- création/modification des étudiants ;
- affectation des étudiants aux 8 groupes ;
- dashboard admin avec 8 groupes et listes triées alphabétiquement ;
- emploi du temps propre à chaque étudiant selon son groupe ;
- déplacement/suppression de séance avec contrôle salle, groupe et professeur ;
- notifications aux étudiants du groupe quand l'emploi du temps change ;
- saisie des notes par admin/enseignant pour un étudiant choisi ;
- calcul backend des moyennes matière, module et semestre ;
- notification de l'étudiant quand une note est ajoutée ou modifiée ;
- accès étudiant limité à ses propres données.

## V16 - correction moyenne/credits

- La moyenne generale du semestre n'est affichee que lorsque toutes les matieres sont completes.
- Les credits des modules sont repartis pour totaliser exactement 30 credits par semestre.
- Faire un reset PostgreSQL une seule fois avant le premier lancement de V16.
