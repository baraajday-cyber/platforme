@echo off
curl -i http://127.0.0.1:8081/actuator/health
