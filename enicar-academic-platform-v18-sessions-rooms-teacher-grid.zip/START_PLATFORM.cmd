@echo off
setlocal
start "ENICar Backend" cmd /k "%~dp0START_BACKEND.cmd"
echo Attente du backend sur 8081...
timeout /t 15 /nobreak >nul
start "ENICar Frontend" cmd /k "%~dp0START_FRONTEND.cmd"
echo Ouverture de http://localhost:4200/login
start http://localhost:4200/login
endlocal
