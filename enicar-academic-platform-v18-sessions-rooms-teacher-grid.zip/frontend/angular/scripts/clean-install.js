const fs = require('fs');
const { execSync } = require('child_process');
for (const path of ['node_modules', 'package-lock.json']) {
  if (fs.existsSync(path)) fs.rmSync(path, { recursive: true, force: true });
}
execSync('npm cache verify', { stdio: 'inherit' });
execSync('npm install', { stdio: 'inherit' });
