const url = 'http://127.0.0.1:8081/actuator/health';

async function main() {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 2500);
    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(timeout);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const body = await res.json().catch(() => ({}));
    console.log(`Backend OK: ${url} (${body.status ?? 'reachable'})`);
  } catch (err) {
    console.error('\nBackend Spring Boot indisponible sur le port 8081.');
    console.error('Lance le backend depuis le dossier racine ou integrated-backend :');
    console.error('  START_BACKEND.cmd');
    console.error('ou :');
    console.error('  cd integrated-backend');
    console.error('  "C:\\Program Files\\apache-maven-3.9.15\\bin\\mvn.cmd" spring-boot:run');
    console.error('Attends le message : Tomcat started on port 8081');
    console.error('Puis relance : npm start\n');
    process.exit(1);
  }
}

main();
