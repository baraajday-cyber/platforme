import { Injectable, inject } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';
import { Client, IMessage, StompSubscription } from '@stomp/stompjs';
import { AuthService } from '../auth/auth.service';
import { NotificationItem } from './communication.models';

@Injectable({ providedIn: 'root' })
export class NotificationWebSocketService {
  private readonly auth = inject(AuthService);
  private client?: Client;
  private subscriptions: StompSubscription[] = [];
  private connectedForStudent?: number;
  private readonly connectedSubject = new BehaviorSubject(false);
  private readonly notificationsSubject = new Subject<NotificationItem>();
  private readonly errorsSubject = new Subject<string>();

  readonly connected$ = this.connectedSubject.asObservable();
  readonly notifications$ = this.notificationsSubject.asObservable();
  readonly errors$ = this.errorsSubject.asObservable();

  connect(studentId: number): void {
    if (this.client?.active && this.connectedForStudent === studentId) return;
    this.disconnect();
    this.connectedForStudent = studentId;
    const authHeader = this.auth.authorizationHeader();

    this.client = new Client({
      brokerURL: `${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.hostname || '127.0.0.1'}:8081/ws`,
      connectHeaders: authHeader ? { Authorization: authHeader } : {},
      reconnectDelay: 5000,
      heartbeatIncoming: 10000,
      heartbeatOutgoing: 10000,
      debug: () => undefined,
      onConnect: () => {
        this.connectedSubject.next(true);
        this.subscriptions = [
          this.client!.subscribe(`/topic/students/${studentId}/queue/notifications`, msg => this.pushNotification(msg)),
          this.client!.subscribe(`/topic/students/${studentId}/queue/grades`, msg => this.pushNotification(msg)),
          this.client!.subscribe(`/topic/students/${studentId}/queue/skill-swaps`, msg => this.pushNotification(msg)),
          this.client!.subscribe(`/user/queue/notifications-handshake`, () => undefined)
        ];
        this.client!.publish({ destination: '/app/notifications/hello', body: String(studentId) });
      },
      onDisconnect: () => this.connectedSubject.next(false),
      onStompError: frame => {
        this.connectedSubject.next(false);
        this.errorsSubject.next(frame.headers['message'] ?? 'Erreur STOMP');
      },
      onWebSocketClose: () => this.connectedSubject.next(false)
    });
    this.client.activate();
  }

  disconnect(): void {
    this.subscriptions.forEach(s => s.unsubscribe());
    this.subscriptions = [];
    this.connectedSubject.next(false);
    this.client?.deactivate();
  }

  private pushNotification(message: IMessage): void {
    try {
      const notification = JSON.parse(message.body) as NotificationItem;
      if (notification?.id && notification?.title) {
        this.notificationsSubject.next(notification);
      }
    } catch {
      this.errorsSubject.next('Notification WebSocket illisible.');
    }
  }
}
