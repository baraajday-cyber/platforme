import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { finalize } from 'rxjs';
import { AuthService } from '../auth/auth.service';
import { CommunicationApiService } from './communication-api.service';
import { Semester, Skill, SkillLevel, SkillMatch, SkillProfile } from './communication.models';

@Component({
  selector: 'app-skill-swap-marketplace',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <section class="card marketplace">
      <header class="market-header">
        <div><span class="badge">Skill Swap</span><h2>Marketplace</h2></div>
        <div class="filters"><input class="input" type="number" [(ngModel)]="year"><select class="select" [(ngModel)]="semester"><option value="S1">S1</option><option value="S2">S2</option><option value="S3">S3</option><option value="S4">S4</option></select><button class="btn" (click)="loadMatches()" [disabled]="loading || !profileReady()">Trouver</button></div>
      </header>

      <div class="alert danger" *ngIf="error"><span>{{ error }}</span></div>
      <div class="alert success" *ngIf="success"><span>{{ success }}</span></div>

      <section class="profile-editor">
        <article class="profile-form">
          <h3>Profil</h3>
          <div class="field"><label>Skill</label><input class="input" [(ngModel)]="query" (input)="search()" placeholder="Java, SQL, Python"></div>
          <div class="field"><label>Selection</label><select class="select" [(ngModel)]="selectedSkillId"><option [ngValue]="undefined">Choisir</option><option *ngFor="let skill of skills" [ngValue]="skill.id">{{ skill.name }}</option></select></div>
          <div class="field"><label>Niveau</label><select class="select" [(ngModel)]="level"><option value="BEGINNER">Debutant</option><option value="INTERMEDIATE">Intermediaire</option><option value="ADVANCED">Avance</option><option value="EXPERT">Expert</option></select></div>
          <div class="actions"><button class="mini" (click)="addOffer()" [disabled]="busy || !selectedSkillId">J'enseigne</button><button class="mini" (click)="addNeed()" [disabled]="busy || !selectedSkillId">Je cherche</button></div>
        </article>
        <article class="profile-list" *ngIf="profile">
          <div><strong>Offres</strong><span>{{ profile.offers.length }}</span></div>
          <p *ngIf="!profile.offers.length" class="muted">Aucune offre.</p>
          <button class="chip" *ngFor="let offer of profile.offers" (click)="removeOffer(offer.id)">{{ offer.skill.name }} ×</button>
          <div><strong>Besoins</strong><span>{{ profile.needs.length }}</span></div>
          <p *ngIf="!profile.needs.length" class="muted">Aucun besoin.</p>
          <button class="chip warning" *ngFor="let need of profile.needs" (click)="removeNeed(need.id)">{{ need.skill.name }} ×</button>
        </article>
      </section>

      <p class="empty" *ngIf="!profileReady()">Ajoute au moins une offre et un besoin.</p>

      <div class="matches" *ngIf="matches.length">
        <article *ngFor="let match of matches" class="match-card">
          <div class="score"><strong>{{ match.score.totalScore | number:'1.0-0' }}</strong><span>%</span></div>
          <div class="match-body">
            <h3>Etudiant #{{ match.candidateStudentId }} · {{ match.candidateTeachesSkill.name }}</h3>
            <p>{{ match.recommendation }}</p>
            <div class="chips"><span class="badge">{{ match.score.commonAvailabilityMinutes }} min commun</span><span class="badge success" *ngIf="match.score.mutualExchange">Reciproque</span></div>
          </div>
          <button class="btn" (click)="sendRequest(match)" [disabled]="sendingId === match.candidateStudentId">Demander</button>
        </article>
      </div>
      <p class="empty" *ngIf="profileReady() && !matches.length && !loading">Aucun match affiche.</p>
    </section>
  `,
  styles: [`
    .marketplace { padding: 1.3rem; display: grid; gap: 1rem; }
    .market-header { display: flex; justify-content: space-between; gap: 1rem; align-items: flex-start; }
    h2 { margin: .45rem 0 .25rem; font-size: 2rem; }
    h3 { margin: 0; }
    .filters { display: flex; gap: .65rem; align-items: center; }
    .profile-editor { display: grid; grid-template-columns: 360px 1fr; gap: 1rem; }
    .profile-form, .profile-list { border: 1px solid var(--line); border-radius: 22px; padding: 1rem; background: #fff; box-shadow: var(--shadow-soft); display: grid; gap: .75rem; }
    .field { display: grid; gap: .3rem; }
    .field label { color: var(--muted); font-weight: 900; font-size: .82rem; }
    .actions, .chips { display: flex; gap: .5rem; flex-wrap: wrap; }
    .mini, .chip { border: 0; border-radius: 999px; padding: .55rem .75rem; font-weight: 900; background: #e0f2fe; color: #075985; cursor: pointer; }
    .chip.warning { background: #fef3c7; color: #92400e; }
    .profile-list div { display: flex; justify-content: space-between; align-items: center; }
    .profile-list div span { background: #eef2ff; color: #1d4ed8; border-radius: 999px; padding: .25rem .55rem; font-weight: 900; }
    .matches { display: grid; gap: .8rem; }
    .match-card { display: grid; grid-template-columns: 100px 1fr auto; gap: 1rem; align-items: center; padding: 1rem; border: 1px solid var(--line); border-radius: 22px; background: linear-gradient(135deg, #fff, #f8fbff); box-shadow: var(--shadow-soft); }
    .score { height: 82px; border-radius: 24px; display: grid; place-items: center; background: linear-gradient(135deg, var(--primary), var(--accent)); color: white; }
    .score strong { font-size: 2.15rem; line-height: 1; }
    .score span { font-weight: 900; margin-top: -1.2rem; }
    .match-body p { color: var(--muted); }
    @media (max-width: 940px) { .market-header, .filters, .profile-editor, .match-card { display: grid; grid-template-columns: 1fr; } }
  `]
})
export class SkillSwapMarketplaceComponent implements OnInit {
  year = 1;
  semester: Semester = 'S1';
  profile?: SkillProfile;
  skills: Skill[] = [];
  matches: SkillMatch[] = [];
  query = '';
  selectedSkillId?: number;
  level: SkillLevel = 'INTERMEDIATE';
  loading = false;
  busy = false;
  error = '';
  success = '';
  sendingId?: number;
  constructor(private readonly auth: AuthService, private readonly api: CommunicationApiService) {}
  ngOnInit(): void { this.loadProfile(); this.search(); }
  profileReady(): boolean { return !!this.profile && this.profile.offers.length > 0 && this.profile.needs.length > 0; }
  loadProfile(): void { this.api.profile(this.auth.studentId()).subscribe({ next: profile => this.profile = profile, error: () => this.error = 'Profil indisponible.' }); }
  search(): void { this.api.skills(this.query).subscribe({ next: skills => this.skills = skills, error: () => this.error = 'Skills indisponibles.' }); }
  addOffer(): void { if (!this.selectedSkillId) return; this.busy = true; this.api.addOffer(this.auth.studentId(), this.selectedSkillId, this.level).pipe(finalize(() => this.busy = false)).subscribe({ next: () => { this.success = 'Offre ajoutee.'; this.loadProfile(); }, error: () => this.error = 'Offre non ajoutee.' }); }
  addNeed(): void { if (!this.selectedSkillId) return; this.busy = true; this.api.addNeed(this.auth.studentId(), this.selectedSkillId, this.level).pipe(finalize(() => this.busy = false)).subscribe({ next: () => { this.success = 'Besoin ajoute.'; this.loadProfile(); }, error: () => this.error = 'Besoin non ajoute.' }); }
  removeOffer(id: number): void { this.api.removeOffer(this.auth.studentId(), id).subscribe({ next: () => this.loadProfile(), error: () => this.error = 'Suppression impossible.' }); }
  removeNeed(id: number): void { this.api.removeNeed(this.auth.studentId(), id).subscribe({ next: () => this.loadProfile(), error: () => this.error = 'Suppression impossible.' }); }
  loadMatches(): void {
    if (!this.profileReady()) return;
    this.loading = true; this.error = ''; this.success = '';
    this.api.matches(this.auth.studentId(), this.year, this.semester).pipe(finalize(() => this.loading = false)).subscribe({
      next: matches => this.matches = matches,
      error: () => this.error = 'Matching indisponible.'
    });
  }
  sendRequest(match: SkillMatch): void {
    this.sendingId = match.candidateStudentId; this.error = ''; this.success = '';
    this.api.createSwap(this.auth.studentId(), { receiverId: match.candidateStudentId, requesterLearnsSkillId: match.candidateTeachesSkill.id, receiverLearnsSkillId: match.candidateWantsSkill?.id, year: this.year, semester: this.semester, message: `Je veux apprendre ${match.candidateTeachesSkill.name}.` })
      .pipe(finalize(() => this.sendingId = undefined))
      .subscribe({ next: () => { this.success = 'Demande envoyee.'; this.loadMatches(); }, error: () => this.error = 'Demande non envoyee.' });
  }
}
