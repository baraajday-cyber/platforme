import { CommonModule } from '@angular/common';
import { Component, computed, inject } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthService } from '../auth/auth.service';

interface NavItem {
  label: string;
  path: string;
  icon: string;
  visible: () => boolean;
}

@Component({
  selector: 'app-communication-shell',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive],
  template: `
    <main class="shell">
      <aside class="side-panel">
        <div class="brand-card">
          <div class="brand-logo">ENI</div>
          <div><strong>ENI Carthage</strong><span>{{ roleLabel() }}</span></div>
        </div>

        <nav class="nav-card">
          <a *ngFor="let item of visibleItems()" [routerLink]="item.path" routerLinkActive="active">
            <span>{{ item.icon }}</span>{{ item.label }}
          </a>
        </nav>

        <div class="profile-card">
          <div class="avatar">{{ initials() }}</div>
          <div><strong>{{ user()?.displayName }}</strong><span>{{ user()?.username }}</span></div>
          <button type="button" (click)="logout()">Sortir</button>
        </div>
      </aside>

      <section class="content-shell">
        <header class="topbar">
          <h1>Plateforme Academique</h1>
          <span>{{ user()?.defaultClassGroupName || roleLabel() }}</span>
        </header>
        <router-outlet />
      </section>
    </main>
  `,
  styles: [`
    .shell { min-height: 100vh; display: grid; grid-template-columns: 280px minmax(0, 1fr); gap: 1rem; padding: 1rem; }
    .side-panel { position: sticky; top: 1rem; height: calc(100vh - 2rem); display: grid; grid-template-rows: auto 1fr auto; gap: .85rem; }
    .brand-card, .nav-card, .profile-card, .topbar { background: rgba(255,255,255,.9); border: 1px solid rgba(226,232,240,.95); border-radius: 26px; box-shadow: var(--shadow-soft); }
    .brand-card { padding: .9rem; display: flex; gap: .8rem; align-items: center; }
    .brand-logo { width: 52px; height: 52px; border-radius: 18px; display: grid; place-items: center; color: white; font-weight: 950; background: linear-gradient(135deg, #0f766e, #2563eb); }
    .brand-card strong, .brand-card span, .profile-card strong, .profile-card span { display: block; }
    .brand-card span, .profile-card span { color: var(--muted); font-size: .82rem; font-weight: 850; }
    .nav-card { padding: .75rem; overflow: auto; display: grid; align-content: start; gap: .35rem; }
    .nav-card a { display: flex; align-items: center; gap: .75rem; padding: .86rem .9rem; border-radius: 18px; color: #52627f; font-weight: 900; }
    .nav-card a:hover, .nav-card a.active { background: linear-gradient(135deg, #ecfeff, #eef2ff); color: #0f3c68; }
    .profile-card { padding: .85rem; display: grid; grid-template-columns: auto minmax(0, 1fr); gap: .65rem; align-items: center; }
    .avatar { width: 46px; height: 46px; border-radius: 16px; display: grid; place-items: center; color: white; background: linear-gradient(135deg, #2563eb, #7c3aed); font-weight: 950; }
    .profile-card button { grid-column: 1 / -1; padding: .72rem; border-radius: 16px; background: #f8fafc; color: #475569; font-weight: 900; }
    .content-shell { min-width: 0; display: grid; align-content: start; gap: 1rem; }
    .topbar { padding: 1rem 1.2rem; display: flex; justify-content: space-between; gap: 1rem; align-items: center; }
    .topbar h1 { margin: 0; font-size: clamp(1.45rem, 3vw, 2.3rem); letter-spacing: -.06em; }
    .topbar span { color: var(--muted); font-weight: 900; }
    @media (max-width: 1040px) { .shell { grid-template-columns: 1fr; } .side-panel { position: static; height: auto; } .nav-card { display: flex; overflow-x: auto; } .nav-card a { white-space: nowrap; } .profile-card { grid-template-columns: auto 1fr auto; } .profile-card button { grid-column: auto; } }
  `]
})
export class CommunicationShellComponent {
  private readonly auth = inject(AuthService);

  readonly user = this.auth.user;
  readonly initials = this.auth.displayInitials;
  readonly roleLabel = computed(() => this.user()?.roles.join(' · ') || 'Invite');

  readonly navItems: NavItem[] = [
    { label: 'Dashboard', path: '/dashboard', icon: '⌂', visible: () => true },
    { label: 'Etudiants', path: '/admin-students', icon: '◎', visible: () => this.auth.isAdmin() },
    { label: 'Enseignants', path: '/admin-teachers', icon: '◇', visible: () => this.auth.isAdmin() },
    { label: 'Admin EDT', path: '/admin-timetable', icon: '▦', visible: () => this.auth.isAdmin() },
    { label: 'Saisie notes', path: '/admin-grades', icon: '✎', visible: () => this.auth.hasAnyRole(['TEACHER', 'DEPARTMENT_ADMIN', 'SUPER_ADMIN']) },
    { label: 'Mon EDT', path: '/teacher-timetable', icon: '◷', visible: () => this.auth.isTeacher() && !this.auth.isAdmin() },
    { label: 'Mon EDT', path: '/timetable', icon: '◷', visible: () => this.auth.isStudent() && !this.auth.isAdmin() },
    { label: 'Mes notes', path: '/grades', icon: '★', visible: () => this.auth.isStudent() && !this.auth.isAdmin() },
    { label: 'Notifications', path: '/notifications', icon: '●', visible: () => this.auth.isStudent() },
    { label: 'Profil Skill', path: '/skill-profile', icon: '✦', visible: () => this.auth.isStudent() && !this.auth.isAdmin() },
    { label: 'Skill Swap', path: '/marketplace', icon: '↔', visible: () => this.auth.isStudent() && !this.auth.isAdmin() }
  ];

  visibleItems(): NavItem[] { return this.navItems.filter(item => item.visible()); }
  logout(): void { this.auth.logout(); }
}
