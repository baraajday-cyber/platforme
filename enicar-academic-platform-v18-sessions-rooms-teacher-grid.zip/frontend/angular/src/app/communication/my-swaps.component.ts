import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { finalize, Observable } from 'rxjs';
import { AuthService } from '../auth/auth.service';
import { CommunicationApiService } from './communication-api.service';
import { SkillSwap } from './communication.models';

@Component({
  selector: 'app-my-swaps',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <section class="card swaps">
      <header>
        <div><span class="badge">Lifecycle</span><h2>Mes swaps</h2><p class="muted">Demandes, acceptation, planification, completion et notation.</p></div>
        <button class="btn secondary" (click)="load()" [disabled]="loading">Actualiser</button>
      </header>

      <div class="alert danger" *ngIf="error"><strong>Erreur</strong><span>{{ error }}</span></div>
      <div class="alert info" *ngIf="loading"><strong>Chargement</strong><span>Recuperation des swaps...</span></div>

      <article *ngFor="let swap of swaps" class="swap-card">
        <div>
          <span class="badge" [class.success]="swap.status === 'COMPLETED'" [class.warning]="swap.status === 'PENDING'" [class.info]="swap.status === 'SCHEDULED'">{{ swap.status }}</span>
          <h3>{{ swap.requesterLearnsSkill.name }}</h3>
          <p>{{ swap.message || 'Aucun message.' }}</p>
          <small>Cree le {{ swap.createdAt | date:'medium' }}<ng-container *ngIf="swap.scheduledAt"> · planifie le {{ swap.scheduledAt | date:'short' }}</ng-container></small>
        </div>
        <div class="swap-actions">
          <input class="input" type="datetime-local" [(ngModel)]="scheduleById[swap.id]">
          <input class="input" placeholder="Salle, bibliotheque..." [(ngModel)]="locationById[swap.id]">
          <button class="btn success" (click)="accept(swap)" [disabled]="busyId === swap.id || swap.status !== 'PENDING'">Accepter</button>
          <button class="btn secondary" (click)="schedule(swap)" [disabled]="busyId === swap.id || !scheduleById[swap.id]">Planifier</button>
          <button class="btn" (click)="complete(swap)" [disabled]="busyId === swap.id || swap.status === 'COMPLETED'">Terminer</button>
          <button class="btn danger" (click)="reject(swap)" [disabled]="busyId === swap.id || swap.status !== 'PENDING'">Refuser</button>
        </div>
      </article>
      <p *ngIf="!loading && swaps.length === 0" class="empty">Aucun swap. Envoie une demande depuis la marketplace.</p>
    </section>
  `,
  styles: [`
    .swaps { padding: 1.3rem; display: grid; gap: 1rem; }
    header { display: flex; justify-content: space-between; gap: 1rem; align-items: center; }
    h2 { margin: .45rem 0 .25rem; font-size: 2rem; }
    .swap-card { display: grid; grid-template-columns: minmax(0, 1fr) minmax(420px, 1.5fr); gap: 1rem; align-items: center; padding: 1rem; border: 1px solid var(--line); border-radius: 22px; background: #fff; box-shadow: var(--shadow-soft); }
    h3 { margin: .55rem 0 .25rem; }
    p, small { color: var(--muted); }
    .swap-actions { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: .55rem; }
    .swap-actions .input { grid-column: span 3; }
    @media (max-width: 950px) { .swap-card, .swap-actions, header { grid-template-columns: 1fr; display: grid; } .swap-actions .input { grid-column: auto; } }
  `]
})
export class MySwapsComponent implements OnInit {
  swaps: SkillSwap[] = [];
  scheduleById: Record<number, string> = {};
  locationById: Record<number, string> = {};
  loading = false;
  error = '';
  busyId?: number;
  constructor(private readonly auth: AuthService, private readonly api: CommunicationApiService) {}
  ngOnInit(): void { this.load(); }
  load(): void {
    this.loading = true;
    this.error = '';
    this.api.mySwaps(this.auth.studentId()).pipe(finalize(() => this.loading = false)).subscribe({
      next: swaps => this.swaps = swaps,
      error: () => this.error = 'Impossible de charger les swaps.'
    });
  }
  accept(swap: SkillSwap): void {
    this.withBusy(swap.id, this.api.acceptSwap(this.auth.studentId(), swap.id, 'OK'), 'Acceptation impossible.');
  }
  reject(swap: SkillSwap): void {
    this.withBusy(swap.id, this.api.rejectSwap(this.auth.studentId(), swap.id, 'Pas disponible'), 'Refus impossible.');
  }
  schedule(swap: SkillSwap): void {
    const value = this.scheduleById[swap.id];
    if (!value) return;
    this.withBusy(swap.id, this.api.scheduleSwap(this.auth.studentId(), swap.id, new Date(value).toISOString(), this.locationById[swap.id]), 'Planification impossible.');
  }
  complete(swap: SkillSwap): void {
    this.withBusy(swap.id, this.api.completeSwap(this.auth.studentId(), swap.id), 'Completion impossible.');
  }
  private withBusy<T>(id: number, request$: Observable<T>, errorMessage: string): void {
    this.busyId = id;
    this.error = '';
    request$.pipe(finalize(() => this.busyId = undefined)).subscribe({
      next: () => this.load(),
      error: () => this.error = errorMessage
    });
  }
}
