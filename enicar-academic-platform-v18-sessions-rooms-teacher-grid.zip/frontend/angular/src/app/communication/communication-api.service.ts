import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { NotificationItem, NotificationPreference, PageResponse, Semester, Skill, SkillCategory, SkillLevel, SkillMatch, SkillNeed, SkillOffer, SkillProfile, SkillSwap, SwapRating } from './communication.models';

@Injectable({ providedIn: 'root' })
export class CommunicationApiService {
  private readonly baseUrl = '/api';
  constructor(private readonly http: HttpClient) {}

  notifications(studentId: number, page = 0, size = 20): Observable<PageResponse<NotificationItem>> {
    return this.http.get<PageResponse<NotificationItem>>(`${this.baseUrl}/student/communication/notifications`, { params: { studentId, page, size } });
  }
  unreadCount(studentId: number): Observable<{ unreadCount: number }> {
    return this.http.get<{ unreadCount: number }>(`${this.baseUrl}/student/communication/notifications/unread-count`, { params: { studentId } });
  }
  markRead(studentId: number, notificationId: number): Observable<NotificationItem> {
    return this.http.patch<NotificationItem>(`${this.baseUrl}/student/communication/notifications/${notificationId}/read`, null, { params: { studentId } });
  }
  markAllRead(studentId: number): Observable<number> {
    return this.http.patch<number>(`${this.baseUrl}/student/communication/notifications/mark-all-read`, null, { params: { studentId } });
  }
  preferences(studentId: number): Observable<NotificationPreference> {
    return this.http.get<NotificationPreference>(`${this.baseUrl}/student/communication/notifications/preferences`, { params: { studentId } });
  }
  updatePreferences(studentId: number, body: NotificationPreference): Observable<NotificationPreference> {
    return this.http.put<NotificationPreference>(`${this.baseUrl}/student/communication/notifications/preferences`, body, { params: { studentId } });
  }
  skills(query?: string, category?: SkillCategory): Observable<Skill[]> {
    let params = new HttpParams();
    if (query) params = params.set('query', query);
    if (category) params = params.set('category', category);
    return this.http.get<Skill[]>(`${this.baseUrl}/skills`, { params });
  }
  profile(studentId: number): Observable<SkillProfile> {
    return this.http.get<SkillProfile>(`${this.baseUrl}/student/skill-swap/profile`, { params: { studentId } });
  }
  addOffer(studentId: number, skillId: number, level: SkillLevel, description?: string): Observable<SkillOffer> {
    return this.http.post<SkillOffer>(`${this.baseUrl}/student/skill-swap/profile/offers`, { skillId, level, description }, { params: { studentId } });
  }
  addNeed(studentId: number, skillId: number, targetLevel: SkillLevel, objective?: string): Observable<SkillNeed> {
    return this.http.post<SkillNeed>(`${this.baseUrl}/student/skill-swap/profile/needs`, { skillId, targetLevel, objective }, { params: { studentId } });
  }
  removeOffer(studentId: number, offerId: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/student/skill-swap/profile/offers/${offerId}`, { params: { studentId } });
  }
  removeNeed(studentId: number, needId: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/student/skill-swap/profile/needs/${needId}`, { params: { studentId } });
  }
  matches(studentId: number, year: number, semester: Semester, limit = 10): Observable<SkillMatch[]> {
    return this.http.get<SkillMatch[]>(`${this.baseUrl}/student/skill-swap/matches`, { params: { studentId, year, semester, limit } });
  }
  createSwap(studentId: number, body: { receiverId: number; requesterLearnsSkillId: number; receiverLearnsSkillId?: number; message?: string; year: number; semester: Semester; }): Observable<SkillSwap> {
    return this.http.post<SkillSwap>(`${this.baseUrl}/student/skill-swap/swaps`, body, { params: { studentId } });
  }
  mySwaps(studentId: number): Observable<SkillSwap[]> {
    return this.http.get<SkillSwap[]>(`${this.baseUrl}/student/skill-swap/swaps`, { params: { studentId } });
  }
  acceptSwap(studentId: number, swapId: number, reason?: string): Observable<SkillSwap> {
    return this.http.post<SkillSwap>(`${this.baseUrl}/student/skill-swap/swaps/${swapId}/accept`, { reason }, { params: { studentId } });
  }
  rejectSwap(studentId: number, swapId: number, reason?: string): Observable<SkillSwap> {
    return this.http.post<SkillSwap>(`${this.baseUrl}/student/skill-swap/swaps/${swapId}/reject`, { reason }, { params: { studentId } });
  }
  scheduleSwap(studentId: number, swapId: number, scheduledAt: string, location?: string): Observable<SkillSwap> {
    return this.http.post<SkillSwap>(`${this.baseUrl}/student/skill-swap/swaps/${swapId}/schedule`, { scheduledAt, location }, { params: { studentId } });
  }
  completeSwap(studentId: number, swapId: number): Observable<SkillSwap> {
    return this.http.post<SkillSwap>(`${this.baseUrl}/student/skill-swap/swaps/${swapId}/complete`, null, { params: { studentId } });
  }
  rateSwap(studentId: number, swapId: number, score: number, comment?: string): Observable<SwapRating> {
    return this.http.post<SwapRating>(`${this.baseUrl}/student/skill-swap/swaps/${swapId}/rating`, { score, comment }, { params: { studentId } });
  }
}
