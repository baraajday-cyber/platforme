import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit, computed, inject } from '@angular/core';
import { finalize } from 'rxjs';
import { Subscription } from 'rxjs';
import { AuthService } from '../auth/auth.service';
import { CommunicationApiService } from './communication-api.service';
import { NotificationWebSocketService } from './notification-websocket.service';
import { NotificationItem } from './communication.models';

@Component({
  selector: 'app-notifications-panel',
  standalone: true,
  imports: [CommonModule],
  template: `
    <section class="card panel">
      <header class="panel-header">
        <div>
          <span class="badge">Temps reel</span>
          <h2>Notifications</h2>
        </div>
        <div class="actions">
          <span class="ws" [class.online]="connected$ | async"><i></i>{{ (connected$ | async) ? 'WebSocket connecte' : 'WebSocket hors ligne' }}</span>
          <button class="btn secondary" type="button" (click)="load()" [disabled]="loading">Actualiser</button>
          <button class="btn" type="button" (click)="markAllRead()" [disabled]="unreadCount === 0 || loading">Tout lire {{ unreadCount ? '(' + unreadCount + ')' : '' }}</button>
        </div>
      </header>

      <div class="alert danger" *ngIf="error"><strong>Erreur</strong><span>{{ error }}</span></div>

      <div class="feed" *ngIf="notifications.length; else noNotifications">
        <article *ngFor="let item of notifications" class="notification" [class.unread]="!item.read">
          <div class="icon">{{ icon(item.type) }}</div>
          <div class="content">
            <div class="line">
              <strong>{{ item.title }}</strong>
              <span class="badge" [class.danger]="item.priority === 'URGENT'" [class.warning]="item.priority === 'HIGH'">{{ item.priority }}</span>
            </div>
            <p>{{ item.message }}</p>
            <small>{{ item.createdAt | date:'medium' }}</small>
          </div>
          <button *ngIf="!item.read" class="btn secondary" type="button" (click)="markRead(item)">Lire</button>
        </article>
      </div>

      <ng-template #noNotifications><p class="empty">Aucune notification.</p></ng-template>
    </section>
  `,
  styles: [`
    .panel { padding: 1.3rem; display: grid; gap: 1rem; }
    .panel-header { display: flex; align-items: flex-start; justify-content: space-between; gap: 1rem; }
    h2 { margin: .45rem 0 .25rem; font-size: 2rem; letter-spacing: -.03em; }
    .actions { display: flex; gap: .65rem; align-items: center; flex-wrap: wrap; justify-content: flex-end; }
    .ws { display: inline-flex; align-items: center; gap: .45rem; padding: .58rem .78rem; border-radius: 999px; background: #f1f5f9; color: var(--muted); font-weight: 900; font-size: .8rem; }
    .ws i { width: .55rem; height: .55rem; border-radius: 999px; background: #94a3b8; }
    .ws.online { background: #dcfce7; color: #166534; }
    .ws.online i { background: #22c55e; box-shadow: 0 0 0 5px rgba(34,197,94,.13); }
    .feed { display: grid; gap: .75rem; }
    .notification { display: grid; grid-template-columns: 52px 1fr auto; gap: 1rem; align-items: center; padding: 1rem; border: 1px solid var(--line); border-radius: 20px; background: #fff; box-shadow: var(--shadow-soft); }
    .notification.unread { border-color: #93c5fd; background: linear-gradient(135deg, #eff6ff, #fff); }
    .icon { width: 52px; height: 52px; border-radius: 17px; display: grid; place-items: center; background: #eef2ff; font-size: 1.2rem; color: var(--primary-dark); font-weight: 900; }
    .line { display: flex; align-items: center; gap: .6rem; flex-wrap: wrap; }
    p { margin: .3rem 0; color: #334155; }
    small { color: var(--muted); }
    @media (max-width: 760px) { .panel-header, .actions { display: grid; justify-content: stretch; } .notification { grid-template-columns: 1fr; } }
  `]
})
export class NotificationsPanelComponent implements OnInit, OnDestroy {
  private readonly auth = inject(AuthService);
  private readonly api = inject(CommunicationApiService);
  private readonly ws = inject(NotificationWebSocketService);

  notifications: NotificationItem[] = [];
  unreadCount = 0;
  loading = false;
  error = '';
  readonly connected$ = this.ws.connected$;
  readonly studentId = computed(() => this.auth.studentId());
  private sub = new Subscription();

  ngOnInit(): void {
    this.load();
    this.ws.connect(this.studentId());
    this.sub.add(this.ws.notifications$.subscribe(item => {
      this.notifications = [item, ...this.notifications.filter(n => n.id !== item.id)];
      this.unreadCount += item.read ? 0 : 1;
    }));
    this.sub.add(this.ws.errors$.subscribe(message => this.error = message));
  }
  ngOnDestroy(): void { this.sub.unsubscribe(); }
  load(): void {
    this.loading = true;
    this.error = '';
    this.api.notifications(this.studentId())
      .pipe(finalize(() => this.loading = false))
      .subscribe({
        next: page => {
          this.notifications = page.content;
          this.api.unreadCount(this.studentId()).subscribe(r => this.unreadCount = r.unreadCount);
        },
        error: () => this.error = 'Impossible de charger les notifications.'
      });
  }
  markRead(item: NotificationItem): void {
    this.api.markRead(this.studentId(), item.id).subscribe(updated => {
      this.notifications = this.notifications.map(n => n.id === updated.id ? updated : n);
      this.unreadCount = Math.max(0, this.unreadCount - 1);
    });
  }
  markAllRead(): void { this.api.markAllRead(this.studentId()).subscribe(() => this.load()); }
  icon(type: string): string {
    if (type.includes('GRADE')) return '★';
    if (type.includes('TIMETABLE')) return '◷';
    if (type.includes('SKILL')) return '↔';
    if (type.includes('DOCUMENT')) return '✓';
    return '●';
  }
}
