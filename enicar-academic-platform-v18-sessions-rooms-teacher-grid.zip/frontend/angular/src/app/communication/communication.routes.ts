import { Routes } from '@angular/router';
import { CommunicationShellComponent } from './communication-shell.component';
import { NotificationsPanelComponent } from './notifications-panel.component';
import { NotificationSettingsComponent } from './notification-settings.component';
import { SkillProfileComponent } from './skill-profile.component';
import { SkillSwapMarketplaceComponent } from './skill-swap-marketplace.component';
import { MySwapsComponent } from './my-swaps.component';

export const COMMUNICATION_ROUTES: Routes = [
  {
    path: '',
    component: CommunicationShellComponent,
    children: [
      { path: 'notifications', component: NotificationsPanelComponent },
      { path: 'notification-settings', component: NotificationSettingsComponent },
      { path: 'skill-profile', component: SkillProfileComponent },
      { path: 'skill-swap', component: SkillSwapMarketplaceComponent },
      { path: 'my-swaps', component: MySwapsComponent },
      { path: '', redirectTo: 'notifications', pathMatch: 'full' }
    ]
  }
];
