import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { finalize, Observable } from 'rxjs';
import { AuthService } from '../auth/auth.service';
import { CommunicationApiService } from './communication-api.service';
import { Skill, SkillLevel, SkillProfile } from './communication.models';

@Component({
  selector: 'app-skill-profile',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <section class="grid two">
      <div class="card editor">
        <span class="badge">Profil</span>
        <h2>Mes competences</h2>
        <p class="muted">Declare ce que tu peux enseigner et ce que tu veux apprendre.</p>
        <div class="alert danger" *ngIf="error"><strong>Erreur</strong><span>{{ error }}</span></div>
        <div class="field"><label>Recherche skill</label><input class="input" [(ngModel)]="query" (input)="search()" placeholder="Java, SQL, Python..."></div>
        <div class="field"><label>Skill</label><select class="select" [(ngModel)]="selectedSkillId"><option [ngValue]="undefined">Selectionner</option><option *ngFor="let skill of skills" [ngValue]="skill.id">{{ skill.name }} - {{ skill.category }}</option></select></div>
        <div class="field"><label>Niveau</label><select class="select" [(ngModel)]="level"><option value="BEGINNER">Debutant</option><option value="INTERMEDIATE">Intermediaire</option><option value="ADVANCED">Avance</option><option value="EXPERT">Expert</option></select></div>
        <div class="actions"><button class="btn" (click)="addOffer()" [disabled]="busy || !selectedSkillId">Je peux enseigner</button><button class="btn secondary" (click)="addNeed()" [disabled]="busy || !selectedSkillId">Je veux apprendre</button></div>
      </div>

      <div class="card profile-card" *ngIf="profile; else profileLoading">
        <div class="profile-summary">
          <article><strong>{{ profile.offers.length }}</strong><span>offres</span></article>
          <article><strong>{{ profile.needs.length }}</strong><span>besoins</span></article>
        </div>
        <div class="section-title"><h3>J'enseigne</h3><span>{{ profile.offers.length }}</span></div>
        <article *ngFor="let offer of profile.offers" class="skill-row"><div><strong>{{ offer.skill.name }}</strong><p>{{ offer.description || offer.skill.description || offer.skill.category }}</p></div><span class="badge success">{{ offer.level }}</span><button class="btn danger" (click)="removeOffer(offer.id)" [disabled]="busy">Retirer</button></article>
        <p *ngIf="profile.offers.length === 0" class="empty">Aucune competence enseignee.</p>
        <div class="section-title"><h3>Je veux apprendre</h3><span>{{ profile.needs.length }}</span></div>
        <article *ngFor="let need of profile.needs" class="skill-row"><div><strong>{{ need.skill.name }}</strong><p>{{ need.objective || need.skill.description || need.skill.category }}</p></div><span class="badge warning">{{ need.targetLevel }}</span><button class="btn danger" (click)="removeNeed(need.id)" [disabled]="busy">Retirer</button></article>
        <p *ngIf="profile.needs.length === 0" class="empty">Aucun besoin declare.</p>
      </div>
      <ng-template #profileLoading><div class="card profile-card"><p class="empty">{{ loading ? 'Chargement du profil...' : 'Profil non disponible.' }}</p></div></ng-template>
    </section>
  `,
  styles: [`
    h2 { margin: .45rem 0 .25rem; font-size: 2rem; }
    .editor, .profile-card { padding: 1.3rem; display: grid; gap: 1rem; align-content: start; }
    .actions { display: flex; gap: .7rem; flex-wrap: wrap; }
    .profile-summary { display: grid; grid-template-columns: repeat(2, 1fr); gap: .7rem; }
    .profile-summary article { padding: 1rem; border-radius: 20px; border: 1px solid var(--line); background: #f8fafc; }
    .profile-summary strong { display: block; font-size: 1.8rem; }
    .profile-summary span { color: var(--muted); }
    .section-title { display: flex; align-items: center; justify-content: space-between; margin-top: .5rem; }
    .section-title h3 { margin: 0; font-size: 1.2rem; }
    .section-title span { width: 34px; height: 34px; border-radius: 12px; background: #eef2ff; color: var(--primary-dark); display: grid; place-items: center; font-weight: 900; }
    .skill-row { display: grid; grid-template-columns: 1fr auto auto; gap: .7rem; align-items: center; border: 1px solid var(--line); border-radius: 20px; padding: .95rem; background: #fff; box-shadow: var(--shadow-soft); }
    .skill-row p { margin: .25rem 0 0; color: var(--muted); font-size: .9rem; }
    @media (max-width: 760px) { .skill-row { grid-template-columns: 1fr; } }
  `]
})
export class SkillProfileComponent implements OnInit {
  profile?: SkillProfile;
  skills: Skill[] = [];
  query = '';
  selectedSkillId?: number;
  level: SkillLevel = 'INTERMEDIATE';
  loading = false;
  busy = false;
  error = '';
  constructor(private readonly auth: AuthService, private readonly api: CommunicationApiService) {}
  ngOnInit(): void { this.load(); this.search(); }
  load(): void {
    this.loading = true;
    this.error = '';
    this.api.profile(this.auth.studentId()).pipe(finalize(() => this.loading = false)).subscribe({
      next: profile => this.profile = profile,
      error: () => this.error = 'Impossible de charger le profil Skill Swap.'
    });
  }
  search(): void { this.api.skills(this.query).subscribe({ next: skills => this.skills = skills, error: () => this.error = 'Recherche skill impossible.' }); }
  addOffer(): void {
    if (!this.selectedSkillId) return;
    this.runBusy(this.api.addOffer(this.auth.studentId(), this.selectedSkillId, this.level), 'Offre deja existante ou invalide.');
  }
  addNeed(): void {
    if (!this.selectedSkillId) return;
    this.runBusy(this.api.addNeed(this.auth.studentId(), this.selectedSkillId, this.level), 'Besoin deja existant ou invalide.');
  }
  removeOffer(offerId: number): void {
    this.runBusy(this.api.removeOffer(this.auth.studentId(), offerId), 'Suppression impossible.');
  }
  removeNeed(needId: number): void {
    this.runBusy(this.api.removeNeed(this.auth.studentId(), needId), 'Suppression impossible.');
  }
  private runBusy<T>(request$: Observable<T>, errorMessage: string): void {
    this.busy = true;
    this.error = '';
    request$.pipe(finalize(() => this.busy = false)).subscribe({
      next: () => this.load(),
      error: () => this.error = errorMessage
    });
  }
}
