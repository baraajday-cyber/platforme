export type Semester = 'S1' | 'S2' | 'S3' | 'S4';
export type NotificationPriority = 'LOW' | 'NORMAL' | 'HIGH' | 'URGENT';
export type SkillCategory = 'PROGRAMMING' | 'DATABASE' | 'MATHEMATICS' | 'LANGUAGES' | 'DESIGN' | 'DATA_AI' | 'NETWORK_SECURITY' | 'SOFT_SKILLS' | 'OTHER';
export type SkillLevel = 'BEGINNER' | 'INTERMEDIATE' | 'ADVANCED' | 'EXPERT';
export type SkillSwapStatus = 'PENDING' | 'ACCEPTED' | 'REJECTED' | 'SCHEDULED' | 'COMPLETED' | 'CANCELLED';

export interface PageResponse<T> { content: T[]; page: number; size: number; totalElements: number; totalPages: number; first: boolean; last: boolean; }
export interface NotificationItem { id: number; recipientId: number; senderId?: number; type: string; priority: NotificationPriority; title: string; message: string; payloadJson?: string; linkUrl?: string; read: boolean; deliveredAt?: string; emailSentAt?: string; readAt?: string; createdAt: string; }
export interface NotificationPreference { studentId: number; websocketEnabled: boolean; emailEnabled: boolean; timetableUpdates: boolean; gradeUpdates: boolean; swapUpdates: boolean; registrationUpdates: boolean; weeklyDigest: boolean; }
export interface Skill { id: number; name: string; normalizedName: string; category: SkillCategory; description?: string; academicCourseId?: number; department?: string; active: boolean; }
export interface SkillOffer { id: number; studentId: number; skill: Skill; level: SkillLevel; description?: string; active: boolean; }
export interface SkillNeed { id: number; studentId: number; skill: Skill; targetLevel: SkillLevel; objective?: string; active: boolean; }
export interface SkillProfile { studentId: number; offers: SkillOffer[]; needs: SkillNeed[]; }
export interface AvailabilityWindow { dayOfWeek: string; startTime: string; endTime: string; minutes: number; }
export interface ScoreBreakdown { totalScore: number; skillComplementarityScore: number; availabilityScore: number; tutorGradeScore: number; historyScore: number; departmentScore: number; commonAvailabilityMinutes: number; tutorGrade?: number; averageRating?: number; sameDepartment: boolean; mutualExchange: boolean; }
export interface SkillMatch { candidateStudentId: number; candidateDepartment?: string; candidateTeachesSkill: Skill; candidateWantsSkill?: Skill; score: ScoreBreakdown; commonAvailability: AvailabilityWindow[]; recommendation: string; }
export interface SkillSwap { id: number; requesterId: number; receiverId: number; requesterLearnsSkill: Skill; receiverLearnsSkill?: Skill; status: SkillSwapStatus; scheduledAt?: string; location?: string; message?: string; decisionReason?: string; decidedAt?: string; completedAt?: string; ratings: SwapRating[]; createdAt: string; }
export interface SwapRating { id: number; swapId: number; raterId: number; ratedId: number; score: number; comment?: string; createdAt: string; }
