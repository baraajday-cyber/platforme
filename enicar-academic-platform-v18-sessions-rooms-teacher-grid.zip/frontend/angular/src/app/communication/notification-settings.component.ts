import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { finalize } from 'rxjs';
import { AuthService } from '../auth/auth.service';
import { CommunicationApiService } from './communication-api.service';
import { NotificationPreference } from './communication.models';

@Component({
  selector: 'app-notification-settings',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <section class="card settings">
      <header>
        <span class="badge">Preferences</span>
        <h2>Canaux et categories</h2>
        <p class="muted">Choisis les notifications push/email a recevoir.</p>
      </header>

      <div class="alert danger" *ngIf="error"><strong>Erreur</strong><span>{{ error }}</span></div>
      <div class="alert success" *ngIf="saved"><strong>Sauvegarde reussie</strong><span>Preferences mises a jour.</span></div>

      <div class="grid two" *ngIf="prefs; else loadingTpl">
        <label class="switch-card"><div><strong>Temps reel</strong><span>Push instantane via WebSocket</span></div><input type="checkbox" [(ngModel)]="prefs.websocketEnabled"></label>
        <label class="switch-card"><div><strong>Email</strong><span>Envoi email via Spring Mail</span></div><input type="checkbox" [(ngModel)]="prefs.emailEnabled"></label>
        <label class="switch-card"><div><strong>Emploi du temps</strong><span>Salle, annulation ou changement</span></div><input type="checkbox" [(ngModel)]="prefs.timetableUpdates"></label>
        <label class="switch-card"><div><strong>Notes</strong><span>Saisie et recalcul des moyennes</span></div><input type="checkbox" [(ngModel)]="prefs.gradeUpdates"></label>
        <label class="switch-card"><div><strong>Skill Swap</strong><span>Demandes, acceptation, session</span></div><input type="checkbox" [(ngModel)]="prefs.swapUpdates"></label>
        <label class="switch-card"><div><strong>Inscriptions</strong><span>Statut, documents et corrections</span></div><input type="checkbox" [(ngModel)]="prefs.registrationUpdates"></label>
        <label class="switch-card"><div><strong>Digest hebdo</strong><span>Resume periodique</span></div><input type="checkbox" [(ngModel)]="prefs.weeklyDigest"></label>
      </div>

      <ng-template #loadingTpl><p class="empty">{{ loading ? 'Chargement des preferences...' : 'Aucune preference disponible.' }}</p></ng-template>

      <button class="btn" type="button" (click)="save()" [disabled]="!prefs || saving">
        <span *ngIf="saving" class="spinner"></span>
        {{ saving ? 'Sauvegarde...' : 'Sauvegarder' }}
      </button>
    </section>
  `,
  styles: [`
    .settings { padding: 1.3rem; display: grid; gap: 1rem; }
    h2 { margin: .45rem 0 .25rem; font-size: 2rem; }
    .switch-card { display: flex; align-items: center; justify-content: space-between; gap: 1rem; padding: 1rem; border-radius: 20px; border: 1px solid var(--line); background: #fff; box-shadow: var(--shadow-soft); }
    .switch-card strong { display: block; }
    .switch-card span { color: var(--muted); font-size: .9rem; }
    input[type='checkbox'] { width: 50px; height: 28px; accent-color: var(--primary); }
  `]
})
export class NotificationSettingsComponent implements OnInit {
  prefs?: NotificationPreference;
  loading = false;
  saving = false;
  saved = false;
  error = '';
  constructor(private readonly auth: AuthService, private readonly api: CommunicationApiService) {}
  ngOnInit(): void { this.load(); }
  load(): void {
    this.loading = true;
    this.error = '';
    this.api.preferences(this.auth.studentId()).pipe(finalize(() => this.loading = false)).subscribe({
      next: p => this.prefs = p,
      error: () => this.error = 'Impossible de charger les preferences.'
    });
  }
  save(): void {
    if (!this.prefs) return;
    this.saving = true;
    this.error = '';
    this.api.updatePreferences(this.auth.studentId(), this.prefs)
      .pipe(finalize(() => this.saving = false))
      .subscribe({
        next: p => { this.prefs = p; this.saved = true; setTimeout(() => this.saved = false, 2200); },
        error: () => this.error = 'Impossible de sauvegarder les preferences.'
      });
  }
}
