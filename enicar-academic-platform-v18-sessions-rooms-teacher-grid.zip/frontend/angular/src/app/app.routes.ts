import { Routes } from '@angular/router';
import { LoginComponent } from './auth/login.component';
import { CommunicationShellComponent } from './communication/communication-shell.component';
import { NotificationsPanelComponent } from './communication/notifications-panel.component';
import { NotificationSettingsComponent } from './communication/notification-settings.component';
import { SkillProfileComponent } from './communication/skill-profile.component';
import { SkillSwapMarketplaceComponent } from './communication/skill-swap-marketplace.component';
import { MySwapsComponent } from './communication/my-swaps.component';
import { AcademicDashboardComponent } from './academic/academic-dashboard.component';
import { TimetablePageComponent } from './academic/timetable-page.component';
import { GradesPageComponent } from './academic/grades-page.component';
import { AdminTimetableManagerComponent } from './academic/admin-timetable-manager.component';
import { AdminGradesManagerComponent } from './academic/admin-grades-manager.component';
import { AdminStudentsManagerComponent } from './academic/admin-students-manager.component';
import { AdminTeachersManagerComponent } from './academic/admin-teachers-manager.component';
import { TeacherDashboardComponent } from './academic/teacher-dashboard.component';
import { TeacherTimetableComponent } from './academic/teacher-timetable.component';
import { authGuard } from './auth/auth.guard';

const adminRoles = ['DEPARTMENT_ADMIN', 'SUPER_ADMIN'];
const teacherOrAdminRoles = ['TEACHER', 'DEPARTMENT_ADMIN', 'SUPER_ADMIN'];
const studentRoles = ['STUDENT'];

export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  {
    path: '',
    component: CommunicationShellComponent,
    canActivate: [authGuard],
    children: [
      { path: 'dashboard', component: AcademicDashboardComponent, canActivate: [authGuard] },
      { path: 'timetable', component: TimetablePageComponent, canActivate: [authGuard], data: { roles: studentRoles } },
      { path: 'grades', component: GradesPageComponent, canActivate: [authGuard], data: { roles: studentRoles } },
      { path: 'admin-students', component: AdminStudentsManagerComponent, canActivate: [authGuard], data: { roles: adminRoles } },
      { path: 'admin-teachers', component: AdminTeachersManagerComponent, canActivate: [authGuard], data: { roles: adminRoles } },
      { path: 'admin-timetable', component: AdminTimetableManagerComponent, canActivate: [authGuard], data: { roles: adminRoles } },
      { path: 'admin-grades', component: AdminGradesManagerComponent, canActivate: [authGuard], data: { roles: teacherOrAdminRoles } },
      { path: 'teacher', component: TeacherDashboardComponent, canActivate: [authGuard], data: { roles: teacherOrAdminRoles } },
      { path: 'teacher-timetable', component: TeacherTimetableComponent, canActivate: [authGuard], data: { roles: teacherOrAdminRoles } },
      { path: 'teacher-grades', component: AdminGradesManagerComponent, canActivate: [authGuard], data: { roles: teacherOrAdminRoles } },
      { path: 'notifications', component: NotificationsPanelComponent, canActivate: [authGuard], data: { roles: studentRoles } },
      { path: 'settings', component: NotificationSettingsComponent, canActivate: [authGuard], data: { roles: studentRoles } },
      { path: 'skill-profile', component: SkillProfileComponent, canActivate: [authGuard], data: { roles: studentRoles } },
      { path: 'marketplace', component: SkillSwapMarketplaceComponent, canActivate: [authGuard], data: { roles: studentRoles } },
      { path: 'my-swaps', component: MySwapsComponent, canActivate: [authGuard], data: { roles: studentRoles } },
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' }
    ]
  },
  { path: '**', redirectTo: '' }
];
