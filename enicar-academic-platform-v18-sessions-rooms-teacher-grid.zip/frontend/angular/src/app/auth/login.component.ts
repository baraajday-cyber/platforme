import { CommonModule } from '@angular/common';
import { Component, OnInit, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { catchError, of } from 'rxjs';
import { AuthService, DemoAccount } from './auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <main class="login-page">
      <section class="intro-card">
        <div class="school-mark">ENI</div>
        <h1>Plateforme Academique</h1>
        <h2>ENI Carthage</h2>
      </section>

      <section class="login-card card">
        <header class="login-head">
          <span class="badge info">Connexion</span>
          <h2>Acces utilisateur</h2>
          <span class="api-state" [class.ok]="backendOnline" [class.ko]="!backendOnline">
            API {{ backendOnline ? 'connectee' : 'hors ligne' }}
          </span>
        </header>

        <div class="account-grid">
          <button type="button" class="account" *ngFor="let account of demoAccounts" [class.selected]="username === account.username" (click)="fill(account)">
            <strong>{{ account.label }}</strong>
            <span>{{ account.username }} / {{ account.password }}</span>
          </button>
        </div>

        <form class="form" (ngSubmit)="submit()">
          <label class="field"><span>Utilisateur</span><input class="input" name="username" [(ngModel)]="username" autocomplete="username"></label>
          <label class="field"><span>Mot de passe</span><input class="input" name="password" type="password" [(ngModel)]="password" autocomplete="current-password"></label>
          <div class="alert danger" *ngIf="error"><span>{{ error }}</span></div>
          <button class="btn wide" type="submit" [disabled]="loading || !username || !password"><span class="spinner" *ngIf="loading"></span>{{ loading ? 'Connexion...' : 'Entrer' }}</button>
        </form>
      </section>
    </main>
  `,
  styles: [`
    .login-page { min-height: 100vh; display: grid; grid-template-columns: minmax(0, 1fr) 430px; gap: 1rem; padding: clamp(1rem, 3vw, 2rem); }
    .intro-card { border-radius: 34px; padding: clamp(2rem, 5vw, 5rem); background: radial-gradient(circle at 80% 0, rgba(255,255,255,.18), transparent 26rem), linear-gradient(135deg, #062a3f, #1d4ed8 58%, #0f766e); color: white; display: grid; align-content: center; box-shadow: var(--shadow); }
    .school-mark { width: 76px; height: 76px; border-radius: 24px; display: grid; place-items: center; background: rgba(255,255,255,.16); font-weight: 950; margin-bottom: 1.4rem; }
    h1 { margin: 0; font-size: clamp(3rem, 7vw, 6rem); line-height: .92; letter-spacing: -.08em; }
    .intro-card h2 { margin: .6rem 0 0; font-size: clamp(2rem, 4vw, 3.4rem); color: rgba(255,255,255,.86); letter-spacing: -.06em; }
    .login-card { align-self: center; padding: 1.35rem; display: grid; gap: 1rem; }
    .login-head { position: relative; display: grid; gap: .25rem; }
    .login-card h2 { margin: .15rem 0 0; font-size: 2rem; letter-spacing: -.05em; }
    .api-state { justify-self: start; border-radius: 999px; padding: .42rem .72rem; font-weight: 950; font-size: .8rem; background: #fff7ed; color: #9a3412; border: 1px solid #fed7aa; }
    .api-state.ok { background: #ecfdf5; color: #047857; border-color: #bbf7d0; }
    .api-state.ko { background: #fff7ed; color: #9a3412; border-color: #fed7aa; }
    .account-grid { display: grid; gap: .62rem; }
    .account { text-align: left; padding: .85rem; border-radius: 18px; border: 1px solid var(--line); background: white; display: grid; gap: .15rem; }
    .account:hover, .account.selected { border-color: #38bdf8; background: linear-gradient(135deg, #ecfeff, #eef2ff); }
    .account strong { color: #0f3c68; }
    .account span { color: var(--muted); font-weight: 850; }
    .form { display: grid; gap: .85rem; }
    .wide { width: 100%; }
    @media (max-width: 950px) { .login-page { grid-template-columns: 1fr; } }
  `]
})
export class LoginComponent implements OnInit {
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);

  readonly demoAccounts = this.auth.demoAccounts;
  username = 'admin';
  password = 'admin';
  loading = false;
  error = '';
  backendOnline = false;

  ngOnInit(): void {
    this.checkBackend();
  }

  fill(account: DemoAccount): void {
    this.username = account.username;
    this.password = account.password;
    this.error = '';
  }

  submit(): void {
    this.error = '';
    this.loading = true;
    this.auth.login(this.username.trim(), this.password).subscribe({
      next: () => this.router.navigateByUrl('/dashboard'),
      error: (err: HttpErrorResponse) => {
        this.loading = false;
        this.backendOnline = err.status !== 0;
        this.error = err.status === 0
          ? 'Backend indisponible. Lance Spring Boot sur le port 8081.'
          : 'Identifiant ou mot de passe incorrect.';
      }
    });
  }

  private checkBackend(): void {
    this.auth.backendHealth().pipe(catchError(() => of(null))).subscribe(res => {
      this.backendOnline = !!res;
    });
  }
}
