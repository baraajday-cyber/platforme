import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { catchError, throwError } from 'rxjs';
import { AuthService } from './auth.service';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(AuthService);
  const header = auth.authorizationHeader();
  const isLoginRequest = req.url.includes('/api/auth/login');

  const request = !header || isLoginRequest
    ? req
    : req.clone({ setHeaders: { Authorization: header } });

  return next(request).pipe(
    catchError((error: HttpErrorResponse) => {
      if (error.status === 401 && !isLoginRequest) {
        auth.logout();
      }
      return throwError(() => error);
    })
  );
};
