import { HttpClient } from '@angular/common/http';
import { Injectable, computed, signal } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, tap } from 'rxjs';

export interface AuthUser {
  username: string;
  studentId: number | null;
  roles: string[];
  displayName: string;
  defaultDepartment?: string | null;
  defaultYear?: number | null;
  defaultSemester?: 'S1' | 'S2' | 'S3' | 'S4' | null;
  defaultClassGroupName?: string | null;
  authScheme: 'Basic';
  accessToken?: string | null;
}

export interface DemoAccount {
  username: 'student' | 'student2' | 'teacher' | 'admin' | 'demo';
  password: string;
  label: string;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly storageKey = 'enicar-auth-user-v11';
  private readonly userSignal = signal<AuthUser | null>(this.readStoredUser());

  readonly demoAccounts: DemoAccount[] = [
    { username: 'admin', password: 'admin', label: 'Administration' },
    { username: 'teacher', password: 'teacher', label: 'Enseignant' },
    { username: 'student', password: 'student', label: 'Etudiant 2A' },
    { username: 'student2', password: 'student2', label: 'Etudiant 2B' },
    { username: 'demo', password: 'demo', label: 'Demo' }
  ];

  readonly user = this.userSignal.asReadonly();
  readonly isLoggedIn = computed(() => !!this.userSignal()?.accessToken);
  readonly isAdmin = computed(() => this.hasAnyRole(['DEPARTMENT_ADMIN', 'SUPER_ADMIN']));
  readonly isTeacher = computed(() => this.hasAnyRole(['TEACHER']));
  readonly isStudent = computed(() => this.hasAnyRole(['STUDENT']));
  readonly studentId = computed(() => this.userSignal()?.studentId ?? 0);
  readonly displayInitials = computed(() => {
    const name = this.userSignal()?.displayName ?? 'EN';
    return name.split(/\s+/).filter(Boolean).slice(0, 2).map(part => part[0]).join('').toUpperCase();
  });

  constructor(private readonly http: HttpClient, private readonly router: Router) {}

  backendHealth(): Observable<{ status: string }> {
    return this.http.get<{ status: string }>('/actuator/health');
  }

  login(username: string, password: string): Observable<AuthUser> {
    return this.http.post<AuthUser>('/api/auth/login', { username, password }).pipe(
      tap(user => this.storeUser(user))
    );
  }

  refreshMe(): Observable<AuthUser> {
    return this.http.get<AuthUser>('/api/auth/me').pipe(
      tap(user => {
        const current = this.userSignal();
        this.storeUser({ ...user, accessToken: current?.accessToken ?? user.accessToken });
      })
    );
  }

  logout(redirect = true): void {
    localStorage.removeItem(this.storageKey);
    this.userSignal.set(null);
    if (redirect) this.router.navigateByUrl('/login');
  }

  authorizationHeader(): string | null {
    const current = this.userSignal();
    return current?.accessToken ? `${current.authScheme} ${current.accessToken}` : null;
  }

  hasAnyRole(roles: string[]): boolean {
    const current = this.userSignal();
    return !!current && current.roles.some(role => roles.includes(role));
  }

  private storeUser(user: AuthUser): void {
    localStorage.setItem(this.storageKey, JSON.stringify(user));
    this.userSignal.set(user);
  }

  private readStoredUser(): AuthUser | null {
    try {
      const raw = localStorage.getItem(this.storageKey);
      if (!raw) return null;
      const parsed = JSON.parse(raw) as AuthUser;
      return parsed.accessToken ? parsed : null;
    } catch {
      localStorage.removeItem(this.storageKey);
      return null;
    }
  }
}
