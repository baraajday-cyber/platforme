import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { forkJoin } from 'rxjs';
import { AcademicApiService } from './academic-api.service';
import { ClassGroup, Semester, StudentCreateRequest, StudentUpdateRequest, StudentUser } from './academic.models';

interface GroupBlock {
  group: ClassGroup;
  students: StudentUser[];
}

@Component({
  selector: 'app-admin-students-manager',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <section class="students-page">
      <header class="page-title card">
        <div><span class="badge warning">Etudiants</span><h2>Comptes et groupes</h2></div>
        <button class="btn" type="button" (click)="resetForm()">Nouvel etudiant</button>
      </header>

      <section class="grid four">
        <article class="kpi card"><span>Total</span><strong>{{ students.length }}</strong></article>
        <article class="kpi card"><span>Actifs</span><strong>{{ activeStudents }}</strong></article>
        <article class="kpi card"><span>Groupes</span><strong>{{ groups.length }}</strong></article>
        <article class="kpi card"><span>Sans groupe</span><strong>{{ unassignedStudents }}</strong></article>
      </section>

      <div class="alert danger" *ngIf="error"><span>{{ error }}</span></div>
      <div class="alert success" *ngIf="success"><span>{{ success }}</span></div>

      <section class="editor-grid">
        <form class="student-form card" (ngSubmit)="saveStudent()">
          <h3>{{ editing ? 'Modifier etudiant' : 'Ajouter etudiant' }}</h3>
          <label>Nom complet<input class="input" name="fullName" [(ngModel)]="form.fullName" required /></label>
          <label>Identifiant<input class="input" name="username" [(ngModel)]="form.username" [disabled]="!!editing" required /></label>
          <label *ngIf="!editing">Mot de passe<input class="input" name="password" type="password" [(ngModel)]="form.password" required /></label>
          <label>Email<input class="input" name="email" [(ngModel)]="form.email" /></label>
          <label>Code etudiant<input class="input" name="studentCode" [(ngModel)]="form.studentCode" /></label>
          <label>Groupe
            <select class="select" name="classGroupId" [(ngModel)]="form.classGroupId" (ngModelChange)="syncFromGroup()" required>
              <option *ngFor="let group of groups" [ngValue]="group.id">{{ group.name }}</option>
            </select>
          </label>
          <div class="checks" *ngIf="editing">
            <label><input type="checkbox" name="enabled" [(ngModel)]="form.enabled" /> Actif</label>
            <label><input type="checkbox" name="enrolled" [(ngModel)]="form.enrolled" /> Inscrit</label>
          </div>
          <button class="btn wide" type="submit" [disabled]="saving || !form.fullName || !form.username || (!editing && !form.password) || !form.classGroupId">
            {{ saving ? 'Sauvegarde...' : (editing ? 'Enregistrer' : 'Creer') }}
          </button>
        </form>

        <section class="group-grid">
          <article class="group-card card" *ngFor="let block of groupBlocks">
            <button type="button" class="group-head" (click)="selectGroup(block.group)">
              <strong>{{ block.group.name }}</strong><span>{{ block.students.length }}</span>
            </button>
            <div class="student-list" *ngIf="block.students.length; else noStudents">
              <button type="button" *ngFor="let student of block.students" (click)="edit(student)" [class.selected]="editing?.studentId === student.studentId">
                <strong>{{ student.fullName }}</strong>
                <span>{{ student.username }} · {{ student.code || 'sans code' }}</span>
              </button>
            </div>
            <ng-template #noStudents><p>Aucun etudiant</p></ng-template>
          </article>
        </section>
      </section>
    </section>
  `,
  styles: [`
    .students-page { display: grid; gap: 1rem; }
    .page-title { padding: 1.1rem; display: flex; justify-content: space-between; align-items: center; gap: 1rem; }
    h2, h3 { margin: .3rem 0 0; letter-spacing: -.05em; }
    .kpi { padding: 1rem; }
    .kpi span { color: var(--muted); font-weight: 900; }
    .kpi strong { display: block; font-size: 2rem; letter-spacing: -.06em; }
    .editor-grid { display: grid; grid-template-columns: 360px minmax(0, 1fr); gap: 1rem; align-items: start; }
    .student-form { padding: 1rem; display: grid; gap: .8rem; }
    .student-form label { display: grid; gap: .35rem; font-size: .84rem; color: #334155; font-weight: 900; }
    .checks { display: flex; gap: .8rem; flex-wrap: wrap; }
    .checks label { display: flex; align-items: center; gap: .35rem; }
    .wide { width: 100%; }
    .group-grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: .8rem; }
    .group-card { padding: .8rem; min-height: 230px; }
    .group-head { width: 100%; display: flex; justify-content: space-between; align-items: center; gap: .75rem; border-radius: 18px; padding: .75rem; background: #f8fafc; color: #0f172a; }
    .group-head span { width: 2rem; height: 2rem; border-radius: 999px; display: grid; place-items: center; background: #eef2ff; color: #1d4ed8; font-weight: 950; }
    .student-list { display: grid; gap: .5rem; margin-top: .7rem; }
    .student-list button { text-align: left; border-radius: 16px; padding: .65rem; background: #fff; border: 1px solid var(--line); }
    .student-list button:hover, .student-list button.selected { border-color: #38bdf8; background: #ecfeff; }
    .student-list strong, .student-list span { display: block; }
    .student-list span, p { color: var(--muted); font-size: .82rem; }
    p { text-align: center; padding: 1rem; }
    @media (max-width: 1280px) { .group-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); } }
    @media (max-width: 940px) { .editor-grid, .page-title { grid-template-columns: 1fr; display: grid; } .group-grid { grid-template-columns: 1fr; } }
  `]
})
export class AdminStudentsManagerComponent implements OnInit {
  students: StudentUser[] = [];
  groups: ClassGroup[] = [];
  editing?: StudentUser;
  saving = false;
  error = '';
  success = '';
  form = this.emptyForm();

  constructor(private readonly api: AcademicApiService) {}

  ngOnInit(): void { this.loadAll(); }

  get activeStudents(): number { return this.students.filter(student => student.enabled && student.enrolled).length; }
  get unassignedStudents(): number { return this.students.filter(student => !student.classGroupId).length; }
  get groupBlocks(): GroupBlock[] {
    return this.groups.map(group => ({
      group,
      students: this.students
        .filter(student => student.classGroupId === group.id)
        .slice()
        .sort((a, b) => a.fullName.localeCompare(b.fullName, 'fr'))
    }));
  }

  loadAll(): void {
    this.error = '';
    forkJoin({
      students: this.api.adminStudentUsers(),
      groupsS2: this.api.adminClassGroups('Informatique', 1, 'S2'),
      groupsS4: this.api.adminClassGroups('Informatique', 2, 'S4')
    }).subscribe({
      next: ({ students, groupsS2, groupsS4 }) => {
        this.students = students.slice().sort((a, b) => a.fullName.localeCompare(b.fullName, 'fr'));
        this.groups = [...groupsS2, ...groupsS4].sort((a, b) => a.name.localeCompare(b.name, 'fr'));
        if (!this.form.classGroupId && this.groups.length) this.selectGroup(this.groups[0]);
      },
      error: err => this.error = err?.error?.message ?? 'Chargement impossible.'
    });
  }

  selectGroup(group: ClassGroup): void {
    this.form.classGroupId = group.id;
    this.form.department = group.department;
    this.form.year = group.year;
    this.form.semester = group.semester;
  }

  syncFromGroup(): void {
    const group = this.groups.find(item => item.id === this.form.classGroupId);
    if (group) this.selectGroup(group);
  }

  edit(student: StudentUser): void {
    this.editing = student;
    this.form = {
      username: student.username,
      password: '',
      fullName: student.fullName,
      email: student.email ?? '',
      studentCode: student.code ?? '',
      department: student.department || 'Informatique',
      year: student.year || 2,
      semester: student.semester || 'S4',
      classGroupId: student.classGroupId,
      enabled: student.enabled,
      enrolled: student.enrolled
    };
  }

  resetForm(): void {
    this.editing = undefined;
    this.form = this.emptyForm();
    if (this.groups.length) this.selectGroup(this.groups[0]);
  }

  saveStudent(): void {
    this.saving = true;
    this.error = '';
    this.success = '';
    this.syncFromGroup();
    if (this.editing) {
      const request: StudentUpdateRequest = {
        fullName: this.form.fullName,
        email: this.form.email || null,
        studentCode: this.form.studentCode || null,
        department: this.form.department,
        year: this.form.year,
        semester: this.form.semester,
        classGroupId: this.form.classGroupId,
        enabled: this.form.enabled,
        enrolled: this.form.enrolled
      };
      this.api.updateStudent(this.editing.studentId, request).subscribe(this.afterSave('Etudiant mis a jour.'));
    } else {
      const request: StudentCreateRequest = {
        username: this.form.username,
        password: this.form.password,
        fullName: this.form.fullName,
        email: this.form.email || null,
        studentCode: this.form.studentCode || null,
        department: this.form.department,
        year: this.form.year,
        semester: this.form.semester,
        classGroupId: this.form.classGroupId
      };
      this.api.createStudent(request).subscribe(this.afterSave('Etudiant cree.'));
    }
  }

  private afterSave(message: string) {
    return {
      next: () => {
        this.saving = false;
        this.success = message;
        this.resetForm();
        this.loadAll();
      },
      error: (err: any) => {
        this.saving = false;
        this.error = err?.error?.message ?? 'Sauvegarde impossible.';
      }
    };
  }

  private emptyForm() {
    return {
      username: '', password: '', fullName: '', email: '', studentCode: '',
      department: 'Informatique', year: 1, semester: 'S2' as Semester,
      classGroupId: 0, enabled: true, enrolled: true
    };
  }
}
