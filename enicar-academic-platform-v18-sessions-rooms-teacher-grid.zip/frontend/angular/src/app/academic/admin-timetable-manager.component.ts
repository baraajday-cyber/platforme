import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { finalize } from 'rxjs';
import { AcademicApiService } from './academic-api.service';
import { ClassGroup, DayName, Semester, TimetableChangeRequestItem, TimetableSlot, TimetableSlotMoveRequest, WeeklyTimetable } from './academic.models';

interface SessionRow {
  label: string;
  start: string;
  end: string;
}

interface MoveDraft {
  slot: TimetableSlot;
  dayOfWeek: DayName;
  startTime: string;
  endTime: string;
  sessionKey: string;
  room: string;
  professorName?: string;
  changeReason: string;
}

@Component({
  selector: 'app-admin-timetable-manager',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <section class="card admin-page">
      <header class="page-head">
        <div><span class="badge warning">Admin EDT</span><h2>Emploi du temps</h2></div>
        <div class="filters">
          <select class="select" [(ngModel)]="year" (ngModelChange)="syncSemester()"><option [ngValue]="1">Annee 1</option><option [ngValue]="2">Annee 2</option></select>
          <select class="select" [(ngModel)]="semester"><option value="S1">S1</option><option value="S2">S2</option><option value="S3">S3</option><option value="S4">S4</option></select>
          <button class="btn" type="button" (click)="loadGroups()" [disabled]="loading">Charger</button>
        </div>
      </header>

      <div class="alert danger" *ngIf="error"><span>{{ error }}</span></div>
      <div class="alert success" *ngIf="success"><span>{{ success }}</span></div>

      <section class="request-board" *ngIf="pendingRequests.length">
        <div class="request-head"><strong>Demandes enseignants</strong><button class="mini" type="button" (click)="loadRequests()">Actualiser</button></div>
        <article class="request-card" *ngFor="let request of pendingRequests">
          <div>
            <strong>{{ request.teacherName }}</strong> · {{ request.courseName }} · {{ request.classGroupName }}
            <small>{{ label(request.currentDayOfWeek) }} {{ request.currentStartTime }}-{{ request.currentEndTime }} {{ request.currentRoom }} → {{ label(request.requestedDayOfWeek) }} {{ request.requestedStartTime }}-{{ request.requestedEndTime }} {{ request.requestedRoom }}</small>
            <small *ngIf="request.reason">{{ request.reason }}</small>
          </div>
          <div class="request-actions">
            <button class="mini" type="button" (click)="approveRequest(request)">Accepter</button>
            <button class="mini danger" type="button" (click)="rejectRequest(request)">Refuser</button>
          </div>
        </article>
      </section>

      <div class="group-strip" *ngIf="groups.length">
        <button *ngFor="let group of groups" type="button" [class.active]="group.id === selectedGroupId" (click)="selectGroup(group)">
          <strong>{{ group.name }}</strong><span>{{ group.semester }}</span>
        </button>
      </div>

      <div class="admin-layout" [class.with-panel]="!!moveDraft" *ngIf="timetable">
        <div class="timeline-wrap">
          <div class="timeline">
            <div class="corner">Heure</div>
            <div class="day-head" *ngFor="let day of days">{{ label(day) }}</div>

            <ng-container *ngFor="let row of timeRows">
              <div class="time-cell"><strong>{{ row.label }}</strong><small>{{ row.start }} - {{ row.end }}</small></div>
              <div class="drop-cell" *ngFor="let day of days" (dragover)="$event.preventDefault()" (drop)="dropSlot(day, row.start, row.end)">
                <article *ngFor="let slot of slotsAt(day, row.start)" class="slot-card" draggable="true" (dragstart)="dragSlot(slot)">
                  <div class="slot-title"><strong>{{ slot.courseName }}</strong><span>{{ slot.room }}</span></div>
                  <p>{{ slot.professorName || '-' }}</p>
                  <small>{{ slot.startTime }} - {{ slot.endTime }}</small>
                  <div class="slot-actions">
                    <button class="mini" type="button" (click)="openMove(slot)">Deplacer</button>
                    <button class="mini danger" type="button" (click)="deleteSlot(slot)">Effacer</button>
                  </div>
                </article>
                <span *ngIf="slotsAt(day, row.start).length === 0" class="free">Libre</span>
              </div>
            </ng-container>
          </div>
        </div>

        <aside class="move-panel card" *ngIf="moveDraft">
          <span class="badge info">Deplacement</span>
          <h3>{{ moveDraft.slot.courseName }}</h3>
          <label>Jour
            <select class="select" [(ngModel)]="moveDraft.dayOfWeek" (ngModelChange)="loadAvailableRooms()">
              <option *ngFor="let day of days" [value]="day">{{ label(day) }}</option>
            </select>
          </label>
          <label>Creneau
            <select class="select" [(ngModel)]="moveDraft.sessionKey" (ngModelChange)="setMoveSession($event)">
              <option *ngFor="let row of timeRows" [value]="sessionKey(row.start, row.end)">{{ row.label }} · {{ row.start }}-{{ row.end }}</option>
            </select>
          </label>
          <label>Salle libre
            <select class="select" [(ngModel)]="moveDraft.room">
              <option *ngFor="let room of availableRooms" [value]="room">{{ room }}</option>
            </select>
            <small *ngIf="availableRooms.length === 0">Aucune salle libre pour ce creneau.</small>
          </label>
          <label>Professeur<input class="input" [(ngModel)]="moveDraft.professorName" /></label>
          <div class="move-actions">
            <button class="btn secondary" type="button" (click)="checkRoom()" [disabled]="saving || !moveDraft.room">Verifier</button>
            <button class="btn" type="button" (click)="confirmMove()" [disabled]="saving || !moveDraft.room || availableRooms.length === 0">Valider</button>
            <button class="btn ghost" type="button" (click)="moveDraft = undefined">Annuler</button>
          </div>
        </aside>
      </div>

      <p class="empty" *ngIf="!loading && !timetable">Aucune classe selectionnee</p>
    </section>
  `,
  styles: [`
    .admin-page { padding: 1.2rem; display: grid; gap: 1rem; overflow: hidden; }
    .page-head { display: flex; justify-content: space-between; align-items: flex-start; gap: 1rem; }
    h2 { margin: .35rem 0 0; font-size: clamp(1.65rem, 3vw, 2.35rem); letter-spacing: -.05em; }
    .filters { display: grid; grid-template-columns: .8fr .65fr auto; gap: .65rem; align-items: center; min-width: min(540px, 100%); }
    .group-strip { display: flex; gap: .7rem; overflow-x: auto; padding: .2rem 0 .75rem; }
    .request-board { display: grid; gap: .55rem; padding: .75rem; border: 1px solid #bfdbfe; background: #eff6ff; border-radius: 22px; }
    .request-head, .request-card, .request-actions { display: flex; justify-content: space-between; align-items: center; gap: .75rem; }
    .request-card { padding: .75rem; background: #fff; border: 1px solid var(--line); border-radius: 18px; }
    .request-card small { display: block; color: var(--muted); margin-top: .25rem; }
    .group-strip button { border: 1px solid var(--line); border-radius: 20px; background: #fff; padding: .8rem .95rem; min-width: 150px; text-align: left; box-shadow: var(--shadow-soft); }
    .group-strip button.active { border-color: #2563eb; color: #1d4ed8; background: #eff6ff; }
    .group-strip span { display: block; color: var(--muted); font-size: .78rem; margin-top: .2rem; }
    .admin-layout { display: grid; grid-template-columns: minmax(0, 1fr); gap: 1rem; align-items: start; min-width: 0; }
    .admin-layout.with-panel { grid-template-columns: minmax(0, 1fr) 340px; }
    .timeline-wrap { width: 100%; overflow-x: auto; padding-bottom: .5rem; }
    .timeline { min-width: 1280px; display: grid; grid-template-columns: 104px repeat(6, 184px); gap: .7rem; align-items: stretch; }
    .corner, .day-head, .time-cell { border-radius: 18px; padding: .9rem; font-weight: 950; }
    .corner { background: #0f172a; color: white; display: grid; place-items: center; }
    .day-head { color: #fff; text-align: center; background: linear-gradient(135deg, #2563eb, #0f766e); }
    .time-cell { background: #f8fafc; color: #334155; border: 1px solid var(--line); display: grid; align-content: start; min-height: 145px; }
    .time-cell small { color: var(--muted); }
    .drop-cell { min-height: 145px; border: 1px dashed #cbd5e1; border-radius: 20px; background: rgba(248,250,252,.88); padding: .55rem; display: grid; gap: .5rem; align-content: start; }
    .drop-cell:hover { background: #eef6ff; border-color: #60a5fa; }
    .slot-card { cursor: grab; padding: .82rem; border-radius: 18px; border: 1px solid #bfdbfe; background: linear-gradient(135deg, #fff, #eff6ff); box-shadow: 0 10px 22px rgba(37,99,235,.09); overflow: hidden; }
    .slot-title { display: flex; justify-content: space-between; gap: .5rem; align-items: start; }
    .slot-title strong { font-size: .9rem; line-height: 1.2; }
    .slot-title span { flex: 0 0 auto; padding: .18rem .5rem; border-radius: 999px; background: #dbeafe; color: #1d4ed8; font-size: .72rem; font-weight: 950; max-width: 75px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .slot-card p, .slot-card small { margin: .32rem 0 0; color: var(--muted); display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .slot-actions { display: flex; gap: .35rem; flex-wrap: wrap; margin-top: .65rem; }
    .mini { border: 0; border-radius: 999px; padding: .45rem .62rem; font-weight: 900; background: #e0f2fe; color: #075985; cursor: pointer; }
    .mini.danger { background: #fee2e2; color: #991b1b; }
    .free { color: #94a3b8; font-size: .82rem; align-self: center; justify-self: center; }
    .move-panel { padding: 1rem; display: grid; gap: .85rem; position: sticky; top: 1rem; }
    .move-panel h3 { margin: 0; }
    .move-panel label { display: grid; gap: .35rem; color: var(--muted); font-size: .82rem; font-weight: 900; }
    .move-actions { display: grid; gap: .55rem; }
    @media (max-width: 1280px) { .admin-layout.with-panel { grid-template-columns: 1fr; } .move-panel { position: static; } }
    @media (max-width: 880px) { .page-head, .filters { display: grid; grid-template-columns: 1fr; } }
  `]
})
export class AdminTimetableManagerComponent implements OnInit {
  department = 'Informatique';
  year = 1;
  semester: Semester = 'S2';
  groups: ClassGroup[] = [];
  rooms: string[] = [];
  availableRooms: string[] = [];
  pendingRequests: TimetableChangeRequestItem[] = [];
  selectedGroupId?: number;
  timetable?: WeeklyTimetable;
  moveDraft?: MoveDraft;
  draggedSlot?: TimetableSlot;
  loading = false;
  saving = false;
  error = '';
  success = '';

  readonly days: DayName[] = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
  readonly timeRows: SessionRow[] = [
    { label: 'S1 matin', start: '08:30', end: '10:00' },
    { label: 'S2 matin', start: '10:10', end: '11:40' },
    { label: 'S3 apres-midi', start: '12:30', end: '14:00' },
    { label: 'S4 apres-midi', start: '14:10', end: '15:40' },
    { label: 'S5 apres-midi', start: '15:50', end: '17:20' }
  ];

  constructor(private readonly api: AcademicApiService) {}
  ngOnInit(): void { this.loadGroups(); this.loadRequests(); this.api.rooms().subscribe({ next: rooms => this.rooms = rooms }); }
  syncSemester(): void { this.semester = this.year === 1 ? 'S2' : 'S4'; }
  loadGroups(): void {
    this.loading = true; this.error = ''; this.success = ''; this.timetable = undefined; this.moveDraft = undefined;
    this.api.adminClassGroups(this.department, this.year, this.semester).pipe(finalize(() => this.loading = false)).subscribe({
      next: groups => { this.groups = groups; if (groups.length) this.selectGroup(groups[0]); },
      error: () => this.error = 'Classes indisponibles.'
    });
  }
  selectGroup(group: ClassGroup): void {
    this.selectedGroupId = group.id; this.loading = true; this.moveDraft = undefined;
    this.api.adminClassTimetable(group.id).pipe(finalize(() => this.loading = false)).subscribe({
      next: timetable => this.timetable = timetable,
      error: () => this.error = 'Emploi du temps indisponible.'
    });
  }
  slotsAt(day: DayName, start: string): TimetableSlot[] { return (this.timetable?.slotsByDay?.[day] ?? []).filter(slot => slot.startTime?.slice(0, 5) === start); }
  dragSlot(slot: TimetableSlot): void { this.draggedSlot = slot; }
  dropSlot(dayOfWeek: DayName, startTime: string, endTime: string): void { if (this.draggedSlot) this.openMove(this.draggedSlot, dayOfWeek, startTime, endTime); this.draggedSlot = undefined; }
  openMove(slot: TimetableSlot, dayOfWeek = slot.dayOfWeek, startTime = slot.startTime.slice(0, 5), endTime = slot.endTime.slice(0, 5)): void {
    this.error = ''; this.success = '';
    const session = this.closestSession(startTime, endTime);
    this.moveDraft = { slot, dayOfWeek, startTime: session.start, endTime: session.end, sessionKey: this.sessionKey(session.start, session.end), room: slot.room, professorName: slot.professorName, changeReason: 'Modification EDT' };
    this.loadAvailableRooms();
  }
  setMoveSession(key: string): void {
    if (!this.moveDraft) return;
    const [start, end] = key.split('|');
    this.moveDraft.startTime = start;
    this.moveDraft.endTime = end;
    this.loadAvailableRooms();
  }
  loadAvailableRooms(): void {
    if (!this.moveDraft) return;
    const d = this.moveDraft;
    this.api.adminAvailableRooms(d.dayOfWeek, d.startTime, d.endTime, d.slot.id).subscribe({
      next: rooms => {
        this.availableRooms = rooms;
        if (!rooms.includes(d.room)) {
          d.room = rooms[0] ?? '';
        }
      },
      error: () => { this.availableRooms = []; d.room = ''; this.error = 'Liste des salles indisponible.'; }
    });
  }
  loadRequests(): void {
    this.api.adminChangeRequests('PENDING').subscribe({ next: requests => this.pendingRequests = requests, error: () => this.pendingRequests = [] });
  }
  approveRequest(request: TimetableChangeRequestItem): void {
    this.api.approveChangeRequest(request.id, 'Demande acceptee').subscribe({
      next: () => { this.success = 'Demande acceptee et seance deplacee.'; this.loadRequests(); const group = this.groups.find(g => g.name === request.classGroupName); if (group) this.selectGroup(group); },
      error: err => this.error = err?.error?.message ?? 'Acceptation impossible.'
    });
  }
  rejectRequest(request: TimetableChangeRequestItem): void {
    this.api.rejectChangeRequest(request.id, 'Demande refusee').subscribe({
      next: () => { this.success = 'Demande refusee.'; this.loadRequests(); },
      error: err => this.error = err?.error?.message ?? 'Refus impossible.'
    });
  }

  checkRoom(): void {
    if (!this.moveDraft) return;
    this.saving = true; this.error = ''; this.success = '';
    const d = this.moveDraft;
    this.api.roomAvailability(d.room, d.dayOfWeek, d.startTime, d.endTime, d.slot.id).pipe(finalize(() => this.saving = false)).subscribe({
      next: result => result.available ? this.success = 'Salle libre' : this.error = result.message,
      error: err => this.error = err?.error?.message ?? 'Verification impossible.'
    });
  }
  confirmMove(): void {
    if (!this.moveDraft) return;
    this.saving = true; this.error = ''; this.success = '';
    const d = this.moveDraft;
    const request: TimetableSlotMoveRequest = { dayOfWeek: d.dayOfWeek, startTime: d.startTime, endTime: d.endTime, room: d.room, professorId: d.slot.professorId, professorName: d.professorName, changeReason: d.changeReason };
    this.api.moveSlot(d.slot.id, request).pipe(finalize(() => this.saving = false)).subscribe({
      next: () => { this.success = 'Seance deplacee.'; const group = this.groups.find(g => g.id === this.selectedGroupId); if (group) this.selectGroup(group); },
      error: err => this.error = err?.error?.message ?? err?.error?.detail ?? 'Deplacement refuse.'
    });
  }
  deleteSlot(slot: TimetableSlot): void {
    if (!confirm(`Effacer ${slot.courseName} ?`)) return;
    this.error = ''; this.success = '';
    this.api.deleteSlot(slot.id).subscribe({
      next: () => { this.success = 'Seance effacee.'; const group = this.groups.find(g => g.id === this.selectedGroupId); if (group) this.selectGroup(group); },
      error: () => this.error = 'Suppression impossible.'
    });
  }
  sessionKey(start: string, end: string): string { return `${start}|${end}`; }
  closestSession(start: string, end: string): SessionRow { return this.timeRows.find(row => row.start === start && row.end === end) ?? this.timeRows[2]; }
  label(day: DayName): string { return ({ MONDAY: 'Lundi', TUESDAY: 'Mardi', WEDNESDAY: 'Mercredi', THURSDAY: 'Jeudi', FRIDAY: 'Vendredi', SATURDAY: 'Samedi' } as Record<DayName, string>)[day]; }
}
