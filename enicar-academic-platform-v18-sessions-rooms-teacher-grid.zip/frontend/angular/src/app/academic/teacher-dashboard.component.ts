import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

interface TeachingCard {
  course: string;
  groups: string;
  room: string;
  schedule: string;
}

@Component({
  selector: 'app-teacher-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <section class="teacher-page">
      <article class="teacher-hero card">
        <div><span class="badge info">Enseignant</span><h2>Espace enseignant</h2></div>
        <div class="actions"><a class="btn" routerLink="/teacher-grades">Saisir les notes</a><a class="btn secondary" routerLink="/teacher-timetable">Mon EDT</a></div>
      </article>

      <section class="grid three">
        <article class="teacher-card card" *ngFor="let item of teachingLoad">
          <span class="badge">{{ item.groups }}</span>
          <h3>{{ item.course }}</h3>
          <p>{{ item.schedule }}</p>
          <small>{{ item.room }}</small>
        </article>
      </section>
    </section>
  `,
  styles: [`
    .teacher-page { display: grid; gap: 1rem; }
    .teacher-hero { padding: 1.25rem; display: flex; justify-content: space-between; align-items: center; gap: 1rem; background: linear-gradient(135deg, #083344, #0f766e); color: white; }
    .actions { display: flex; gap: .7rem; flex-wrap: wrap; }
    h2 { margin: .35rem 0 0; font-size: clamp(2rem, 4vw, 3.2rem); letter-spacing: -.06em; }
    .teacher-card { padding: 1.1rem; display: grid; gap: .5rem; }
    .teacher-card h3 { margin: .3rem 0 0; font-size: 1.25rem; }
    .teacher-card p, .teacher-card small { color: var(--muted); }
    @media (max-width: 780px) { .teacher-hero { display: grid; } }
  `]
})
export class TeacherDashboardComponent {
  readonly teachingLoad: TeachingCard[] = [
    { course: 'Analyse des Donnees', groups: 'Ing Inf 2A / 2B', room: 'SL33 / SL25', schedule: 'Vendredi 08:30 + Jeudi 14:10' },
    { course: 'Programmation Orientee Objet', groups: 'Ing Inf 1A / 1B', room: 'SL23 / SL30', schedule: 'Mercredi et Jeudi' },
    { course: 'Technologies Web', groups: 'Ing Inf 1A / 1C', room: 'SL27', schedule: 'Vendredi apres-midi' }
  ];
}
