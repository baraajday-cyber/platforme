import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {
  ClassGroup,
  DayName,
  RoomAvailability,
  Semester,
  StudentCreateRequest,
  StudentGradeUpsertRequest,
  StudentOption,
  StudentUpdateRequest,
  StudentUser,
  StudentResults,
  TimetableSlot,
  TimetableSlotMoveRequest,
  WeeklyTimetable,
  CourseOption,
  TeacherCreateRequest,
  TeacherUpdateRequest,
  TeacherUser,
  TimetableChangeRequestCreateRequest,
  TimetableChangeRequestItem,
  TimetableChangeRequestStatus
} from './academic.models';

@Injectable({ providedIn: 'root' })
export class AcademicApiService {
  private readonly baseUrl = '/api/student/academic';
  private readonly adminCatalogUrl = '/api/admin/academic/catalog';
  private readonly adminTimetableUrl = '/api/admin/academic/timetable';
  private readonly adminGradesUrl = '/api/admin/academic/grades';
  private readonly adminStudentsUrl = '/api/admin/academic/students';
  private readonly adminTeachersUrl = '/api/admin/academic/teachers';
  private readonly teacherTimetableUrl = '/api/teacher/academic/timetable';
  private readonly teacherTimetableRequestsUrl = '/api/teacher/academic/timetable/change-requests';
  private readonly adminTimetableRequestsUrl = '/api/admin/academic/timetable/change-requests';

  constructor(private readonly http: HttpClient) {}

  timetable(studentId: number, year: number, semester: Semester): Observable<WeeklyTimetable> {
    return this.http.get<WeeklyTimetable>(`${this.baseUrl}/timetable`, {
      params: { studentId, year, semester }
    });
  }

  grades(studentId: number, department: string, year: number, semester: Semester): Observable<StudentResults> {
    const params = new HttpParams()
      .set('studentId', studentId)
      .set('department', department)
      .set('year', year)
      .set('semester', semester);
    return this.http.get<StudentResults>(`${this.baseUrl}/grades/results`, { params });
  }

  adminStudents(): Observable<StudentOption[]> {
    return this.http.get<StudentOption[]>(`${this.adminGradesUrl}/students`);
  }

  adminStudentUsers(): Observable<StudentUser[]> {
    return this.http.get<StudentUser[]>(this.adminStudentsUrl);
  }

  createStudent(request: StudentCreateRequest): Observable<StudentUser> {
    return this.http.post<StudentUser>(this.adminStudentsUrl, request);
  }

  updateStudent(studentId: number, request: StudentUpdateRequest): Observable<StudentUser> {
    return this.http.put<StudentUser>(`${this.adminStudentsUrl}/${studentId}`, request);
  }

  adminStudentResults(studentId: number, department: string, year: number, semester: Semester): Observable<StudentResults> {
    const params = new HttpParams()
      .set('department', department)
      .set('year', year)
      .set('semester', semester);
    return this.http.get<StudentResults>(`${this.adminGradesUrl}/students/${studentId}/results`, { params });
  }

  adminUpsertGrade(studentId: number, request: StudentGradeUpsertRequest): Observable<StudentResults> {
    return this.http.put<StudentResults>(`${this.adminGradesUrl}/students/${studentId}`, request);
  }

  adminDeleteGrade(gradeId: number): Observable<void> {
    return this.http.delete<void>(`${this.adminGradesUrl}/${gradeId}`);
  }

  adminClassGroups(department: string, year: number, semester: Semester): Observable<ClassGroup[]> {
    return this.http.get<ClassGroup[]>(`${this.adminCatalogUrl}/class-groups`, {
      params: { department, year, semester }
    });
  }

  adminClassTimetable(classGroupId: number): Observable<WeeklyTimetable> {
    return this.http.get<WeeklyTimetable>(`${this.adminTimetableUrl}/class-groups/${classGroupId}`);
  }

  moveSlot(slotId: number, request: TimetableSlotMoveRequest): Observable<TimetableSlot> {
    return this.http.patch<TimetableSlot>(`${this.adminTimetableUrl}/slots/${slotId}/move`, request);
  }

  deleteSlot(slotId: number): Observable<void> {
    return this.http.delete<void>(`${this.adminTimetableUrl}/slots/${slotId}`);
  }

  rooms(): Observable<string[]> {
    return this.http.get<string[]>(`${this.adminTimetableUrl}/rooms`);
  }

  courses(department: string): Observable<CourseOption[]> {
    return this.http.get<CourseOption[]>(`${this.adminCatalogUrl}/courses`, { params: { department } });
  }

  adminTeachers(): Observable<TeacherUser[]> {
    return this.http.get<TeacherUser[]>(this.adminTeachersUrl);
  }

  createTeacher(request: TeacherCreateRequest): Observable<TeacherUser> {
    return this.http.post<TeacherUser>(this.adminTeachersUrl, request);
  }

  updateTeacher(teacherId: number, request: TeacherUpdateRequest): Observable<TeacherUser> {
    return this.http.put<TeacherUser>(`${this.adminTeachersUrl}/${teacherId}`, request);
  }

  teacherTimetable(year: number, semester: Semester): Observable<TimetableSlot[]> {
    return this.http.get<TimetableSlot[]>(this.teacherTimetableUrl, { params: { year, semester } });
  }


  teacherChangeRequests(): Observable<TimetableChangeRequestItem[]> {
    return this.http.get<TimetableChangeRequestItem[]>(this.teacherTimetableRequestsUrl);
  }

  createTeacherChangeRequest(request: TimetableChangeRequestCreateRequest): Observable<TimetableChangeRequestItem> {
    return this.http.post<TimetableChangeRequestItem>(this.teacherTimetableRequestsUrl, request);
  }

  adminChangeRequests(status?: TimetableChangeRequestStatus): Observable<TimetableChangeRequestItem[]> {
    const params = status ? new HttpParams().set('status', status) : undefined;
    return this.http.get<TimetableChangeRequestItem[]>(this.adminTimetableRequestsUrl, { params });
  }

  approveChangeRequest(id: number, message?: string): Observable<TimetableChangeRequestItem> {
    return this.http.post<TimetableChangeRequestItem>(`${this.adminTimetableRequestsUrl}/${id}/approve`, { message: message ?? '' });
  }

  rejectChangeRequest(id: number, message?: string): Observable<TimetableChangeRequestItem> {
    return this.http.post<TimetableChangeRequestItem>(`${this.adminTimetableRequestsUrl}/${id}/reject`, { message: message ?? '' });
  }

  availableRooms(dayOfWeek: DayName, startTime: string, endTime: string, excludedSlotId?: number): Observable<string[]> {
    let params = new HttpParams()
      .set('dayOfWeek', dayOfWeek)
      .set('startTime', startTime)
      .set('endTime', endTime);
    if (excludedSlotId) {
      params = params.set('excludedSlotId', excludedSlotId);
    }
    return this.http.get<string[]>(`${this.teacherTimetableUrl}/rooms/available`, { params });
  }

  adminAvailableRooms(dayOfWeek: DayName, startTime: string, endTime: string, excludedSlotId?: number): Observable<string[]> {
    let params = new HttpParams()
      .set('dayOfWeek', dayOfWeek)
      .set('startTime', startTime)
      .set('endTime', endTime);
    if (excludedSlotId) {
      params = params.set('excludedSlotId', excludedSlotId);
    }
    return this.http.get<string[]>(`${this.adminTimetableUrl}/rooms/available`, { params });
  }

  roomAvailability(room: string, dayOfWeek: DayName, startTime: string, endTime: string, excludedSlotId?: number): Observable<RoomAvailability> {
    let params = new HttpParams()
      .set('room', room)
      .set('dayOfWeek', dayOfWeek)
      .set('startTime', startTime)
      .set('endTime', endTime);
    if (excludedSlotId) {
      params = params.set('excludedSlotId', excludedSlotId);
    }
    return this.http.get<RoomAvailability>(`${this.adminTimetableUrl}/rooms/availability`, { params });
  }
}
