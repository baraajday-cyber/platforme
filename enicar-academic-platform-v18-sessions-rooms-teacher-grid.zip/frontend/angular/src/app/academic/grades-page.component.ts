import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { finalize } from 'rxjs';
import { AuthService } from '../auth/auth.service';
import { AcademicApiService } from './academic-api.service';
import { Semester, StudentResults } from './academic.models';

@Component({
  selector: 'app-grades-page',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <section class="card page-card">
      <header class="page-head">
        <div><span class="badge">Notes</span><h2>Mes notes</h2></div>
        <div class="filters"><select class="select" [(ngModel)]="semester"><option value="S1">S1</option><option value="S2">S2</option><option value="S3">S3</option><option value="S4">S4</option></select><button class="btn" (click)="load()" [disabled]="loading">Charger</button></div>
      </header>

      <div class="alert danger" *ngIf="error"><span>{{ error }}</span></div>

      <section class="summary grid three" *ngIf="results">
        <article><span>Moyenne finale</span><strong>{{ numberOrDash(results.semester?.semesterAverage) }}</strong></article>
        <article><span>Credits valides</span><strong>{{ results.semester?.totalCredits ?? 0 }}</strong></article>
        <article><span>Statut</span><strong>{{ semesterStatus() }}</strong></article>
      </section>

      <div class="table-wrap" *ngIf="results && !loading; else loadingTpl">
        <table>
          <thead><tr><th>Matiere</th><th>Module</th><th>CC</th><th>Exam</th><th>TP</th><th>Moyenne</th><th>Statut</th></tr></thead>
          <tbody>
            <tr *ngFor="let grade of results.grades">
              <td><strong>{{ grade.subjectName }}</strong></td><td>{{ grade.moduleName }}</td><td>{{ numberOrDash(grade.ccGrade) }}</td><td>{{ numberOrDash(grade.examGrade) }}</td><td>{{ numberOrDash(grade.tpGrade) }}</td><td><strong>{{ numberOrDash(grade.subjectAverage) }}</strong></td><td><span class="badge" [class.success]="grade.validated" [class.warning]="!grade.validated">{{ grade.validated ? 'Validee' : (grade.complete ? 'Non validee' : 'Incomplete') }}</span></td>
            </tr>
          </tbody>
        </table>
      </div>

      <section class="modules" *ngIf="results?.modules?.length">
        <article class="module-card" *ngFor="let module of results?.modules">
          <div><h3>{{ module.moduleName }}</h3><p>{{ numberOrDash(module.moduleAverage) }} · {{ module.creditsEarned }}/{{ module.moduleCredits }} credits</p></div>
          <span class="badge" [class.success]="module.validated" [class.warning]="!module.validated">{{ module.validated ? 'Valide' : 'En cours' }}</span>
        </article>
      </section>

      <ng-template #loadingTpl><p class="empty">{{ loading ? 'Chargement...' : 'Aucune note' }}</p></ng-template>
    </section>
  `,
  styles: [`
    .page-card { padding: 1.2rem; display: grid; gap: 1rem; }
    .page-head { display: flex; justify-content: space-between; align-items: flex-start; gap: 1rem; }
    h2 { margin: .35rem 0 0; font-size: 2rem; letter-spacing: -.05em; }
    .filters { display: flex; gap: .6rem; align-items: center; }
    .summary article { padding: 1rem; border-radius: 20px; background: #f8fafc; border: 1px solid var(--line); box-shadow: var(--shadow-soft); }
    .summary span { color: var(--muted); }
    .summary strong { display: block; margin-top: .35rem; font-size: 1.85rem; letter-spacing: -.04em; }
    .modules { display: grid; grid-template-columns: repeat(2, 1fr); gap: .8rem; }
    .module-card { padding: 1rem; border-radius: 22px; border: 1px solid var(--line); background: #fff; display: flex; justify-content: space-between; gap: 1rem; box-shadow: var(--shadow-soft); }
    h3 { margin: 0; }
    p { margin: .25rem 0 0; color: var(--muted); }
    @media (max-width: 900px) { .page-head, .module-card { display: grid; } .modules { grid-template-columns: 1fr; } }
  `]
})
export class GradesPageComponent implements OnInit {
  results?: StudentResults;
  loading = false;
  error = '';
  semester: Semester = 'S4';

  constructor(private readonly auth: AuthService, private readonly api: AcademicApiService) {}
  ngOnInit(): void {
    const user = this.auth.user();
    this.semester = user?.defaultSemester ?? this.semester;
    this.load();
  }
  load(): void {
    const studentId = this.auth.studentId();
    if (!studentId) { this.error = 'Profil etudiant requis.'; return; }
    const year = this.semester === 'S1' || this.semester === 'S2' ? 1 : 2;
    this.loading = true;
    this.error = '';
    this.api.grades(studentId, 'Informatique', year, this.semester)
      .pipe(finalize(() => this.loading = false))
      .subscribe({ next: results => this.results = results, error: () => this.error = 'Notes indisponibles.' });
  }
  semesterStatus(): string {
    if (!this.results?.semester?.complete) {
      return 'Non finalisee';
    }
    return this.results.semester.validated ? 'Valide' : 'Non valide';
  }

  numberOrDash(value: number | string | undefined | null): string {
    if (value === undefined || value === null) return '-';
    const n = Number(value);
    return Number.isFinite(n) ? n.toFixed(2) : String(value);
  }
}
