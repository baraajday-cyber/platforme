import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { finalize } from 'rxjs';
import { AcademicApiService } from './academic-api.service';
import { Semester, StudentGrade, StudentGradeUpsertRequest, StudentOption, StudentResults } from './academic.models';

type EditableGrade = StudentGrade & { saving?: boolean; deleting?: boolean; };
type GroupOption = { id: number; name: string; count: number };

@Component({
  selector: 'app-admin-grades-manager',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <section class="card grades-admin-page">
      <header class="page-head">
        <div><span class="badge warning">Notes</span><h2>Saisie notes</h2></div>
        <div class="quick-summary" *ngIf="results?.semester"><span>Moyenne finale</span><strong>{{ numberOrDash(results?.semester?.semesterAverage) }}</strong><small>{{ results?.semester?.totalCredits ?? 0 }} credits</small></div>
      </header>

      <div class="filters-panel">
        <label>Groupe
          <select class="select" [(ngModel)]="selectedGroupId" (ngModelChange)="onGroupChange()">
            <option *ngFor="let group of groups" [ngValue]="group.id">{{ group.name }} · {{ group.count }}</option>
          </select>
        </label>
        <label>Etudiant
          <select class="select" [(ngModel)]="selectedStudentId" (ngModelChange)="onStudentChange()">
            <option *ngFor="let student of filteredStudents" [ngValue]="student.id">{{ student.fullName }}</option>
          </select>
        </label>
        <label>Annee
          <select class="select" [(ngModel)]="year" (ngModelChange)="onYearChange()"><option [ngValue]="1">1</option><option [ngValue]="2">2</option></select>
        </label>
        <label>Semestre
          <select class="select" [(ngModel)]="semester" (ngModelChange)="reloadGroups()"><option value="S1">S1</option><option value="S2">S2</option><option value="S3">S3</option><option value="S4">S4</option></select>
        </label>
        <button class="btn" type="button" (click)="loadResults()" [disabled]="loading || !selectedStudentId">Charger</button>
      </div>

      <div class="alert danger" *ngIf="error"><span>{{ error }}</span></div>
      <div class="alert success" *ngIf="success"><span>{{ success }}</span></div>

      <section class="student-card" *ngIf="selectedStudent">
        <div><span class="badge info">{{ selectedStudent.code }}</span><h3>{{ selectedStudent.fullName }}</h3><p>{{ selectedStudent.classGroupName }} · {{ semester }}</p></div>
        <button class="btn secondary" type="button" (click)="applyStudentDefaults(); reloadGroups(); loadResults()">Defaut</button>
      </section>

      <div class="table-wrap grade-table" *ngIf="rows.length; else emptyTpl">
        <table>
          <thead><tr><th>Matiere</th><th>Module</th><th>CC</th><th>TP</th><th>Examen</th><th>Moyenne</th><th>Statut</th><th>Action</th></tr></thead>
          <tbody>
            <tr *ngFor="let row of rows">
              <td><strong>{{ row.subjectName }}</strong></td>
              <td>{{ row.moduleName }}</td>
              <td><input class="grade-input" type="number" min="0" max="20" step="0.25" [(ngModel)]="row.ccGrade" /></td>
              <td><input class="grade-input" type="number" min="0" max="20" step="0.25" [(ngModel)]="row.tpGrade" /></td>
              <td><input class="grade-input" type="number" min="0" max="20" step="0.25" [(ngModel)]="row.examGrade" /></td>
              <td><strong>{{ numberOrDash(row.subjectAverage) }}</strong></td>
              <td><span class="badge" [class.success]="row.validated" [class.warning]="!row.validated && row.complete" [class.danger]="!row.complete">{{ row.validated ? 'Validee' : (row.complete ? 'Non validee' : 'Incomplete') }}</span></td>
              <td class="actions"><button class="mini" type="button" (click)="saveRow(row)" [disabled]="row.saving">Enregistrer</button><button class="mini danger" *ngIf="row.id" type="button" (click)="deleteRow(row)" [disabled]="row.deleting">Effacer</button></td>
            </tr>
          </tbody>
        </table>
      </div>

      <section class="modules" *ngIf="results?.modules?.length">
        <article class="module-card" *ngFor="let module of results?.modules">
          <div><h3>{{ module.moduleName }}</h3><p>{{ numberOrDash(module.moduleAverage) }} · {{ module.creditsEarned }}/{{ module.moduleCredits }} credits</p></div>
          <span class="badge" [class.success]="module.validated" [class.warning]="!module.validated">{{ module.validated ? 'Valide' : 'En cours' }}</span>
        </article>
      </section>

      <ng-template #emptyTpl><p class="empty">Aucune matiere</p></ng-template>
    </section>
  `,
  styles: [`
    .grades-admin-page { padding: 1.2rem; display: grid; gap: 1rem; }
    .page-head { display: flex; align-items: stretch; justify-content: space-between; gap: 1rem; }
    h2 { margin: .35rem 0 0; font-size: clamp(1.65rem, 3vw, 2.35rem); letter-spacing: -.05em; }
    h3 { margin: .3rem 0; }
    .quick-summary { min-width: 210px; border-radius: 24px; padding: 1rem; background: linear-gradient(135deg, #eef2ff, #f5f3ff); border: 1px solid #ddd6fe; display: grid; gap: .15rem; align-content: center; }
    .quick-summary span, .quick-summary small { color: var(--muted); font-weight: 800; }
    .quick-summary strong { font-size: 2.25rem; letter-spacing: -.06em; color: var(--primary-dark); }
    .filters-panel { display: grid; grid-template-columns: 1fr 1.4fr .45fr .55fr auto; gap: .75rem; align-items: end; padding: 1rem; border: 1px solid var(--line); border-radius: 24px; background: #f8fafc; }
    .filters-panel label { display: grid; gap: .35rem; color: #334155; font-size: .82rem; font-weight: 900; }
    .student-card { display: flex; justify-content: space-between; align-items: center; gap: 1rem; padding: 1rem; border-radius: 24px; background: linear-gradient(135deg, #fff, #f8fbff); border: 1px solid var(--line); box-shadow: var(--shadow-soft); }
    .student-card p { margin: .15rem 0 0; color: var(--muted); }
    .grade-table table { min-width: 1060px; }
    .grade-input { width: 6.8rem; border: 1px solid var(--line); border-radius: 12px; padding: .55rem .65rem; outline: none; }
    .grade-input:focus { border-color: var(--primary); box-shadow: 0 0 0 3px rgba(37,99,235,.12); }
    .actions { display: flex; gap: .45rem; flex-wrap: wrap; }
    .mini { border: 0; border-radius: 999px; padding: .55rem .75rem; font-weight: 900; background: #e0f2fe; color: #075985; cursor: pointer; }
    .mini.danger { background: #fee2e2; color: #991b1b; }
    .mini:disabled { opacity: .55; cursor: not-allowed; }
    .modules { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: .85rem; }
    .module-card { padding: 1rem; border-radius: 22px; border: 1px solid var(--line); background: #fff; box-shadow: var(--shadow-soft); display: flex; align-items: center; justify-content: space-between; gap: .75rem; }
    .module-card p { color: var(--muted); margin: .25rem 0 0; }
    @media (max-width: 1180px) { .filters-panel { grid-template-columns: 1fr 1fr; } .page-head, .student-card { display: grid; } .modules { grid-template-columns: 1fr; } }
    @media (max-width: 720px) { .filters-panel { grid-template-columns: 1fr; } }
  `]
})
export class AdminGradesManagerComponent implements OnInit {
  students: StudentOption[] = [];
  groups: GroupOption[] = [];
  selectedGroupId?: number;
  selectedStudentId?: number;
  filteredStudents: StudentOption[] = [];
  department = 'Informatique';
  year = 2;
  semester: Semester = 'S4';
  results?: StudentResults;
  rows: EditableGrade[] = [];
  loading = false;
  error = '';
  success = '';

  constructor(private readonly api: AcademicApiService) {}
  ngOnInit(): void {
    this.api.adminStudents().subscribe({
      next: students => {
        this.students = students.slice().sort((a, b) => a.fullName.localeCompare(b.fullName, 'fr'));
        this.reloadGroups();
      },
      error: () => this.error = 'Etudiants indisponibles.'
    });
  }
  get selectedStudent(): StudentOption | undefined { return this.students.find(student => student.id === this.selectedStudentId); }
  onYearChange(): void { this.semester = this.year === 1 ? 'S2' : 'S4'; this.reloadGroups(); }
  reloadGroups(): void {
    const eligible = this.students.filter(s => s.defaultYear === this.year && s.defaultSemester === this.semester);
    const byGroup = new Map<number, GroupOption>();
    eligible.forEach(student => {
      const current = byGroup.get(student.classGroupId) ?? { id: student.classGroupId, name: student.classGroupName, count: 0 };
      current.count += 1;
      byGroup.set(student.classGroupId, current);
    });
    this.groups = Array.from(byGroup.values()).sort((a, b) => a.name.localeCompare(b.name, 'fr'));
    if (!this.selectedGroupId || !this.groups.some(g => g.id === this.selectedGroupId)) {
      this.selectedGroupId = this.groups[0]?.id;
    }
    this.refreshFilteredStudents();
  }
  refreshFilteredStudents(): void {
    this.filteredStudents = this.students
      .filter(student => student.defaultYear === this.year && student.defaultSemester === this.semester && student.classGroupId === this.selectedGroupId)
      .sort((a, b) => a.fullName.localeCompare(b.fullName, 'fr'));
    if (!this.selectedStudentId || !this.filteredStudents.some(student => student.id === this.selectedStudentId)) {
      this.selectedStudentId = this.filteredStudents[0]?.id;
    }
    if (this.selectedStudentId) {
      this.loadResults();
    } else {
      this.results = undefined;
      this.rows = [];
    }
  }
  onGroupChange(): void { this.refreshFilteredStudents(); }
  onStudentChange(): void { this.applyStudentDefaults(false); this.loadResults(); }
  applyStudentDefaults(updateFilters = true): void {
    const student = this.selectedStudent; if (!student) return;
    this.department = student.defaultDepartment; this.year = student.defaultYear; this.semester = student.defaultSemester;
    if (updateFilters) {
      this.selectedGroupId = student.classGroupId;
      this.reloadGroups();
    }
  }
  loadResults(): void {
    if (!this.selectedStudentId) return;
    this.loading = true; this.error = ''; this.success = '';
    this.api.adminStudentResults(this.selectedStudentId, this.department, this.year, this.semester).pipe(finalize(() => this.loading = false)).subscribe({
      next: results => { this.results = results; this.rows = results.grades.map(row => ({ ...row })); },
      error: err => { this.results = undefined; this.rows = []; this.error = err?.error?.message ?? 'Notes indisponibles.'; }
    });
  }
  saveRow(row: EditableGrade): void {
    if (!this.selectedStudentId) return;
    row.saving = true; this.error = ''; this.success = '';
    const request: StudentGradeUpsertRequest = { department: this.department, year: this.year, semester: this.semester, subjectId: row.subjectId, ccGrade: this.cleanGrade(row.ccGrade), examGrade: this.cleanGrade(row.examGrade), tpGrade: this.cleanGrade(row.tpGrade) };
    this.api.adminUpsertGrade(this.selectedStudentId, request).pipe(finalize(() => row.saving = false)).subscribe({
      next: results => { this.results = results; this.rows = results.grades.map(item => ({ ...item })); this.success = 'Note enregistree.'; },
      error: err => this.error = err?.error?.message ?? 'Sauvegarde impossible.'
    });
  }
  deleteRow(row: EditableGrade): void {
    if (!row.id || !confirm(`Effacer ${row.subjectName} ?`)) return;
    row.deleting = true; this.error = ''; this.success = '';
    this.api.adminDeleteGrade(row.id).pipe(finalize(() => row.deleting = false)).subscribe({
      next: () => { this.success = 'Note effacee.'; this.loadResults(); },
      error: err => this.error = err?.error?.message ?? 'Suppression impossible.'
    });
  }
  cleanGrade(value: number | string | undefined | null): number | null {
    if (value === undefined || value === null || value === '') return null;
    const numeric = Number(value);
    return Number.isFinite(numeric) ? numeric : null;
  }
  numberOrDash(value?: number | null): string { return value === undefined || value === null ? '-' : Number(value).toFixed(2).replace(/\.00$/, ''); }
}
