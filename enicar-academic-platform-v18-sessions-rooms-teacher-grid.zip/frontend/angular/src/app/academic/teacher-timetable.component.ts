import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { finalize } from 'rxjs';
import { AcademicApiService } from './academic-api.service';
import { DayName, Semester, TimetableChangeRequestItem, TimetableSlot } from './academic.models';

interface SessionRow {
  label: string;
  start: string;
  end: string;
}

interface TeacherRequestDraft {
  slot: TimetableSlot;
  dayOfWeek: DayName;
  startTime: string;
  endTime: string;
  sessionKey: string;
  room: string;
  reason: string;
}

@Component({
  selector: 'app-teacher-timetable',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <section class="card teacher-time">
      <header class="page-head">
        <div><span class="badge info">Enseignant</span><h2>Mon emploi du temps</h2></div>
        <div class="filters">
          <select class="select" [(ngModel)]="year" (ngModelChange)="semester = year === 1 ? 'S2' : 'S4'; load()"><option [ngValue]="1">Annee 1</option><option [ngValue]="2">Annee 2</option></select>
          <select class="select" [(ngModel)]="semester" (ngModelChange)="load()"><option value="S1">S1</option><option value="S2">S2</option><option value="S3">S3</option><option value="S4">S4</option></select>
          <button class="btn" (click)="load()">Charger</button>
        </div>
      </header>

      <div class="alert danger" *ngIf="error"><span>{{ error }}</span></div>
      <div class="alert success" *ngIf="success"><span>{{ success }}</span></div>

      <section class="request-layout" *ngIf="draft">
        <div class="card request-panel">
          <span class="badge warning">Demande de changement</span>
          <h3>{{ draft.slot.courseName }}</h3>
          <p>{{ draft.slot.classGroupName }} · {{ dayLabel(draft.slot.dayOfWeek) }} {{ draft.slot.startTime }}-{{ draft.slot.endTime }} · {{ draft.slot.room }}</p>
          <label>Jour
            <select class="select" [(ngModel)]="draft.dayOfWeek" (ngModelChange)="loadAvailableRooms()">
              <option *ngFor="let day of days" [value]="day">{{ dayLabel(day) }}</option>
            </select>
          </label>
          <label>Creneau
            <select class="select" [(ngModel)]="draft.sessionKey" (ngModelChange)="setDraftSession($event)">
              <option *ngFor="let row of timeRows" [value]="sessionKey(row.start, row.end)">{{ row.label }} · {{ row.start }}-{{ row.end }}</option>
            </select>
          </label>
          <label>Salle libre
            <select class="select" [(ngModel)]="draft.room">
              <option *ngFor="let room of availableRooms" [value]="room">{{ room }}</option>
            </select>
            <small *ngIf="availableRooms.length === 0">Aucune salle libre pour ce creneau.</small>
          </label>
          <label>Motif<input class="input" [(ngModel)]="draft.reason" placeholder="Rattrapage, contrainte pedagogique..." /></label>
          <div class="actions"><button class="btn" (click)="sendRequest()" [disabled]="saving || !draft.room || availableRooms.length === 0">Envoyer a l'administration</button><button class="btn ghost" (click)="draft = undefined">Annuler</button></div>
        </div>
      </section>

      <div class="timetable-scroll" *ngIf="slots.length; else emptyTpl">
        <div class="week-grid">
          <div class="grid-head time-head">Heure</div>
          <div class="grid-head" *ngFor="let day of days">{{ dayLabel(day) }}</div>
          <ng-container *ngFor="let row of timeRows">
            <div class="time-cell"><strong>{{ row.label }}</strong><small>{{ row.start }} - {{ row.end }}</small></div>
            <div class="course-cell" *ngFor="let day of days">
              <article class="course-card" *ngFor="let slot of slotsAt(day, row.start)">
                <strong>{{ slot.courseName }}</strong>
                <span>{{ slot.classGroupName }}</span>
                <small>{{ slot.room }}</small>
                <button class="mini" type="button" (click)="openRequest(slot)">Demander</button>
              </article>
              <span class="free" *ngIf="slotsAt(day, row.start).length === 0">Libre</span>
            </div>
          </ng-container>
        </div>
      </div>
      <ng-template #emptyTpl><p class="empty">Aucune seance affectee.</p></ng-template>

      <section class="request-history" *ngIf="requests.length">
        <h3>Mes demandes</h3>
        <article *ngFor="let request of requests" class="history-item" [class.approved]="request.status === 'APPROVED'" [class.rejected]="request.status === 'REJECTED'">
          <div><strong>{{ request.courseName }}</strong><small>{{ dayLabel(request.requestedDayOfWeek) }} {{ request.requestedStartTime }}-{{ request.requestedEndTime }} · {{ request.requestedRoom }}</small></div>
          <span>{{ statusLabel(request.status) }}</span>
        </article>
      </section>
    </section>
  `,
  styles: [`
    .teacher-time { padding: 1.2rem; display: grid; gap: 1rem; overflow: hidden; }
    .page-head { display: flex; justify-content: space-between; gap: 1rem; align-items: start; }
    h2 { margin: .35rem 0 0; font-size: clamp(1.65rem, 3vw, 2.35rem); letter-spacing: -.05em; }
    .filters { display: flex; gap: .65rem; flex-wrap: wrap; }
    .timetable-scroll { overflow-x: auto; padding-bottom: .45rem; }
    .week-grid { min-width: 1160px; display: grid; grid-template-columns: 92px repeat(6, 172px); gap: .62rem; align-items: stretch; }
    .grid-head { padding: .85rem; border-radius: 18px; text-align: center; color: white; font-weight: 950; background: linear-gradient(135deg, #2563eb, #0f766e); }
    .time-head { background: #0f172a; }
    .time-cell { min-height: 128px; padding: .85rem; border-radius: 18px; border: 1px solid var(--line); background: #f8fafc; display: grid; align-content: start; }
    .time-cell strong { font-size: .95rem; }
    .time-cell small { color: var(--muted); font-weight: 800; }
    .course-cell { min-height: 128px; padding: .45rem; border-radius: 18px; border: 1px dashed #cbd5e1; background: rgba(248,250,252,.8); display: grid; gap: .45rem; align-content: start; }
    .course-card { padding: .72rem; border-radius: 16px; border: 1px solid #bfdbfe; background: linear-gradient(135deg, #fff, #eff6ff); display: grid; gap: .22rem; box-shadow: 0 8px 18px rgba(37,99,235,.08); }
    .course-card strong { font-size: .9rem; line-height: 1.22; }
    .course-card span { color: #475569; font-size: .82rem; }
    .course-card small { color: #1d4ed8; font-weight: 900; }
    .free { color: #94a3b8; justify-self: center; align-self: center; font-weight: 850; }
    .mini { border: 0; border-radius: 999px; padding: .45rem .62rem; font-weight: 900; background: #e0f2fe; color: #075985; cursor: pointer; justify-self: start; }
    .request-panel { padding: 1rem; display: grid; gap: .7rem; background: #f8fafc; }
    .request-panel label { display: grid; gap: .35rem; color: var(--muted); font-weight: 900; }
    .request-panel p { color: var(--muted); font-weight: 800; }
    .actions { display: flex; gap: .55rem; flex-wrap: wrap; }
    .request-history { display: grid; gap: .6rem; }
    .history-item { padding: 1rem; border-radius: 22px; border: 1px solid var(--line); background: #fff; box-shadow: var(--shadow-soft); display: grid; grid-template-columns: 1fr auto; align-items: center; gap: .55rem; }
    .history-item small { display: block; color: var(--muted); margin-top: .2rem; }
    .history-item span { border-radius: 999px; padding: .35rem .65rem; background: #fef3c7; color: #92400e; font-weight: 950; }
    .history-item.approved span { background: #dcfce7; color: #166534; }
    .history-item.rejected span { background: #fee2e2; color: #991b1b; }
    @media (max-width: 980px) { .page-head, .filters { display: grid; } }
  `]
})
export class TeacherTimetableComponent implements OnInit {
  year = 2;
  semester: Semester = 'S4';
  slots: TimetableSlot[] = [];
  requests: TimetableChangeRequestItem[] = [];
  availableRooms: string[] = [];
  draft?: TeacherRequestDraft;
  error = '';
  success = '';
  saving = false;
  readonly days: DayName[] = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
  readonly timeRows: SessionRow[] = [
    { label: 'S1 matin', start: '08:30', end: '10:00' },
    { label: 'S2 matin', start: '10:10', end: '11:40' },
    { label: 'S3 apres-midi', start: '12:30', end: '14:00' },
    { label: 'S4 apres-midi', start: '14:10', end: '15:40' },
    { label: 'S5 apres-midi', start: '15:50', end: '17:20' }
  ];

  constructor(private readonly api: AcademicApiService) {}
  ngOnInit(): void { this.load(); }

  load(): void {
    this.error = ''; this.success = '';
    this.api.teacherTimetable(this.year, this.semester).subscribe({ next: slots => this.slots = slots, error: () => this.error = 'Emploi indisponible.' });
    this.api.teacherChangeRequests().subscribe({ next: requests => this.requests = requests, error: () => this.requests = [] });
  }

  openRequest(slot: TimetableSlot): void {
    const session = this.closestSession(slot.startTime.slice(0, 5), slot.endTime.slice(0, 5));
    this.draft = { slot, dayOfWeek: slot.dayOfWeek, startTime: session.start, endTime: session.end, sessionKey: this.sessionKey(session.start, session.end), room: slot.room, reason: 'Demande de rattrapage ou changement de seance' };
    this.loadAvailableRooms();
  }

  setDraftSession(key: string): void {
    if (!this.draft) return;
    const [start, end] = key.split('|');
    this.draft.startTime = start;
    this.draft.endTime = end;
    this.loadAvailableRooms();
  }

  loadAvailableRooms(): void {
    if (!this.draft) return;
    const d = this.draft;
    this.api.availableRooms(d.dayOfWeek, d.startTime, d.endTime, d.slot.id).subscribe({
      next: rooms => { this.availableRooms = rooms; if (!rooms.includes(d.room)) d.room = rooms[0] ?? ''; },
      error: () => { this.availableRooms = []; d.room = ''; this.error = 'Liste des salles indisponible.'; }
    });
  }

  sendRequest(): void {
    if (!this.draft) return;
    this.saving = true; this.error = ''; this.success = '';
    const d = this.draft;
    this.api.createTeacherChangeRequest({ slotId: d.slot.id, dayOfWeek: d.dayOfWeek, startTime: d.startTime, endTime: d.endTime, room: d.room, reason: d.reason })
      .pipe(finalize(() => this.saving = false))
      .subscribe({
        next: () => { this.success = 'Demande envoyee a l administration.'; this.draft = undefined; this.load(); },
        error: err => this.error = err?.error?.message ?? err?.error?.detail ?? 'Demande impossible.'
      });
  }

  slotsAt(day: DayName, start: string): TimetableSlot[] { return this.slots.filter(slot => slot.dayOfWeek === day && slot.startTime?.slice(0, 5) === start); }
  sessionKey(start: string, end: string): string { return `${start}|${end}`; }
  closestSession(start: string, end: string): SessionRow { return this.timeRows.find(row => row.start === start && row.end === end) ?? this.timeRows[2]; }
  dayLabel(day: string): string { return ({ MONDAY: 'Lundi', TUESDAY: 'Mardi', WEDNESDAY: 'Mercredi', THURSDAY: 'Jeudi', FRIDAY: 'Vendredi', SATURDAY: 'Samedi' } as Record<string, string>)[day] ?? day; }
  statusLabel(status: string): string { return ({ PENDING: 'En attente', APPROVED: 'Acceptee', REJECTED: 'Refusee' } as Record<string, string>)[status] ?? status; }
}
