import { CommonModule } from '@angular/common';
import { Component, OnInit, computed, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { catchError, finalize, forkJoin, of } from 'rxjs';
import { AuthService } from '../auth/auth.service';
import { CommunicationApiService } from '../communication/communication-api.service';
import { AcademicApiService } from './academic-api.service';
import { ClassGroup, StudentResults, StudentUser, TimetableSlot, WeeklyTimetable } from './academic.models';

interface GroupBlock {
  group: ClassGroup;
  students: StudentUser[];
}

@Component({
  selector: 'app-academic-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <section class="dashboard">
      <ng-container *ngIf="isAdmin(); else studentDashboard">
        <section class="grid four">
          <article class="kpi card"><span>Etudiants</span><strong>{{ students.length }}</strong></article>
          <article class="kpi card"><span>Groupes</span><strong>8</strong></article>
          <article class="kpi card"><span>Actifs</span><strong>{{ activeStudents }}</strong></article>
          <article class="kpi card"><span>Notifications</span><strong>{{ unreadCount }}</strong></article>
        </section>

        <section class="card group-board">
          <header class="section-head">
            <div><span class="badge">Groupes</span><h2>Etudiants par classe</h2></div>
            <a class="btn secondary" routerLink="/admin-students">Gerer</a>
          </header>
          <div class="group-grid">
            <article class="group-card" *ngFor="let block of groupBlocks">
              <div class="group-title"><strong>{{ block.group.name }}</strong><span>{{ block.students.length }}</span></div>
              <ol *ngIf="block.students.length; else emptyGroup">
                <li *ngFor="let student of block.students">{{ student.fullName }}</li>
              </ol>
              <ng-template #emptyGroup><p>Aucun etudiant</p></ng-template>
            </article>
          </div>
        </section>
      </ng-container>

      <ng-template #studentDashboard>
        <ng-container *ngIf="isTeacherOnly(); else studentView">
          <section class="student-hero card">
            <div><span class="badge info">Enseignant</span><h2>{{ user()?.displayName }}</h2></div>
            <div class="hero-actions"><a class="btn" routerLink="/teacher-grades">Saisir les notes</a></div>
          </section>
        </ng-container>

        <ng-template #studentView>
        <section class="student-hero card">
          <div>
            <span class="badge info">{{ user()?.defaultClassGroupName || 'Etudiant' }}</span>
            <h2>{{ user()?.displayName }}</h2>
          </div>
          <div class="hero-actions">
            <a class="btn" routerLink="/timetable">Mon EDT</a>
            <a class="btn secondary" routerLink="/grades">Mes notes</a>
          </div>
        </section>

        <section class="grid three">
          <article class="kpi card"><span>Moyenne</span><strong>{{ numberOrDash(results?.semester?.semesterAverage) }}</strong></article>
          <article class="kpi card"><span>Credits</span><strong>{{ results?.semester?.totalCredits ?? 0 }}</strong></article>
          <article class="kpi card"><span>Notifications</span><strong>{{ unreadCount }}</strong></article>
        </section>

        <section class="card compact-list">
          <header class="section-head"><div><span class="badge">Prochains cours</span><h2>Cette semaine</h2></div></header>
          <div class="slot-list" *ngIf="nextSlots.length; else noSlots">
            <div *ngFor="let slot of nextSlots"><strong>{{ slot.courseName }}</strong><span>{{ dayLabel(slot.dayOfWeek) }} · {{ slot.startTime }} · {{ slot.room }}</span></div>
          </div>
          <ng-template #noSlots><p class="empty small">Aucun cours charge</p></ng-template>
        </section>
        </ng-template>
      </ng-template>
    </section>
  `,
  styles: [`
    .dashboard { display: grid; gap: 1rem; }
    .section-head { display: flex; justify-content: space-between; align-items: center; gap: 1rem; margin-bottom: 1rem; }
    h2 { margin: .35rem 0 0; font-size: clamp(1.7rem, 3vw, 2.25rem); letter-spacing: -.05em; }
    .kpi { padding: 1rem; display: grid; gap: .25rem; }
    .kpi span { color: var(--muted); font-weight: 900; }
    .kpi strong { font-size: 2.15rem; line-height: 1; letter-spacing: -.05em; }
    .group-board { padding: 1.1rem; }
    .group-grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: .8rem; }
    .group-card { min-height: 190px; padding: .95rem; border-radius: 22px; border: 1px solid var(--line); background: #fff; box-shadow: var(--shadow-soft); }
    .group-title { display: flex; justify-content: space-between; align-items: center; gap: .7rem; margin-bottom: .7rem; }
    .group-title strong { font-size: 1.05rem; }
    .group-title span { width: 2.1rem; height: 2.1rem; display: grid; place-items: center; border-radius: 999px; background: #eef2ff; color: #1d4ed8; font-weight: 950; }
    ol { margin: 0; padding-left: 1.1rem; display: grid; gap: .35rem; color: #334155; }
    p { margin: 0; color: var(--muted); }
    .student-hero { padding: 1.25rem; display: flex; justify-content: space-between; align-items: center; gap: 1rem; }
    .student-hero h2 { font-size: clamp(2rem, 5vw, 3.5rem); }
    .hero-actions { display: flex; gap: .7rem; flex-wrap: wrap; }
    .compact-list { padding: 1.1rem; }
    .slot-list { display: grid; gap: .65rem; grid-template-columns: repeat(2, minmax(0, 1fr)); }
    .slot-list div { padding: .9rem; border-radius: 18px; background: #f8fafc; border: 1px solid var(--line); display: grid; gap: .2rem; }
    .slot-list span { color: var(--muted); }
    .empty.small { padding: 1.2rem; }
    @media (max-width: 1200px) { .group-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); } }
    @media (max-width: 780px) { .group-grid, .slot-list { grid-template-columns: 1fr; } .student-hero, .section-head { display: grid; } }
  `]
})
export class AcademicDashboardComponent implements OnInit {
  private readonly auth = inject(AuthService);
  private readonly academic = inject(AcademicApiService);
  private readonly communication = inject(CommunicationApiService);

  readonly user = this.auth.user;
  readonly isAdmin = this.auth.isAdmin;
  readonly isStudent = this.auth.isStudent;
  readonly isTeacher = this.auth.isTeacher;

  students: StudentUser[] = [];
  groups: ClassGroup[] = [];
  timetable?: WeeklyTimetable;
  results?: StudentResults;
  unreadCount = 0;
  loading = false;

  isTeacherOnly(): boolean { return this.isTeacher() && !this.isStudent() && !this.isAdmin(); }

  get activeStudents(): number { return this.students.filter(student => student.enabled && student.enrolled).length; }
  get groupBlocks(): GroupBlock[] {
    return this.groups.map(group => ({
      group,
      students: this.students
        .filter(student => student.classGroupId === group.id)
        .slice()
        .sort((a, b) => a.fullName.localeCompare(b.fullName, 'fr'))
    }));
  }
  get nextSlots(): TimetableSlot[] { return Object.values(this.timetable?.slotsByDay ?? {}).flat().slice(0, 5); }

  ngOnInit(): void {
    if (this.isAdmin()) {
      this.loadAdminDashboard();
      return;
    }
    this.loadStudentDashboard();
  }

  loadAdminDashboard(): void {
    this.loading = true;
    forkJoin({
      students: this.academic.adminStudentUsers().pipe(catchError(() => of([] as StudentUser[]))),
      groupsS2: this.academic.adminClassGroups('Informatique', 1, 'S2').pipe(catchError(() => of([] as ClassGroup[]))),
      groupsS4: this.academic.adminClassGroups('Informatique', 2, 'S4').pipe(catchError(() => of([] as ClassGroup[]))),
      unread: this.communication.unreadCount(this.auth.studentId()).pipe(catchError(() => of({ unreadCount: 0 })))
    }).pipe(finalize(() => this.loading = false)).subscribe(({ students, groupsS2, groupsS4, unread }) => {
      this.students = students;
      this.groups = [...groupsS2, ...groupsS4].sort((a, b) => a.name.localeCompare(b.name, 'fr'));
      this.unreadCount = unread.unreadCount;
    });
  }

  loadStudentDashboard(): void {
    const user = this.user();
    const studentId = this.auth.studentId();
    if (!studentId) return;
    this.loading = true;
    forkJoin({
      timetable: this.academic.timetable(studentId, user?.defaultYear ?? 2, user?.defaultSemester ?? 'S4').pipe(catchError(() => of(undefined))),
      results: this.academic.grades(studentId, user?.defaultDepartment ?? 'Informatique', user?.defaultYear ?? 2, user?.defaultSemester ?? 'S4').pipe(catchError(() => of(undefined))),
      unread: this.communication.unreadCount(studentId).pipe(catchError(() => of({ unreadCount: 0 })))
    }).pipe(finalize(() => this.loading = false)).subscribe(({ timetable, results, unread }) => {
      this.timetable = timetable;
      this.results = results;
      this.unreadCount = unread.unreadCount;
    });
  }

  numberOrDash(value: number | string | undefined | null): string {
    if (value === undefined || value === null) return '-';
    const n = Number(value);
    return Number.isFinite(n) ? n.toFixed(2) : String(value);
  }

  dayLabel(day: string): string {
    return ({ MONDAY: 'Lundi', TUESDAY: 'Mardi', WEDNESDAY: 'Mercredi', THURSDAY: 'Jeudi', FRIDAY: 'Vendredi', SATURDAY: 'Samedi' } as Record<string, string>)[day] ?? day;
  }
}
