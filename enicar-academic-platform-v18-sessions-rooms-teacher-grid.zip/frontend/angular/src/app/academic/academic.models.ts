export type Semester = 'S1' | 'S2' | 'S3' | 'S4';
export type DayName = 'MONDAY' | 'TUESDAY' | 'WEDNESDAY' | 'THURSDAY' | 'FRIDAY' | 'SATURDAY';

export interface TimetableSlot {
  id: number;
  classGroupId: number;
  classGroupName: string;
  courseId: number;
  courseName: string;
  dayOfWeek: DayName;
  startTime: string;
  endTime: string;
  room: string;
  professorId: number;
  professorName: string;
  status: 'ACTIVE' | 'CANCELLED';
  changeReason?: string;
}

export interface WeeklyTimetable {
  classGroupId: number;
  classGroupName: string;
  department: string;
  year: number;
  semester: Semester;
  slotsByDay: Partial<Record<DayName, TimetableSlot[]>>;
}

export interface StudentGrade {
  id?: number;
  studentId: number;
  department: string;
  year: number;
  semester: Semester;
  subjectId: number;
  subjectName: string;
  moduleId: number;
  moduleName: string;
  ccGrade?: number;
  examGrade?: number;
  tpGrade?: number;
  subjectAverage?: number;
  complete: boolean;
  validated: boolean;
}

export interface StudentOption {
  id: number;
  code: string;
  fullName: string;
  defaultDepartment: string;
  defaultYear: number;
  defaultSemester: Semester;
  classGroupId: number;
  classGroupName: string;
}

export interface StudentGradeUpsertRequest {
  department: string;
  year: number;
  semester: Semester;
  subjectId: number;
  ccGrade?: number | null;
  examGrade?: number | null;
  tpGrade?: number | null;
}

export interface RequiredExamGrade {
  subjectId: number;
  subjectName: string;
  requiredForSubject?: number;
  requiredForModule?: number;
  impossibleForSubject: boolean;
  impossibleForModule: boolean;
  status: string;
  message: string;
}

export interface ModuleResult {
  id?: number;
  moduleId: number;
  moduleName: string;
  department: string;
  year: number;
  semester: Semester;
  moduleAverage?: number;
  creditsEarned: number;
  moduleCredits: number;
  complete: boolean;
  validated: boolean;
  requiredExamGrades: RequiredExamGrade[];
}

export interface SemesterResult {
  id?: number;
  studentId: number;
  department: string;
  year: number;
  semester: Semester;
  semesterAverage?: number;
  totalCredits: number;
  complete: boolean;
  validated: boolean;
}

export interface StudentResults {
  grades: StudentGrade[];
  modules: ModuleResult[];
  semester?: SemesterResult;
}

export interface ClassGroup {
  id: number;
  name: string;
  department: string;
  year: number;
  semester: Semester;
  description?: string;
}

export interface TimetableSlotMoveRequest {
  dayOfWeek: DayName;
  startTime: string;
  endTime: string;
  room: string;
  professorId?: number | null;
  professorName?: string | null;
  changeReason?: string | null;
}

export interface RoomAvailability {
  available: boolean;
  room: string;
  dayOfWeek: DayName;
  startTime: string;
  endTime: string;
  message: string;
}

export interface StudentUser {
  id: number;
  studentId: number;
  username: string;
  code: string;
  fullName: string;
  email?: string | null;
  department: string;
  year: number;
  semester: Semester;
  classGroupId: number;
  classGroupName: string;
  enabled: boolean;
  enrolled: boolean;
}

export interface StudentCreateRequest {
  username: string;
  password: string;
  fullName: string;
  email?: string | null;
  studentCode?: string | null;
  department: string;
  year: number;
  semester: Semester;
  classGroupId: number;
}

export interface StudentUpdateRequest {
  fullName: string;
  email?: string | null;
  studentCode?: string | null;
  department: string;
  year: number;
  semester: Semester;
  classGroupId: number;
  enabled: boolean;
  enrolled: boolean;
}

export interface CourseOption {
  id: number;
  name: string;
  department: string;
  code?: string | null;
  defaultCoefficient?: number | null;
  defaultCredits?: number | null;
}

export interface TeacherUser {
  id: number;
  username: string;
  fullName: string;
  email?: string | null;
  enabled: boolean;
  courses: CourseOption[];
}

export interface TeacherCreateRequest {
  username: string;
  password: string;
  fullName: string;
  email?: string | null;
  courseIds: number[];
  enabled: boolean;
}

export interface TeacherUpdateRequest {
  fullName: string;
  email?: string | null;
  courseIds: number[];
  enabled: boolean;
}

export type TimetableChangeRequestStatus = 'PENDING' | 'APPROVED' | 'REJECTED';

export interface TimetableChangeRequestCreateRequest {
  slotId: number;
  dayOfWeek: DayName;
  startTime: string;
  endTime: string;
  room: string;
  reason?: string | null;
}

export interface TimetableChangeRequestItem {
  id: number;
  status: TimetableChangeRequestStatus;
  teacherId: number;
  teacherName: string;
  slotId: number;
  courseName: string;
  classGroupName: string;
  currentDayOfWeek: DayName;
  currentStartTime: string;
  currentEndTime: string;
  currentRoom: string;
  requestedDayOfWeek: DayName;
  requestedStartTime: string;
  requestedEndTime: string;
  requestedRoom: string;
  reason?: string | null;
  adminResponse?: string | null;
  createdAt?: string | null;
  decidedAt?: string | null;
}
