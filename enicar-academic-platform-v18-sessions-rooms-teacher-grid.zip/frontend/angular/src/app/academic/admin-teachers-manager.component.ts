import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AcademicApiService } from './academic-api.service';
import { CourseOption, TeacherUser } from './academic.models';

@Component({
  selector: 'app-admin-teachers-manager',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <section class="card teachers-page">
      <header class="page-head"><div><span class="badge info">Enseignants</span><h2>Enseignants et matieres</h2></div><button class="btn" type="button" (click)="newTeacher()">Nouvel enseignant</button></header>
      <div class="alert danger" *ngIf="error"><span>{{ error }}</span></div>
      <div class="alert success" *ngIf="success"><span>{{ success }}</span></div>
      <div class="layout">
        <form class="editor" (ngSubmit)="save()">
          <h3>{{ selected?.id ? 'Modifier enseignant' : 'Ajouter enseignant' }}</h3>
          <label>Nom complet<input class="input" [(ngModel)]="form.fullName" name="fullName" required></label>
          <label>Identifiant<input class="input" [(ngModel)]="form.username" name="username" [disabled]="!!selected?.id" required></label>
          <label *ngIf="!selected?.id">Mot de passe<input class="input" type="password" [(ngModel)]="form.password" name="password" required></label>
          <label>Email<input class="input" [(ngModel)]="form.email" name="email"></label>
          <label><input type="checkbox" [(ngModel)]="form.enabled" name="enabled"> Actif</label>
          <div class="course-box">
            <strong>Matieres affectees</strong>
            <label *ngFor="let course of courses"><input type="checkbox" [checked]="form.courseIds.includes(course.id)" (change)="toggleCourse(course.id)"> {{ course.name }}</label>
          </div>
          <button class="btn" type="submit">Enregistrer</button>
        </form>
        <section class="teacher-list">
          <article class="teacher-card" *ngFor="let teacher of teachers" (click)="select(teacher)" [class.active]="teacher.id === selected?.id">
            <div><strong>{{ teacher.fullName }}</strong><span>{{ teacher.username }}</span></div>
            <small>{{ teacher.courses.length }} matiere(s)</small>
          </article>
        </section>
      </div>
    </section>
  `,
  styles: [`
    .teachers-page { padding: 1.2rem; display: grid; gap: 1rem; }
    .page-head { display: flex; justify-content: space-between; align-items: center; gap: 1rem; }
    h2 { margin: .35rem 0 0; font-size: clamp(1.65rem, 3vw, 2.35rem); letter-spacing: -.05em; }
    .layout { display: grid; grid-template-columns: 420px 1fr; gap: 1rem; align-items: start; }
    .editor, .teacher-card { border: 1px solid var(--line); border-radius: 24px; background: #fff; box-shadow: var(--shadow-soft); }
    .editor { padding: 1rem; display: grid; gap: .8rem; }
    .editor h3 { margin: 0; }
    .editor label { display: grid; gap: .35rem; color: var(--muted); font-weight: 900; }
    .course-box { max-height: 360px; overflow: auto; display: grid; gap: .4rem; padding: .8rem; border: 1px solid var(--line); border-radius: 18px; background: #f8fafc; }
    .course-box label { display: flex; align-items: center; gap: .5rem; color: #0f172a; font-weight: 700; }
    .teacher-list { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: .8rem; }
    .teacher-card { padding: 1rem; cursor: pointer; display: flex; justify-content: space-between; gap: .8rem; }
    .teacher-card.active { border-color: #2563eb; background: #eff6ff; }
    .teacher-card span, .teacher-card small { color: var(--muted); font-weight: 800; }
    @media (max-width: 1050px) { .layout { grid-template-columns: 1fr; } .teacher-list { grid-template-columns: 1fr; } }
  `]
})
export class AdminTeachersManagerComponent implements OnInit {
  teachers: TeacherUser[] = [];
  courses: CourseOption[] = [];
  selected?: TeacherUser;
  error = '';
  success = '';
  form = { username: '', password: '', fullName: '', email: '', enabled: true, courseIds: [] as number[] };
  constructor(private readonly api: AcademicApiService) {}
  ngOnInit(): void { this.load(); }
  load(): void {
    this.error = ''; this.success = '';
    this.api.courses('Informatique').subscribe({ next: courses => this.courses = courses, error: () => this.error = 'Matieres indisponibles.' });
    this.api.adminTeachers().subscribe({ next: teachers => this.teachers = teachers, error: () => this.error = 'Enseignants indisponibles.' });
  }
  newTeacher(): void { this.selected = undefined; this.form = { username: '', password: '', fullName: '', email: '', enabled: true, courseIds: [] }; }
  select(teacher: TeacherUser): void {
    this.selected = teacher;
    this.form = { username: teacher.username, password: '', fullName: teacher.fullName, email: teacher.email ?? '', enabled: teacher.enabled, courseIds: teacher.courses.map(c => c.id) };
  }
  toggleCourse(courseId: number): void {
    this.form.courseIds = this.form.courseIds.includes(courseId) ? this.form.courseIds.filter(id => id !== courseId) : [...this.form.courseIds, courseId];
  }
  save(): void {
    this.error = ''; this.success = '';
    const request = { fullName: this.form.fullName, email: this.form.email || null, courseIds: this.form.courseIds, enabled: this.form.enabled };
    const call = this.selected?.id
      ? this.api.updateTeacher(this.selected.id, request)
      : this.api.createTeacher({ ...request, username: this.form.username, password: this.form.password });
    call.subscribe({ next: teacher => { this.success = 'Enseignant enregistre.'; this.load(); this.select(teacher); }, error: err => this.error = err?.error?.message ?? 'Enregistrement impossible.' });
  }
}
