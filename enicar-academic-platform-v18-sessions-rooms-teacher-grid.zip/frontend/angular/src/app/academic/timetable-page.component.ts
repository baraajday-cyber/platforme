import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { finalize } from 'rxjs';
import { AuthService } from '../auth/auth.service';
import { AcademicApiService } from './academic-api.service';
import { DayName, Semester, TimetableSlot, WeeklyTimetable } from './academic.models';

@Component({
  selector: 'app-timetable-page',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <section class="card page-card">
      <header class="page-head">
        <div><span class="badge">Emploi du temps</span><h2>Ma semaine</h2></div>
        <div class="filters">
          <select class="select" [(ngModel)]="semester"><option value="S1">S1</option><option value="S2">S2</option><option value="S3">S3</option><option value="S4">S4</option></select>
          <button class="btn" (click)="load()" [disabled]="loading">Afficher</button>
        </div>
      </header>

      <div class="alert danger" *ngIf="error"><span>{{ error }}</span></div>
      <div class="meta" *ngIf="timetable">
        <span>{{ timetable.classGroupName }}</span><span>{{ timetable.semester }}</span><span>{{ timetable.department }}</span>
      </div>

      <div class="timetable-scroll" *ngIf="timetable && !loading; else loadingTpl">
        <div class="week-grid">
          <div class="grid-head time-head">Heure</div>
          <div class="grid-head" *ngFor="let day of days">{{ label(day) }}</div>
          <ng-container *ngFor="let row of timeRows">
            <div class="time-cell"><strong>{{ row.label }}</strong><small>{{ row.start }} - {{ row.end }}</small></div>
            <div class="course-cell" *ngFor="let day of days">
              <article class="course-card" *ngFor="let slot of slotsAt(day, row.start)" [class.cancelled]="slot.status === 'CANCELLED'">
                <strong>{{ slot.courseName }}</strong>
                <span>{{ slot.professorName || '-' }}</span>
                <small>{{ slot.room }}</small>
              </article>
              <span class="free" *ngIf="slotsAt(day, row.start).length === 0">Libre</span>
            </div>
          </ng-container>
        </div>
      </div>
      <ng-template #loadingTpl><p class="empty">{{ loading ? 'Chargement...' : 'Aucun emploi du temps' }}</p></ng-template>
    </section>
  `,
  styles: [`
    .page-card { padding: 1.15rem; display: grid; gap: 1rem; overflow: hidden; }
    .page-head { display: flex; justify-content: space-between; align-items: start; gap: 1rem; }
    h2 { margin: .35rem 0 0; font-size: clamp(1.7rem, 3vw, 2.35rem); letter-spacing: -.05em; }
    .filters, .meta { display: flex; gap: .6rem; align-items: center; flex-wrap: wrap; }
    .meta span { padding: .58rem .76rem; border-radius: 999px; background: #f8fafc; border: 1px solid var(--line); color: #475569; font-weight: 850; }
    .timetable-scroll { overflow-x: auto; padding-bottom: .45rem; }
    .week-grid { min-width: 1160px; display: grid; grid-template-columns: 92px repeat(6, 172px); gap: .62rem; align-items: stretch; }
    .grid-head { padding: .85rem; border-radius: 18px; text-align: center; color: white; font-weight: 950; background: linear-gradient(135deg, #2563eb, #0f766e); }
    .time-head { background: #0f172a; }
    .time-cell { min-height: 128px; padding: .85rem; border-radius: 18px; border: 1px solid var(--line); background: #f8fafc; display: grid; align-content: start; }
    .time-cell strong { font-size: 1.05rem; }
    .time-cell small { color: var(--muted); font-weight: 800; }
    .course-cell { min-height: 128px; padding: .45rem; border-radius: 18px; border: 1px dashed #cbd5e1; background: rgba(248,250,252,.8); display: grid; gap: .45rem; align-content: start; }
    .course-card { padding: .72rem; border-radius: 16px; border: 1px solid #bfdbfe; background: linear-gradient(135deg, #fff, #eff6ff); display: grid; gap: .22rem; box-shadow: 0 8px 18px rgba(37,99,235,.08); }
    .course-card strong { font-size: .9rem; line-height: 1.22; }
    .course-card span { color: #475569; font-size: .82rem; }
    .course-card small { color: #1d4ed8; font-weight: 900; }
    .course-card.cancelled { opacity: .55; text-decoration: line-through; }
    .free { color: #94a3b8; justify-self: center; align-self: center; font-weight: 850; }
    @media (max-width: 820px) { .page-head { display: grid; } }
  `]
})
export class TimetablePageComponent implements OnInit {
  timetable?: WeeklyTimetable;
  loading = false;
  error = '';
  year = 2;
  semester: Semester = 'S4';
  readonly days: DayName[] = ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
  readonly timeRows = [
    { label: 'S1 matin', start: '08:30', end: '10:00' },
    { label: 'S2 matin', start: '10:10', end: '11:40' },
    { label: 'S3 apres-midi', start: '12:30', end: '14:00' },
    { label: 'S4 apres-midi', start: '14:10', end: '15:40' },
    { label: 'S5 apres-midi', start: '15:50', end: '17:20' }
  ];

  constructor(private readonly auth: AuthService, private readonly api: AcademicApiService) {}
  ngOnInit(): void {
    const user = this.auth.user();
    this.year = user?.defaultYear ?? this.year;
    this.semester = user?.defaultSemester ?? this.semester;
    this.load();
  }
  load(): void {
    const studentId = this.auth.studentId();
    if (!studentId) { this.error = 'Profil etudiant requis.'; return; }
    this.loading = true;
    this.error = '';
    this.api.timetable(studentId, this.semester === 'S1' || this.semester === 'S2' ? 1 : 2, this.semester)
      .pipe(finalize(() => this.loading = false))
      .subscribe({ next: timetable => this.timetable = timetable, error: () => this.error = 'Emploi du temps indisponible.' });
  }
  slotsAt(day: DayName, start: string): TimetableSlot[] { return (this.timetable?.slotsByDay?.[day] ?? []).filter(slot => slot.startTime?.slice(0, 5) === start); }
  label(day: DayName): string { return ({ MONDAY: 'Lundi', TUESDAY: 'Mardi', WEDNESDAY: 'Mercredi', THURSDAY: 'Jeudi', FRIDAY: 'Vendredi', SATURDAY: 'Samedi' } as Record<DayName, string>)[day]; }
}
