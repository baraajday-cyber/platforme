$ErrorActionPreference = "Stop"
Write-Host "Reset frontend Angular stable..." -ForegroundColor Cyan
if (Test-Path node_modules) { Remove-Item -Recurse -Force node_modules }
if (Test-Path package-lock.json) { Remove-Item -Force package-lock.json }
npm cache verify
npm install
Write-Host "OK. Lance ensuite depuis le dossier racine: .\START_FRONTEND.ps1" -ForegroundColor Green
