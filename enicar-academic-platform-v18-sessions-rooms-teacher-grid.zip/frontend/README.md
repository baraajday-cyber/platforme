# UniGate Frontend Angular V5

Application Angular standalone complete pour presenter Membre 2 + Membre 3.

## Pages incluses

- Login local modernise.
- Dashboard global.
- Emploi du temps.
- Notes et moyennes.
- Notifications temps reel.
- Preferences notifications.
- Profil Skill Swap.
- Marketplace Skill Swap.
- Mes swaps.

## Lancement

```bash
cd frontend/angular
npm install
npm start
```

Backend attendu : `http://localhost:8081`.

## Comptes de test

- `student / student`
- `admin / admin`
- `demo / demo`

Le frontend utilise Basic Auth local via `/api/auth/login`. Dans l'integration finale, remplacer `AuthService` et l'interceptor par le JWT du Membre 1.
