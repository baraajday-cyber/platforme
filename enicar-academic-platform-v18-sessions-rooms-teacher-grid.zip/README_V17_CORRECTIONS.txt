V17 - Corrections emploi du temps enseignant et salles disponibles

Corrections principales:
1. L'emploi du temps enseignant n'est plus vide si l'enseignant a des matieres affectees.
2. Les affectations enseignant tiennent compte des matieres de l'emploi du temps et pas seulement des matieres de notes.
3. Quand l'admin deplace une seance, la liste Salle affiche uniquement les salles libres pour le jour et l'heure choisis.
4. Si l'admin change le jour ou l'heure, la liste des salles libres est recalculee automatiquement.
5. L'enseignant ne deplace pas directement une seance: il envoie une demande.
6. L'admin accepte ou refuse les demandes depuis Admin EDT.
7. Si l'admin accepte, la seance est deplacee avec les controles de conflit et les etudiants du groupe sont notifies.
8. L'enseignant voit l'etat de ses demandes: en attente, acceptee, refusee.

Important:
- Faire un reset PostgreSQL une seule fois avant de tester cette version.
- Lancer backend puis frontend comme les versions precedentes.
