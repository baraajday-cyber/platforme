ENI Carthage Academic Platform V14
==================================

1) PostgreSQL / pgAdmin
----------------------
Execute une seule fois le contenu de RESET_DATABASE.sql dans pgAdmin.
Ne colle pas le nom du fichier RESET_DATABASE.sql dans Query Tool.
Colle uniquement les lignes SQL du fichier.

2) Lancement backend
--------------------
Methode simple Windows : double-clique START_BACKEND.cmd
ou terminal :
  cd integrated-backend
  "C:\Program Files\apache-maven-3.9.15\bin\mvn.cmd" spring-boot:run

Attends : Tomcat started on port 8081

3) Lancement frontend
---------------------
Methode simple Windows : double-clique START_FRONTEND.cmd
ou terminal :
  cd frontend/angular
  npm install
  npm start

Ouvre : http://localhost:4200/login

4) Comptes
----------
admin / admin
teacher / teacher
student / student
student2 / student2
demo / demo

5) Important
------------
Ne lance pas npm audit fix --force. Cette commande casse les versions Angular.
Les warnings npm audit ne bloquent pas l'execution locale.
Le health check mail est desactive pour eviter l'erreur SMTP localhost:1025.
