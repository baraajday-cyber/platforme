@echo off
setlocal
cd /d "%~dp0frontend\angular"
if not exist node_modules (
  npm install
)
npm start
endlocal
