V18 - Corrections EDT enseignant, creneaux fixes et salles libres

Corrections principales:
1. EDT enseignant affiche maintenant une vraie grille hebdomadaire comme l EDT etudiant/admin.
2. Les creneaux sont limites a 5 sessions pedagogiques par jour: 2 le matin et 3 l apres-midi.
3. Dans Admin EDT, on ne saisit plus une heure libre: on choisit un creneau dans une liste.
4. Dans la demande enseignant, on ne saisit plus une heure libre: on choisit un creneau dans une liste.
5. La liste des salles est recalculée apres changement du jour ou du creneau.
6. La liste des salles contient uniquement les salles libres sur le creneau choisi.
7. Les salles composees comme SL31/S33 sont gerees comme deux salles pour eviter les conflits caches.
8. Le compte teacher est affecte a davantage de matieres reelles de l emploi du temps pour eviter un EDT vide apres reset.
9. Les anciens creneaux 11:50-13:20 du jeu de donnees sont normalises vers le creneau S3 12:30-14:00.

Important: refaire RESET_DATABASE.sql une seule fois avant le premier test de V18.
